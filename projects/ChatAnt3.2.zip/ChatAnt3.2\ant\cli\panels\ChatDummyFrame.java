package ant.cli.panels;
import java.awt.*;
import java.awt.event.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatDummyFrame extends Frame {
	private Dimension Dim;

	private WindowAdapter WinAdp = new WindowAdapter() {

	  public void windowClosing( WindowEvent e ) {

//	     onMailSelected();
		 dispose();		 	
	  }
	};
	
	public	ChatDummyFrame() {

	Dim = new Dimension(750, 450);
	int w = Dim.width;
	int h = Dim.height;
	Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
	if ( w >= d.width )  w = d.width - 10;
	if ( h >= d.height ) h = d.height - 10;
	setSize( w, h );
	setLocation( ( d.width - w ) / 2, ( d.height - h ) / 2 );
	
	addWindowListener( WinAdp );
	
	}
	
	public void validate() {
	super.validate();
}

  public Dimension getDimension() {
   	  return Dim;
   	
   }

}