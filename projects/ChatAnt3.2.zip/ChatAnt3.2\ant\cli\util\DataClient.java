package ant.cli.util;

import java.util.*;

import ant.glob.Globals;
import ant.awt.TextDisplayField;
import ant.awt.Table;

import ant.cli.UpdatableComponent;
import ant.cli.panels.ChatRoom;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class DataClient {

	private String stream;
	private String roomData;

/**
 * DataClient constructor comment.
 */
public DataClient() {
	super();
}
public DataClient(String stream) {
	
	super();
	this.stream = stream;
	
	StringTokenizer st = new StringTokenizer( stream, Globals.FieldSeparator );

	while (st.hasMoreTokens()) {
	  fields.addElement( st.nextToken() );
	}		
   
}
/**
 * Insert the method's description here.
 * Creation date: (16/01/03 11.02.11)
 * @return java.lang.String
 */
public java.lang.String getRoomData() {
	return roomData;
}
/**
 * Insert the method's description here.
 * Creation date: (16/01/03 11.02.11)
 * @param newRoomData java.lang.String
 */
public void setRoomData(java.lang.String newRoomData) {
	roomData = newRoomData;
}
public void updateRecords (UpdatableComponent c, String str) {

  String app = null;
  //this.component = component;
	int i = 0;
	StringTokenizer st = new StringTokenizer( str, Globals.NewRecord );
	c.removeAll();
	while (st.hasMoreTokens()) {
	   app = st.nextToken();
	   c.add( app );
	   //if (room != null) room.updNumUsers( app, i );
	   i++;
	}	  	
}

public void updateRoomTabList (UpdatableComponent c) {

  String rec = null;
  String fld = null;
  //this.component = component;
  int i = 0;
	
	StringTokenizer st = new StringTokenizer( roomData, Globals.NewRecord );
	//component.removeAll();	
	while (st.hasMoreTokens()) {		
	   rec = st.nextToken();
	   
	   StringTokenizer st1 = new StringTokenizer( rec, Globals.FieldSeparator );
	   while (st1.hasMoreTokens()) {
		  fld = st1.nextToken();
	      ( (Table)c ).add( new TextDisplayField(fld) );
	   }
	   
	//if (room != null) room.updNumUsers( app, i );
	i++;
	}	  	
}

	Vector fields = new Vector();
	public ChatRoom room;

public String getField (int i) {

  return (String)fields.elementAt(i);
}

public Vector getFields (String stream) {

	//int i = 0;
	Vector fields = new Vector();
	StringTokenizer st = new StringTokenizer( stream, Globals.FieldSeparator );

	while (st.hasMoreTokens()) {
	   fields.addElement( st.nextToken() );
	   //i++;
	}	  	
  return fields;
}

public void updateRoomList (UpdatableComponent c, ChatRoom room) {

  String app = null;
  int i = 0;
	StringTokenizer st = new StringTokenizer( roomData, Globals.NewRecord );
	c.removeAll();
	while (st.hasMoreTokens()) {
	   app = st.nextToken();
	   c.add( app );
	   if (room != null) room.updCruscotto( app, i );//� !=da null se ci sto chattando dentro
	   i++;
	}	  	
}
public String format2Digits (int num) {

  return num < 10 ?  "0"+ String.valueOf(num) 
				  : String.valueOf(num);
				  
}
public java.awt.List loadListFromString (String str, java.awt.List c) {

  StringTokenizer st = new StringTokenizer( str, Globals.FieldSeparator );
  c.removeAll();
  while (st.hasMoreTokens()) {
	   c.add( st.nextToken() );
  }
  return c;
}}