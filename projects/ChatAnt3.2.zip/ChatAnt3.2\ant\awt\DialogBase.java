package ant.awt;
import java.awt.Frame;
import java.awt.Dialog;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class DialogBase extends Dialog {

  private WindowAdapter WindowLstn = new WindowAdapter()  {
	  
	public void windowClosing( WindowEvent e ) {
		
	  dispose();
	}
  };
public DialogBase( Frame owner, String title, boolean modal ) {

  super( owner, title, modal );

  addWindowListener( WindowLstn );
/*  addContent();
  pack();
  show();
  // addWindowListener( WindowLstn );    NON QUI!!! Se la dialog e' modale
									  // allora interrompe il flusso 
									  // del programma dopo lo show()!!!
*/}
}