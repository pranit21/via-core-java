package ant.awt;
import java.awt.Frame;
import java.awt.Rectangle;

import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import ant.glob.Globals;
import ant.cli.NickAdmin;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class CentrDlgBase extends DialogBase {

  private Frame owner;   // see validate()
  private boolean okAnn;
  private NickAdmin nickAdm; 
  
  public CentrDlgBase
    ( Frame owner, String title, String nDiagn, boolean modal ) {
	
	this( owner, title, nDiagn, modal, false, null );
  
  }

 public CentrDlgBase
	( Frame owner, String title, String nDiagn, 
	  boolean modal, boolean okAnn, NickAdmin nickAdm ) {	

	super( (Frame) owner, title, modal);
	this.owner = (Frame) owner;     // see validate() 
	this.okAnn = okAnn; 
	this.nickAdm = nickAdm;
	
	String diagn = Globals.Diagn[ Integer.parseInt(nDiagn) ];
	drawPanel(diagn);
}
public void validate() {

  Rectangle parentBounds = owner.getBounds();  // getOwner() throws SecurityException
											   // in Applet
  Rectangle myBounds = super.getBounds();
  myBounds.x = parentBounds.x + ( parentBounds.width  - myBounds.width  ) / 2;
  myBounds.y = parentBounds.y + ( parentBounds.height - myBounds.height ) / 2;
  if ( myBounds.x < 0 ) myBounds.x = 0;
  if ( myBounds.y < 0 ) myBounds.y = 0;
  setBounds( myBounds );
  super.validate();
}


public void drawPanel(String diagn) {

  setBackground( Color.red );  
  setForeground( Color.white );
  
  Panel contentErr = new Panel( new BorderLayout( 10, 10 ) ) {
	   public Insets getInsets() { return new Insets( 10,10,10,10 ); } };
	contentErr.add( new Label( diagn ),
	                BorderLayout.CENTER );
	                 
	Panel p = new Panel(new FlowLayout());
	  p.setForeground( owner.getForeground() );  
	  Button ok = new Button( "OK" );
	  ok.addActionListener( new ActionListener() {
		  public void actionPerformed( ActionEvent e ) {
			    dispose();
		    }
	 	  }
	  );
	p.add( ok );
	
	if (okAnn) {
		Button annulla = new Button( "ANNULLA" );
		annulla.addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e ) { 
				  nickAdm.setVocalCallRefused();
				  dispose();
			  }
			}
		);
      p.add( annulla );
	}
		
    contentErr.add( p, BorderLayout.SOUTH );
  
  add( contentErr );
  setResizable( false );
  pack();
  show();

}


}