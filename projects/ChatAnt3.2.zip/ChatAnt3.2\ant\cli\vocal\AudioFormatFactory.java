/*
 * Created on 10-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;

import javax.sound.sampled.AudioFormat;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class AudioFormatFactory {
	

	//AudioFormat.Encoding.PCM_SIGNED, 16000.0f, 16, 1, 2, 16000.0f, true);
	//AudioFormat.Encoding.PCM_SIGNED, 8000.0f, 8, 1, 1, 8000.0f, true);

	//questo dovrebbe essere un buon compromesso
	//AudioFormat.Encoding.PCM_SIGNED, 16000.0f, 8, 1, 1, 16000.0f, true);


 public static final AudioFormat FORMAT16000_2 =
		 new AudioFormat(
			 AudioFormat.Encoding.PCM_SIGNED, 16000.0f, 16, 1, 2, 16000.0f, true);

 public static final AudioFormat FORMAT16000 =
		 new AudioFormat(
				 AudioFormat.Encoding.PCM_SIGNED, 16000.0f, 8, 1, 1, 16000.0f, true);

 public static final AudioFormat FORMAT8000 =
		 new AudioFormat(
			 AudioFormat.Encoding.PCM_SIGNED, 8000.0f, 8, 1, 1, 8000.0f, true);

 //richiede JVM 1.5
 //private static AudioFormat.Encoding	enc_GSM = new AudioFormat.Encoding("GSM0610");
 //public static final AudioFormat FORMAT_GSM =
 //     new AudioFormat(enc_GSM, 8000.0f, 8, 1, 1, 8000.0f, true);

public AudioFormat getFormat(int bit) {	
  
  if (bit == 8) { 
  
	return new AudioFormat(
		AudioFormat.Encoding.PCM_SIGNED,
		(float)8000, //diminuentdo la frequenza sento pi� basso e pi� lento
		8,
		1,
		1,
		(float)8000,
		true
	);
  } else {
  
    return new AudioFormat(
	  (float)8000,
	  bit,
	  1,
	  true,
	  true
     );  
   } 
 }

//public AudioFormat getFormatGSM() {			
//		return FORMAT_GSM;
//}



}
