package ant.cli.ftp;

import ant.awt.LabLog;

import java.net.*;
import java.io.*;
import ant.cli.video.AntVideoFrameGrabbing;

/**
 * 
 * @author A.Formiconi
 * esegue "l'upload". Legge un file e lo manda in DataOutptupStream 
 *
 */
public class CopyOfSendImageClient extends Thread {
	Thread thread;
	private InetAddress address;	 	 	
	private int porta;
	private String str;
	private String nick;
	private Socket server ;
	private String nomeFile;
	private LabLog labLog;
	private boolean toRepository = false;
	private byte[] imageBytes;
	AntVideoFrameGrabbing grabber;
	
public CopyOfSendImageClient ()

		throws IOException {

}

public void destroy() {
	super.destroy();

	// inserire qui la codifica per il rilascio delle risorse
}

public void run() {
	
	try {
	
	sleep(2000);
	Socket server = new Socket ( address, 9990 );	
	System.out.println("---- SendImageGrabbedClient, socket eseguito"); 
    
	 
	//BufferedOutputStream out = new BufferedOutputStream(server.getOutputStream());	
	//DataOutputStream oStream = new DataOutputStream(out);
	
	//alternativa
	DataOutputStream oStream = new DataOutputStream(server.getOutputStream());	
	int BufferSize = imageBytes.length;
	
	int n;
	  
	//sincronizzare imageBytes
	oStream.write(imageBytes,0,BufferSize);
	System.out.println("---- SendImageGrabbedClient, immagine spedita!!");	
	oStream.close();

	if (null != server) {
	  try {
		thread = null;		
		server.close (); 
	}
	    catch (IOException e) {
		  System.out.println( "SendImageGrabbed: errore chiususra socket " + e);
	    }
	    //System.out.println( "FtpClient: Chiudo la connessione con "+ server.getInetAddress() ) ;
	}

	}
	catch ( FileNotFoundException e ) {
	      System.out.println( "SendImageGrabbed: file non trovato, eccezione: "+e ) ;
	      System.out.println( "SendImageGrabbed: file non trovato = "+ nomeFile);
	}
	catch ( IOException e ) {
		System.out.println( "SendImageGrabbed: errore socket "+e );
		e.printStackTrace();
	}
	catch (Exception ex) {
		System.out.println ("SendImageGrabbed : errore apertura socket :"+ex);
		ex.printStackTrace();
	}
	finally {
	  System.out.println ("---------------- SendImageGrabbed STOPPED");
	  interrupt();
	}
}


public void start() {
	if (thread == null){
		thread = new Thread(this);
		thread.start();
	}
 }           
		

 public CopyOfSendImageClient (byte[] imageBytes, InetAddress address)
	throws IOException {

	    this.address = address;
		this.imageBytes = imageBytes;
}     

 public CopyOfSendImageClient (AntVideoFrameGrabbing grabber, byte[] imageBytes, InetAddress address)
 throws IOException {

 	this.address = address;
 	this.imageBytes = imageBytes;
 	this.grabber = grabber;
 }     

             
public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}


}