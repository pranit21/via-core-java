package ant.dyn;

import java.io.*;
import java.util.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class ChatDirList implements Serializable {

 private String[] list;
 private String Directory;

 public ChatDirList(String Directory)
 {
	this.Directory = Directory;
	File path = new File( 
		 getDrive() 
		 + File.separator 
		 + Directory);  //=MieiFiles o Repository

	list = path.list();
	if (list == null)
	  path.mkdir();
	else {
	  listLung = new String[ list.length ];
	  for (int i=0; i<list.length ; i++)
	      listLung[i] = getLung( list[i] );
	}	     
 }                                     
 public String[] getList()
 	{
 	return list;
	}

 public String[] listLung;
 long lung;

 public String[] getListLung()
 	{
 	return listLung;
	}

public String getLung(String file) {
	
		File fi = new File(
			getDrive()
			+ File.separator 
			+ Directory
			+ File.separator 
			+ file );
			
 	    lung = fi.length(); 
		return String.valueOf(lung);
}
public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}}