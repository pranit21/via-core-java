package ant.cli.ftp;
import java.net.*;
import java.io.*;

import ant.cli.panels.ChatFinListaFile;
import ant.dyn.RegistroDownload;

import ant.awt.LabLog;

import java.awt.Component;
import ant.awt.PanelMesg;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class FtpServer extends Thread {

	protected BufferedInputStream iStream;
	protected BufferedOutputStream oStream;
	public Thread thread;

	public Socket client;
	public String nomeFile;
	public String nickDonatore;
	public RegistroDownload regdow;

	public ServerSocket server;
	private LabLog labLog;
	private Component MesgValues =
		 new PanelMesg( "Download successful !", PanelMesg.ModeInfo );
	public ChatFinListaFile parent;

	private RegistroDownload listaFiles;

public void run()  {

 labLog = (LabLog) parent.labLog;

 try {

 server = (server == null) ? new ServerSocket(9990) : server;	
 
 labLog.setText( "...AntFtpServer attivato, attesa di ricevere il file..." ) ;
 
 client = server.accept ();
 System.out.println ("FtpServer, donatore : " + client.getInetAddress ());

 labLog.setText( "..Collegato al donatore " );
 labLog.setColor(java.awt.Color.pink);
	
// BufferedInputStream iStream = new BufferedInputStream( client.getInputStream (),1024);
  BufferedInputStream in = new BufferedInputStream( client.getInputStream ());
  DataInputStream iStream = new DataInputStream( in );
  FileOutputStream fout =
	 new FileOutputStream( new File(
		 getDrive()
		 + File.separator 
		 + "MieiFiles"
		 + File.separator + "Ant_" + nomeFile ) );
		 
  DataOutputStream oStream = new DataOutputStream(fout);

  //int BufferSize = 1024;
  int BufferSize = 2048;
  //int buflen = fout.length() > 1000000L ? 10240 : 2048;
  byte buf[] = new byte[ BufferSize ];  
  int n;
  int totBytes=0;

//	while ( ( n = iStream.read( buf ) ) >= 0 ) {
//  byte bit;
//  while (iStream.available() != 0 ) {
//	   bit = iStream.readByte();
//	    oStream.writeByte(bit);

	while ( ( n = iStream.read( buf, 0, BufferSize ) ) != -1 ) {
		//	  oStream.write( buf );
	  oStream.write( buf, 0, n );
	  //totBytes = totBytes + BufferSize;
	  totBytes += BufferSize;
	  labLog.setText( totBytes +" bytes ricevuti...");
	}
	fout.close();
	iStream.close();
	oStream.close();
	in.close();

	labLog.setText("..Download terminato ! " + totBytes +" ricevuti");
	labLog.setColor(java.awt.Color.cyan);

 } catch (java.net.BindException ex) {
	     labLog.setText("..Attendere: up/downLoading in corso sul tuo PC");
	  	 labLog.setColor(java.awt.Color.pink);

 } catch (Exception ex) {
	     System.out.println ("FtpServer: errore ricezione dati: ");
		 ex.printStackTrace ();
 }

 if (null != client) {
   //System.out.println( "..Ftp Server: Chiudo la connessione con "+client.getInetAddress() ) ;
   try {
	  client.close ();
	  }
   catch (IOException e) { 
	  System.out.println( "Ftp Server: errore close socket " + e.getMessage() );
	  e.printStackTrace();
	  }
 }

try {
  if ( server != null )  server.close();
  thread = null;
  interrupt();
  } 
catch (IOException e) {
  System.out.println( "Ftp Server: errore close socket " +e);
  }

}

public void start () {

	if (thread == null) {
		thread = new Thread(this);
		thread.start();
	}

}     	 	 	 	 	 	 	 


public FtpServer(String nomeFile, ChatFinListaFile parent) 
   throws IOException {
	   
	  this.nomeFile = nomeFile;
	  this.parent = parent;
   }                     

public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}

}