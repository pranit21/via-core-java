package ant.cli.panels;
import java.awt.Frame;


import java.awt.*;
import java.awt.Color;
import java.awt.event.*;

import ant.glob.Globals;
import ant.awt.LimitedTabTextField;
import ant.cli.ChatFrame;

import java.awt.event.WindowAdapter;

import java.awt.event.WindowEvent;
import java.util.Properties;
import java.io.*;
import java.util.Observer;
import java.util.Observable;
import java.util.StringTokenizer;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatFrameConnect extends Frame 
    implements ActionListener, Observer {

  private ChatFrame owner;   // see validate()
  private Button buOk, buAnnulla; 
  private String serverAddress, porta, nomeServer;  
  private Properties p;  
  private TextField txNome, txPorta; 
  private LimitedTabTextField 
      txHost1, txHost2, txHost3, txHost4;  
  private String userDir;

public void validate() {

  Rectangle parentBounds = owner.getBounds();  // getOwner() throws SecurityException
											   // in Applet
  Rectangle myBounds = super.getBounds();
  myBounds.x = parentBounds.x + ( parentBounds.width  - myBounds.width  ) / 2;
  myBounds.y = parentBounds.y + ( parentBounds.height - myBounds.height ) / 2;
  if ( myBounds.x < 0 ) myBounds.x = 0;
  if ( myBounds.y < 0 ) myBounds.y = 0;
  setBounds( myBounds );
  super.validate();
}


public void update( Observable obs, Object obj) {
	
	if (obj == null) return;
	int index = ((Integer)obj).intValue();
	
	if (index == 1) txHost2.requestFocus();
	if (index == 2) txHost3.requestFocus();
	if (index == 3) txHost4.requestFocus();
}

public void actionPerformed( ActionEvent e ) {
	//setNick();
}

      public ChatFrameConnect( Frame owner ) throws IOException {
	
  //super( owner, "Nuovo collegamento con il server...", true ); //modal
  this.owner = (ChatFrame)owner;     // see validate()
  setTitle("Nuovo collegamento con il server..");
  
  String lab = "Host : ";
  String lab2 = "Nome : ";
  String lab3 = "Porta :";
  
  setBackground( Globals.CruscottoColor );  
  setForeground( Color.white );
  
  Panel content = new Panel( new GridLayout( 4,1,2,2 ) )
  {
	   public Insets getInsets() { return new Insets( 10,10,10,10 ); 
		   } 
  };


 Panel p01 = new Panel( new BorderLayout( 2, 2 ) );
	p01.add( new Label( lab ), BorderLayout.WEST );
	  Panel pHost = new Panel (new FlowLayout());
	  
		txHost1 = new LimitedTabTextField(3, 3, 1);
		txHost2 = new LimitedTabTextField(3, 3, 2);
		txHost3 = new LimitedTabTextField(3, 3, 3);
		txHost4 = new LimitedTabTextField(3, 3, 3);
		pHost.add(txHost1);
		pHost.add(txHost2);
		pHost.add(txHost3);
		pHost.add(txHost4);
	
		txHost1 .setFont(new Font("Mia", Font.BOLD, 14));
		txHost1.setForeground( Globals.Bordeaux );
		txHost1 .setObserver(this);
		
		txHost2 .setFont(new Font("Mia", Font.BOLD, 14));
		txHost2.setForeground( Globals.Bordeaux );
		txHost2 .setObserver(this);
		
		txHost3 .setFont(new Font("Mia", Font.BOLD, 14));
		txHost3.setForeground( Globals.Bordeaux );
		txHost3 .setObserver(this);
		
		txHost4 .setFont(new Font("Mia", Font.BOLD, 14));
		txHost4.setForeground( Globals.Bordeaux );
		
	
	p01.add( pHost, BorderLayout.EAST );
/* 1 */ content.add(p01);
 
 Panel p02 = new Panel( new BorderLayout( 2, 2 ) ); 
	p02.add( new Label( lab2 ), BorderLayout.WEST );
	txNome = new TextField(25);
	txNome.setFont(new Font("Mia", Font.BOLD, 14));
	txNome.setForeground( Globals.Bordeaux );
	txNome.setEnabled(true);
	//txEmail .addActionListener(this);
	p02.add( txNome, BorderLayout.EAST );
/* 2 */ content.add(p02);     
	 
/* 3 */
 Panel p03 = new Panel( new BorderLayout( 2, 2 ) ); 
	p03.add( new Label( lab3 ), BorderLayout.WEST );
	txPorta = new TextField(6);
	txPorta.setFont(new Font("Mia", Font.BOLD, 14));
	txPorta.setForeground( Globals.Bordeaux );
	txPorta.setEnabled(true);
	//txEmail .addActionListener(this);
	p03.add( txPorta, BorderLayout.EAST );
 content.add(p03);     


	//Panel p2 = new Panel();
	Panel p2 = new Panel( new FlowLayout( 2 ) ); 
	  buOk = new Button( "OK" );
	  buAnnulla = new Button( "Annulla" );
	  
	  buOk.addMouseListener( new MouseAdapter() { 
	      public void mouseClicked( MouseEvent e ) {
		    reconnect();  
		  }
	   }
	  );
	  buAnnulla.addMouseListener( new MouseAdapter() { 
	      public void mouseClicked( MouseEvent e ) {
	          dispose();
	       }
	   }
	  );
	  
	p2.add( buOk );
	p2.add( buAnnulla );
	 
/* 4 */  content.add( p2 );
	
  add( content );

  addWindowListener ( new WindowAdapter() {
	     public void windowClosing(WindowEvent e) {

	      dispose();
	 }
	} 
   );

  loadProperties();
  
  setResizable( false );
  pack();
  toFront();
  show();
   
}
public void loadProperties() throws IOException {

  readPropertyFile();
  
  //localhost = 127.0.0.1
  StringTokenizer st = new StringTokenizer(serverAddress, ".");
  
  
  if (serverAddress.length() > 0) {
	  txHost1.setText(st.nextToken());
	  txHost2.setText(st.nextToken());	  
	  txHost3.setText(st.nextToken());	  
	  txHost4.setText(st.nextToken());	    	  
  }
  txPorta.setText(porta);
  txNome.setText(nomeServer);	
}
private void readPropertyFile() throws IOException {

	p = new Properties();
	userDir = System.getProperty("user.dir");
	try {
	   p.load(new FileInputStream(
		       userDir 
			   + File.separator
			   + Globals.ChatProperties
			   + File.separator 
			   + "client-config.props" ));
		                      
	}
	catch (IOException e) {
		System.err.println("errore su lettura client-config.props");
		e.printStackTrace();
	    throw new IOException("ChatFrameConnect: errore su lettura client-config.props");
	}

	serverAddress = p.getProperty("ServerIP");
	porta = p.getProperty("Porta");
	nomeServer = p.getProperty("NomeServer");
}

public void reconnect() {	

	try {
	    dispose();
	    owner.dispose();
		writeProperty();
		owner.onReconnect();
		//owner.cli.reconnect();
		//System.exit(0);
	}
	catch (IOException ex) {
		  System.err.println("ChatFrameConnect: errore su scrittura client-config.props");
		  ex.printStackTrace();        
	}
	catch (Exception ex) {
		  System.err.println("ChatFrameConnect: errore su scrittura client-config.props");
		  ex.printStackTrace();        
	}
	
}

private void writeProperty()
   throws IOException {

   //p.setProperty("indice" , "valore");

   p.setProperty("ServerIP", 
         txHost1.getText() + "."
       + txHost2.getText() + "."
       + txHost3.getText() + "."
       + txHost4.getText());
   p.setProperty("Porta", txPorta.getText());
   p.setProperty("NomeServer", txNome.getText());
   p.store( new FileOutputStream(
		      userDir 
			  + File.separator
			  + Globals.ChatProperties
			  + File.separator 
			  + "client-config.props" ), "parametri di connessione");
		                      
 }
   
}