package ant.dyn;
/*
 * @(#)Target.java	1.1 01/03/12
 *
 * Copyright (c) 2001 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Sun grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Sun.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL SUN OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF SUN HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 *
 * This software is not designed or intended for use in on-line control of
 * aircraft, air traffic, aircraft navigation or aircraft communications; or in
 * the design, construction, operation or maintenance of any nuclear
 * facility. Licensee represents and warrants that it will not use or
 * redistribute the Software for such purposes.
 */

import java.io.Serializable;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class Target implements Serializable {
    
	public static int START_VIDEO_AUDIO_CONFERENCE = 3;
    public static int STOP_VIDEO_AUDIO_CONFERENCE = 31;
    public static int START_AUDIO_CONFERENCE = 1;
    public static int STOP_AUDIO_CONFERENCE = 11;
    public static int START_VIDEO_CONFERENCE = 2;
    public static int STOP_VIDEO_CONFERENCE = 21;
    public static int STOP_CONFERENCING = 111;
    public static int CONFERENCING_STOPPED = 112;
    public static int CONFERENCING_STARTED = 113;
    public static int CONFERENCING_BUSY_PORT = 114;
    
    
	public String localPort;
    public String ip;
    public String port;
    public String senderNick;
    public String receiverNick;
    public int Action;
    
    public Target( String localPort,
				   String ip, String port) {
    	this(localPort, ip, port, null, null);
    }	
    
    public Target( String localPort,
		   String ip, String port, 
		   String senderNick, String receiverNick ) {
    	
		this.localPort= localPort;
		this.ip= ip;
		this.port= port;
		this.senderNick=senderNick;
		this.receiverNick=receiverNick;
    }	
    
    public void setAction(int Action) {
       this.Action = Action;
    }
    
    public int getAction() {
    	return Action;
    }
    
	/**
	 * @return Returns the ip.
	 */
	public String getReceiverNick() {
		return receiverNick;
	}

	/**
	 * @return Returns the localPort.
	 */
	public String getLocalPort() {
		return localPort;
	}

	public String getReceiverIP() {
		return ip;
	}
	/**
	 * @return Returns the port.
	 */
	public String getPort() {
		return port;
	}
	public String getSenderNick() {
		return senderNick;
	}

}
