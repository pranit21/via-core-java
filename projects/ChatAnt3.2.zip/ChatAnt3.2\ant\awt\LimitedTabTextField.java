package ant.awt;

import java.awt.TextField;
import java.awt.event.*;
import java.util.Observable;
import java.util.Observer;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class LimitedTabTextField extends TextField {

  private static final boolean DEBUG = false;

  private int MaxLen;
  private String Text;
  private Observer ExtObs;
  int position;
  boolean perdoFocus = false;

  private TextListener TxLstn = new TextListener() {

	public void textValueChanged( TextEvent e ) {

	  changed();
	}
  };
public LimitedTabTextField() {

  this( 0, "", 0, 0 );
}
public LimitedTabTextField( int MaxLen, int Columns ) {

  this( MaxLen, "", Columns, 0 );
}

public LimitedTabTextField( int MaxLen, int Columns, int position ) {

  this( MaxLen, "", Columns, position );
}
public LimitedTabTextField( int MaxLen, String Text, int Columns, int position ) {

  super( Text, Columns );

  this.Text = Text == null ? "" : Text;
  this.MaxLen = MaxLen;
  this.position = position;

  super.addTextListener( TxLstn );
}
public LimitedTabTextField( String Text ) {

  this( 0, Text, 0, 0 );
}
public LimitedTabTextField( String Text, int Columns ) {

  this( 0, Text, Columns, 0 );
}
public void addTextListener( TextListener lst ) {

  throw new RuntimeException( "Not supported" );
}
private synchronized void changed() {

  set( super.getText() );
}
public synchronized String getText() {

  return super.getText();
  //return Text;
}

public synchronized void setText(String tx) {

  super.setText(tx);
}
private synchronized void set( String Text ) {
	
  perdoFocus=false;
  if ( DEBUG )
	System.out.println(
	  getClass().getName() + ".set(" + Text + ')' );

  if ( ( MaxLen > 0 ) && ( Text.length() > MaxLen-1 ) && !perdoFocus ) {
  	perdoFocus= true;
	int p = getCaretPosition();
	//super.setText( Text.substring( 0, MaxLen ) );
	//setCaretPosition( p +1);
	this.Text = Text;
	Integer pos = new Integer(position);
	if ( ExtObs != null ) ExtObs.update( null, pos);
  }
  else {
	this.Text = Text;
	//if ( ExtObs != null ) ExtObs.update( null, Text );
  }
}
public synchronized void setObserver( Observer ExtObs ) {

  this.ExtObs = ExtObs;
  //if ( ExtObs != null ) ExtObs.update( null, Text );
}
}
