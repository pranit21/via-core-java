package ant.awt;

import java.awt.Font;
import java.util.StringTokenizer;
import java.awt.Panel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class FormattedListPanel extends Panel implements ActionListener {

	private int FieldLength[];
	private String line;
	private int NumFields;
	private String[] Fields;
	private ScrollPane scrollPnl;
	private Button[] btn;
	private int[] Marker;
	private int[] NumericFields;
	private boolean LOADED = false;
	
	private String campo = "";		
	private String[] ColTitles ;		
	
	//public java.awt.List lista = new java.awt.List(25, false);
	//public java.awt.List lista = new java.awt.List();
	public java.awt.List lista;
	private String[] record;
	private Record2[] rc2;
	public static int FIRST, LAST;
	//private Record2 rc3 = new Record2();
	//private Vector vtRec = new Vector();
	
 private class Record2 {
	private int index = 0;
	private String rec = "";
 
 private Record2(int index, String rec){
    this.index = index;
    this.rec = rec;
 
 }	

 }
	
	
public FormattedListPanel() {
	super();
}
public FormattedListPanel( int FieldLength[] ) {
	
	super();
	this.FieldLength = FieldLength;

	setFont( new Font("Monospaced", Font.PLAIN, 11) );
	lista.setForeground(Color.black);
	//setFont( new Font("SansSerif", Font.PLAIN, 10) );
	//setFont( new Font("Dialog", Font.PLAIN, 10) ); 
}

public FormattedListPanel( int FieldLength[], String[] ColTitles ) {
	//Richiamato per la lista messaggi di posta	
	this( FieldLength, ColTitles, null, 
	Color.lightGray, Color.black, "ListaMessaggi" );		
}

/*
public FormattedListPanel( int FieldLength[], String[] ColTitles, int[] NumericFields ) {
    //non richiamato danessuno
	this( FieldLength, ColTitles, NumericFields, Color.lightGray, Color.red );	
}
*/

public FormattedListPanel( 
	int FieldLength[], String[] ColTitles, int[] NumericFields, 
	Color bgColor, Color fgColor, String Action ) {
	
	this.FieldLength = FieldLength;
	this.ColTitles = ColTitles;
	this.NumericFields = NumericFields;
	
	//codice sporco per dimensionare la lista 
	//che non riuscivo a dimensionare diversamente
	// listaMessaggi deve essere di poche righe
	// FileSharing, l'altra deve essere a tutto schermo
    if (Action.equals("ListaMessaggi")) {
		lista = new java.awt.List();
    } else {
	    lista = new java.awt.List(25, false);
    }
    
	Panel MainP = new Panel();
	MainP.setLayout(new BorderLayout ());
	Panel p0 = new Panel( new FlowLayout(FlowLayout.LEFT,0,0) );	

	MainP.add ("North", p0);
	MainP.add("Center", lista);  
	add(MainP);
	//scrollPnl = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED );
    //scrollPnl = new ScrollPane(ScrollPane.SCROLLBARS_NEVER);
	//scrollPnl.add( MainP );
	//add(scrollPnl);


	lista.setBackground(bgColor);
	lista.setForeground(fgColor);
        
	setFont( new Font("Monospaced", Font.PLAIN, 11) );
    
	btn = new Button[ColTitles.length];
	Marker = new int[ColTitles.length];
	
	int n = 0;    
	for (int i=0; i < ColTitles.length; i++) {
	   btn[i] = new Button( center(i) );
	   btn[i].addActionListener(this); 
	   p0.add( btn[i] );
	   
	   n += FieldLength[i]; 
	   Marker[i] = n;    
	} 
	
	FIRST = 1;
	LAST = FieldLength.length;
	
}



public void add(String line) {

	int i = 0;
	int spaces = 0;
	String field = ""; 
	Fields = new String[FieldLength.length];
	
	StringTokenizer st = new StringTokenizer(line, "|");
	while (st.hasMoreTokens()) {	   	
	    Fields[i++] = st.nextToken();
	}

	for (i=0; i < Fields.length; i++) {
	   spaces = FieldLength[i] - Fields[i].length();
	   field = field +  Fields[i] + addSpace(spaces);	   
	}	
	lista.add( field );
	field = "";
}
public void add(String[] Fields) {

	int i = 0;
	int spaces = 0;
	String field = ""; 
//	Fields = new String[FieldLength.length];
	
	for (i=0; i < Fields.length; i++) {
	   spaces = FieldLength[i] - Fields[i].length();
	   field = field +  Fields[i] + addSpace(spaces);	   
	}
	
	lista.add( field );
	field = "";
}


private String addSpace(int n) {

	String s = "";
	for (int i=0; i < n; i++)
	   s += " ";
	
	return s;    
	
}

public int getLength(int i) {

	
	return FieldLength[i];
}

public int getPosition(int pos) {

	int Position = 0;
	for (int i=0; i < pos; i++) {
	   Position += FieldLength[i];
	}	
	return Position;
}

public String getField(int row, int pos) {

    int pos2 = pos -1;
	int fromByte;
    int toByte = Marker[pos2];
    fromByte = pos2 == 0 ? 0 : Marker[pos2 -1]; 
	return  lista.getItem(row).substring( fromByte, toByte ).trim();

}

public void setSize(int Width, int Height) {
	//scrollPnl.setSize(Width, Height -30);
	super.setSize(Width, Height);
}


public void addValue(String value, int pos) {

	int spaces = 0;

	spaces = FieldLength[pos] - value.length();
	campo = campo +  value + addSpace(spaces);	   
}
public int getSelectedRow() {

	return lista.getSelectedIndex();	

}public void remove(int num) {

	lista.remove(num);

}

public void writeRow() {
	
	lista.add( campo.trim() );
	campo = "";
}


public String center(int pos) {

	String titolo = ColTitles[pos];
	int lungCampo = FieldLength[pos] - 2; //devo correggere con -2
	
	int spacesLeft = (lungCampo - titolo.length()) / 2;
	int spacesRight = lungCampo - (spacesLeft + titolo.length());

	return addSpace(spacesLeft) + titolo + addSpace(spacesRight); 
}

public String center(String str, int pos) {

	int spacesLeft = (FieldLength[pos] - ColTitles[pos].length()) / 2;
	int spacesRight = spacesLeft + str.length() 
  				 + (ColTitles[pos].length() - spacesLeft + str.length()); 

	return addSpace(spacesLeft) + str + addSpace(spacesRight); 
}

public int getItemCount() {
	return lista.getItemCount();
}

public int getSelectedIndex() {
	return lista.getSelectedIndex();
}

public int[] getSelectedIndexes() {
	return lista.getSelectedIndexes();
}

public String[] getSelectedItems() {
	return lista.getSelectedItems();
}

public String getSelectedItem() {
	return lista.getSelectedItem();
}

public String getItem(int index) {
	return lista.getItem(index);
}
/*
public void sort(int pos) {
	
	loadRecords();	
	performSort(pos);
	lista.removeAll();
	for (int n=0; n < record.length; n++) {
		lista.add(record[n]);	
	}
	setVisible(true);	
}
*/
public void sort2(int pos) {
	
	loadRecords2();	
	performSort2(pos);
	lista.removeAll();
	for (int n=0; n < rc2.length; n++) {
		lista.add(rc2[n].rec);	
		System.out.println("index =" + rc2[n].index);
	}
	setVisible(true);	
}

public int getPreSortIndex(){
	return rc2[lista.getSelectedIndex()].index;
}

/*
private void loadRecords() {

    if (!LOADED) {
	    record = new String[lista.countItems()];	 
		for (int j=0; j < lista.countItems(); j++) {
			 lista.select(j);
			 record[j] =  lista.getSelectedItem();
		}
		LOADED = true;	 
    }	
}
*/
private void loadRecords2() {

	if (!LOADED) {
		rc2 = new Record2[lista.countItems()];	 
		for (int j=0; j < lista.countItems(); j++) {
			 lista.select(j);
			 //rc2[j].rec =  lista.getSelectedItem();
			 rc2[j] = new Record2(j, lista.getSelectedItem());
			 //rc2[j].setIndex(j);			
		}
		LOADED = true;	 
	}	
}

/*
private void performSort (int pos) {

  String keyNext, next, keyPrev;
  int fromByte;
  int toByte = Marker[pos];
//  boolean LAST = false;
//  if (pos == Marker.length) LAST = true; 
  	
  for (int j=0; j < record.length; j++) {
	   for (int i = j+1; i < record.length; i++) {
		  next = record[i];
		   //keyNext = record[i].substring( 0, FieldLength[0] );
		  fromByte = pos == 0 ? 0 : Marker[pos-1]; 
		  
//		  if (LAST){
		  
             keyNext = record[i].substring( fromByte, toByte);
		     keyPrev = record[j].substring( fromByte, toByte);
//		  }
//          else {
          
//		     keyNext = record[i].substring( startByte);
//		     keyPrev = record[j].substring( startByte);
//          }

		  if (keyNext.compareTo( keyPrev ) < 0) {
	          record[i] = record[j];
	          record[j] = next;	       
	       }
	   
	   }
  
  }

}
*/

private void performSort2 (int pos) {

  String keyNext, keyPrev;
  Record2 next;
  int fromByte;
  int toByte = Marker[pos];
  boolean IS_NUMERIC = false;
  
  if ( isNumeric(pos) )  
     IS_NUMERIC = true; 
  
  for (int j=0; j < rc2.length; j++) {
	   for (int i = j+1; i < rc2.length; i++) {
	 
		  //next = rc2[i].rec;
		  next = rc2[i];
	
		  fromByte = pos == 0 ? 0 : Marker[pos-1]; 
		
		keyNext = rc2[i].rec.substring( fromByte, toByte);
		keyPrev = rc2[j].rec.substring( fromByte, toByte);

		  if ( !IS_NUMERIC ) {		     
			
		  	if (keyNext.compareTo( keyPrev ) < 0) {
			   rc2[i] = rc2[j];
			   rc2[j] = next;	       
			   //rc2[i].rec = rc2[j].rec;
			   //rc2[j].rec = next;	       
		     }
		  }
		  else {
  	       try {
  	       
	         int nKeyNext = Integer.parseInt(keyNext.trim());
			 int nKeyPrev = Integer.parseInt(keyPrev.trim());
  	     
          
			 if (nKeyNext < nKeyPrev) {
				 rc2[i] = rc2[j];
				 rc2[j] = next;	       
				 //rc2[i].rec = rc2[j].rec;
				 //rc2[j].rec = next;	       
			 }
  	       } 
	       catch (NumberFormatException e) {
	       	    System.out.println("errore numerico" + j);
						IS_NUMERIC = false;
						continue;
		   }
		  }
	   }
  
  }

}


private boolean isNumeric ( int pos ) {
   for (int i = 0; i<NumericFields.length; i++) {
      if ( NumericFields[i] == pos ) return true;
   } 
   return false;
}

public void removeAll() {
  lista.removeAll();
}

public void actionPerformed( ActionEvent e ) {
	
 for (int i = 0; i<btn.length; i++){
	if( e.getSource().equals(btn[i]) ) { 
		   System.out.println(getClass().getName() + "clikkato " + i);
		   //sort(i);
		   sort2(i);
    }
 }  
}
   
}