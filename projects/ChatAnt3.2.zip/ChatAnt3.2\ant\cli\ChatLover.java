package ant.cli;

import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;



import ant.glob.Globals;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatLover extends Frame implements ActionListener {
	
	private	StringTokenizer st;
	private String listaLove;
	private ChatCliente cli;

	public ChatLover (String listaLove, ChatCliente cli, String nick)
		 {
		super("ChatLove: La tua Chat privata..");

		this.cli = cli;
		this.listaLove = listaLove;
		this.nick = nick;
		
		chatPan = new LovePanel();
		chatPan.creaFrame();
	    setSize(450, 305);	//era 400
	    //chatPan.txNick.setText(nic);	
		chatPan.txInput.addActionListener(this);

		
	int i = 1;
	String appNick;
	
	st = new StringTokenizer(listaLove, Globals.FieldSeparator);
	while (st.hasMoreTokens()) {
		appNick = st.nextToken();
		chatPan.txListTalk.add( appNick );
		
	    if (i == 1)  nickCreator = appNick; 
	    i++; 
	}   
	add(chatPan);	  
	
	show();	
			
	 addWindowListener ( new WindowAdapter() {
	 public void windowClosing(WindowEvent e) {
 		 quit();	 
	 }
	} );

	 	//botEsci.addMouseListener(
	//	new MouseAdapter() {
	//		public void MouseClicked(MouseEvent e)
	//			  { quit(e); }	
	//			}
	//);	
}



							  

	 	public void AddText( String s )
	{
		chatPan.txOutput.append( s + "\n" ) ;
	}

public void destroy() {
	this.destroy();
}










public void actionPerformed(ActionEvent e) {
	
  if ((e.getSource().equals( chatPan.txInput )) && (e.getID()==1001)) {

	  	 mess = (String) chatPan.txInput.getText();
	  	 if (mess.length() != 0) {
		  	sendString( (String) chatPan.txInput.getText() );
		 	
	     }
// ho dato invio a vuoto
  }
}













































							  


	private LovePanel chatPan;
	private ChatFrame frame;


	private String mess;


public void addChatter(String nick) {
	
	chatPan.txListTalk.add( nick );

}

public void clearChatterList() {

	chatPan.txListTalk.removeAll();
}

public void quit() {
	
	cli.frame.btnPriv.setEnabled(true);
	cli.lov = null;
	
	try {  
	    cli.SendString( Globals.LovqCommand );
	       
	} catch (IOException ex) {
	    System.out.println("ChatLover: errore su sendString");  
	    ex.printStackTrace();
	 }
	 dispose();
	 
}

public void quit(MouseEvent e) {
	
	quit();	
}

public void sendString( String mess ) {

	 try {
	  cli.SendString ( 
		  Globals.LovSpeakCommand
		  + nickCreator
  		  + Globals.FieldSeparator
  		  + nick
   		  + Globals.FieldSeparator
		  + mess );
	  
	 } catch (IOException ex) {
	   System.out.println("ChatLover: errore su sendString");  
	   ex.printStackTrace();
	 }
	  chatPan.txInput.setText ("");	
}

	private String nick;
	private String nickCreator;
}