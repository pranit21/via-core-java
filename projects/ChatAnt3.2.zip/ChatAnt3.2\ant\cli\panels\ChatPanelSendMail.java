package ant.cli.panels;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import java.io.IOException;
import ant.glob.Globals;

import ant.awt.TextDisplayField;
import ant.awt.EnterExitEnlightButton;

import ant.awt.LabLog;

import ant.cli.ChatCliente;
import ant.cli.ChatFrame;
import ant.cli.util.DataClient;
import ant.dyn.EMail;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatPanelSendMail extends Panel {
	
	private String nick;
	public LabLog labLog;	      
	private ChatCliente cliente;

public void drawPanel() {
	
	setLayout(new BorderLayout ());
	setBackground(Color.lightGray);

	Panel mainPanel = new Panel( new BorderLayout(2,2) );

	Panel mainPanel01 = new Panel( new BorderLayout(2,2) );
	  	 Label labTitle = new Label("Titolo: ");	
	     txTitle = new TextField("", 54);
	     mainPanel01.add("West", labTitle);
	     mainPanel01.add("East", txTitle);
	Panel mainPanel02 = new Panel( new BorderLayout(2,2) );
	  	 Label labTo = new Label("To: ");	
	     txTo = new TextField("", 54);
	     mainPanel02.add("West", labTo);
	     mainPanel02.add("East", txTo);

	Panel mP1 = new Panel( new BorderLayout() );
	mP1.add("North", mainPanel01 );
	mP1.add("South", mainPanel02 );

	txMsg = new TextArea("", 2,1, TextArea.SCROLLBARS_VERTICAL_ONLY);		        
	txMsg.setName("MsgInput");
	txMsg.setFont(new Font("Mia", Font.PLAIN, 12));
	txMsg.setBackground(Color.darkGray);
	txMsg.setForeground(Color.white);
	txMsg.setEditable(true);
	//add("Center", txMsg);

//	mainPanel.add ("North", mainPanel01);
	mainPanel.add ("North", mP1);
	mainPanel.add ("Center", txMsg);
	add("Center", mainPanel);
	 
	txListTalk = new java.awt.List();
	txListTalk.setBackground(java.awt.Color.blue);
	txListTalk.setFont(new Font("Mm", Font.PLAIN, 12));
	txListTalk.setBackground(Globals.CruscottoColor);
	    add("East", txListTalk);
	loadListDest();    

	txListTalk.addMouseListener( new MouseAdapter() { 
	      public void mouseClicked( MouseEvent e ) {
		    setTxTo();  
		    //txTo.setText(txListTalk.getSelectedItem());  
		  }
	   }
	  );


	Panel p0 = new Panel( new BorderLayout() );
	add ("South", p0);

	TextDisplayField labLog = new TextDisplayField("... Scrivi il messaggio" );
	p0.add("North", labLog);

	Panel p1 = new Panel( new GridLayout(1,2) );
	p0.add("East", p1);
	
	EnterExitEnlightButton botOK =  
	       new EnterExitEnlightButton("Send");
	botOK .setBackground(Globals.CruscottoColor);
	p1.add( botOK );
	
	botOK.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		  onSendMail(txMsg.getText());
	       }
	} );

//	Button botCanc = new Button("Cancel");
//	p1.add( botCanc );
	
/*	botCanc.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		  onCancel();
	       }
	} );
*/
	setVisible(true);
	//toFront();
	//show();
	}





	private Button botOK;
	ChatFrame frame;
	String[] listaDest;
	private String nickDestinatario, nickMittente;
	public java.awt.List txListTalk;
	public TextArea txMsg = null;

                           

public void loadListDest() {
	
  DataClient dtCli = new DataClient();
  dtCli.loadListFromString( RegistredNickList, txListTalk);

}



public void onCancel()  {

   frame.onBackFromMessage();
	
}
	String RegistredNickList;	
	public TextField txTitle, txTo;	
	public ChatPanelSendMail(ChatFrame frame, String RegistredNickList, String nick) {
	
	this.RegistredNickList = RegistredNickList;
	this.frame = frame;
	this.nickMittente = nick;
		
	drawPanel();

   }   
 private String formatDate(int num) {

  return (num < 10) ? '0' + String.valueOf(num)
					:  	String.valueOf(num);
}
public String getSystemDate()  {

	Calendar cal = Calendar.getInstance();
	Date tempo = cal.getTime();
	return	
		   formatDate( cal.get(Calendar.DATE) ) 
	     + "/"
	     + formatDate( (1+(cal.get(Calendar.MONTH))) )
	     + "/"
	     + formatDate( cal.get(Calendar.YEAR) )
	     + " :: "
	     + formatDate( cal.get(Calendar.HOUR_OF_DAY) )
	     + ":"
	     + formatDate( cal.get(Calendar.MINUTE) );	
}

public void onSendMail(String msg)  {

  try {

	StringTokenizer st = new StringTokenizer( txTo.getText(), ";" );

	while (st.hasMoreTokens()) {
	  
	 EMail eml = new EMail(
	     nickMittente, 
	     st.nextToken(), 
	     txTitle.getText(), 
	     txMsg.getText(),
	     getSystemDate() 
	 );
	 frame.cli.sendObject(eml);
   }
  }
 
  catch (IOException ex) {
	   System.err.println(getClass().getName() + "errore su onSendMessage");
   	   ex.printStackTrace();
   }
   frame.onBackFromMessage();
}

public void setTxTo()  {

   String app = txTo.getText();
   app += txListTalk.getSelectedItem() + ';';	
   txTo.setText(app);  	
}
}