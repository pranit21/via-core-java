package ant.cli.ftp;
import java.net.*;
import java.io.*;

import ant.cli.panels.ChatFinListaFile;
import ant.cli.video.AntVideoFrameGrabbing;
import ant.dyn.RegistroDownload;

import ant.awt.LabLog;

import java.awt.Component;
import ant.awt.PanelMesg;

import java.awt.Image;

import javax.media.*;
import javax.media.format.*;
import javax.media.util.*;
import javax.media.control.*;
import javax.media.protocol.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import com.sun.image.codec.jpeg.*;
import javax.imageio.stream.*;


public class CopyOfReceiveImageServer extends Thread {

	int numBytes;
	protected BufferedInputStream iStream;
	protected BufferedOutputStream oStream;
	public Thread thread;

	public Socket client;
	public String nomeFile;
	public String nickDonatore;
	public RegistroDownload regdow;

	public ServerSocket server;
	private LabLog labLog;
	private Component MesgValues =
		 new PanelMesg( "Download successful !", PanelMesg.ModeInfo );
	public ChatFinListaFile parent;

	private RegistroDownload listaFiles;

public void run()  {

 try {

 server = (server == null) ? new ServerSocket(9990) : server;	
 
 System.out.println ("ReceiveImage, in attesa di connessioni !");
 client = server.accept ();
 System.out.println ("ReceiveImage, donatore : " + client.getInetAddress ());

 
  //BufferedInputStream in = new BufferedInputStream( client.getInputStream ());
  DataInputStream iStream = new DataInputStream( client.getInputStream () );
  ByteArrayOutputStream oStream = new ByteArrayOutputStream();

 
  //------------- ok (*)
  //byte buf[] = new byte[ numBytes ]; OK
  //----------------------------
  int BufferSize = 2048;  
  byte buf[] = new byte[ BufferSize ];  
  int n;
  int totBytes=0;

/* OLD OK (*)
	while ( ( n = iStream.read( buf, 0, numBytes ) ) != -1 ) {
	  totBytes += numBytes;
	}
*/

while ( ( n = iStream.read( buf, 0, BufferSize ) ) != -1 ) {
	//	  oStream.write( buf );
  oStream.write( buf, 0, n );
  totBytes = totBytes + BufferSize;
  
}

	//oStream.close();
	iStream.close();
	System.out.println("------ receiveImage : ricevuti byte : "+totBytes);
	
	
    //java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit(); 
    //Image img = tk.createImage(buf);
	//System.out.println("------ receiveImage : immagine creata !");
    
	 
	//------------------------------------    
	//0k	(*)
	//ByteArrayInputStream stream = new ByteArrayInputStream(buf);
	//BufferedImage bufImg  = javax.imageio.ImageIO.read(stream);
   //--------------------------------------
   byte[] buf2 = oStream.toByteArray();
   oStream.close();
   ByteArrayInputStream stream = new ByteArrayInputStream(buf2);
   BufferedImage bufImg  = javax.imageio.ImageIO.read(stream);
   //AntVideoFrameGrabbing.saveJPG(bufImg,"c:\\myVideoCapture99.jpg");
  
  //apre il pannello per visualizzare l'immagine 
   //ant.cli.video.ShowImageGrabbedPanel pan = 
     // new ant.cli.video.ShowImageGrabbedPanel(bufImg);
 

 } catch (java.net.BindException ex) {
 	     ex.printStackTrace();
	     //labLog.setText("..Attendere: up/downLoading in corso sul tuo PC");
	  	 //labLog.setColor(java.awt.Color.pink);

 } catch (Exception ex) {
	     System.out.println ("ReceiveImage: errore ricezione dati: ");
		 ex.printStackTrace ();
 }

 if (null != client) {
   System.out.println( "------ ReceiveImage: Chiudo la connessione con "+client.getInetAddress() ) ;
   try {
	  client.close ();
	  }
   catch (IOException e) { 
	  System.out.println( "ReceiveImage: errore close socket " + e.getMessage() );
	  e.printStackTrace();
	  }
 }

try {
  if ( server != null )  server.close();
  thread = null;
  interrupt();
  } 
catch (IOException e) {
  System.out.println( "ReceiveImage: errore close socket " +e);
  }

}

public void start () {

	if (thread == null) {
		thread = new Thread(this);
		thread.start();
	}

}     	 	 	 	 	 	 	 


public CopyOfReceiveImageServer(String nomeFile, ChatFinListaFile parent) 
   throws IOException {
	   
	  this.nomeFile = nomeFile;
	  this.parent = parent;
   }                     

 public CopyOfReceiveImageServer(int numbytes) 
	  throws IOException {
	  this.numBytes = numbytes; 
 }  

public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}

public static void saveJPG(Image img, String s)
{
  BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
  Graphics2D g2 = bi.createGraphics();
  g2.drawImage(img, null, null);

  FileOutputStream out = null;
  try
  { 
	out = new FileOutputStream(s); 
  }
  catch (java.io.FileNotFoundException io)
  { 
	System.out.println("File Not Found"); 
  }
    
  JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
	
  JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bi);
  param.setQuality(0.5f,false);
  encoder.setJPEGEncodeParam(param);
    
  try 
  { 
	encoder.encode(bi); 
	out.close(); 
  }
  catch (java.io.IOException io) 
  {
	System.out.println("IOException"); 
  }
}
  

}