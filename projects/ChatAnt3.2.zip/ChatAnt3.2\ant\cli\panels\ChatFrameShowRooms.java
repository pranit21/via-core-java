package ant.cli.panels;
import java.awt.Frame;
import java.awt.Rectangle;

import java.awt.Color;
import ant.glob.Globals;
import java.awt.*;
import java.awt.event.*;
import ant.awt.Table;

import ant.cli.ChatFrame;
import ant.cli.util.DataClient;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatFrameShowRooms extends Frame implements ActionListener {

  private Frame owner;   // see validate()
  Button insButt;
  String[] Intestazioni = 
      {"Titolo Room", "Users", "N.accessi", "Data scadenza" };
  Button koButt;
  Label labTit;
  Button okButt;
  Panel pIns;
  Panel pNewTitle;
  Panel pOK;
  Table tab;
  private ChatFrame chatFrame;
  private DataClient dataCli;
  private TextField txTitle;





public void validate() {

  Rectangle parentBounds = owner.getBounds();  // getOwner() throws SecurityException
											   // in Applet
  Rectangle myBounds = super.getBounds();
  myBounds.x = parentBounds.x + ( parentBounds.width  - myBounds.width  ) / 2;
  myBounds.y = parentBounds.y + ( parentBounds.height - myBounds.height ) / 2;
  if ( myBounds.x < 0 ) myBounds.x = 0;
  if ( myBounds.y < 0 ) myBounds.y = 0;
  setBounds( myBounds );
  super.validate();
}


public ChatFrameShowRooms( Frame owner, String title, boolean modal ) {
	
  //super( owner, title, modal );
  this.owner = owner;
   
/*  setBackground( Color.lightGray );  
  setForeground( Color.black );

  tab = new Table( Intestazioni );
  tab.setBackground( Globals.CruscottoColor );
	    
  //ScrollPane content = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED );
  Panel content = new Panel();
  content.add(tab);
*/		
  //dataCli.updateRoomTabList( tab );

/*	
   pIns = new Panel();
	  pIns.setForeground( owner.getForeground() );
	  insButt = new Button( "Aggiungi" );
	  insButt.addActionListener( this );
						
	  pIns.add( insButt ); 
  tab.add( pIns, BorderLayout.SOUTH );
	
  add( content );
  
  addWindowListener( WindowLstn );
  
  setResizable( true );
  show();
  pack();
 */  
}

public void actionPerformed( ActionEvent e ) {

//---------------- asteriscare per la versione TRIAL	
	if (e.getSource().equals(insButt)) 
	  onNewRoom();
	if (e.getSource().equals(okButt)) 
			onConfirm();
	if (e.getSource().equals(koButt)) 
			onCancel();
//	---------------- asteriscare per la versione TRIAL	
			
}

  private WindowAdapter WindowLstn = new WindowAdapter()  {
	  
	public void windowClosing( WindowEvent e ) {
		
	  dispose();
	}
  };

public void updateRows(DataClient dataCli) {
	
	  setBackground( Color.lightGray );  
	  setForeground( Color.black );

	  tab = new Table( Intestazioni );
	  tab.setBackground( Globals.CruscottoColor );
	    
	  //ScrollPane content = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED );
	  Panel content = new Panel();
	  content.add(tab);

	dataCli.updateRoomTabList( tab );			

	
	pIns = new Panel();
		pIns.setForeground( owner.getForeground() );
		insButt = new Button( "Aggiungi" );
		insButt.addActionListener( this );
						
		pIns.add( insButt ); 
	tab.add( pIns, BorderLayout.SOUTH );
	
	add( content );
  
	addWindowListener( WindowLstn );
  
	setResizable( true );
	show();
	pack();
}

public void onCancel() {
	
	tab.remove(pOK);
	tab.remove(labTit);
	tab.remove(txTitle);
	tab.add(pIns);

	setSize();
}

public void onConfirm() {
	
	chatFrame = (ChatFrame)owner;
	chatFrame.onNewRoom( txTitle.getText() );
	dispose();
}

public void onNewRoom() {

	tab.remove(pIns);
	  labTit  = new Label(  "Titolo : " );
	  tab.add( labTit );
	  txTitle = new TextField(30);//new Font( "dialog", Font.BOLD, 10 );
	  txTitle.setFont(new Font("dialog", Font.BOLD, 14));
	  txTitle.setForeground(Globals.CruscottoColor);
	  tab.add( txTitle, BorderLayout.EAST );     

	
	pOK = new Panel();
	  pOK.setForeground( owner.getForeground() );
	  okButt = new Button( "OK" );
	  okButt.addActionListener( this );

	  koButt = new Button( "CANCEL" );
	  koButt.addActionListener( this );
						
	  pOK.add( okButt );
	  pOK.add( koButt );
   tab.add( pOK, BorderLayout.SOUTH );

   setSize();
}

public void setSize() {
	
//	setSize(450,350);
   //Rectangle rct = new Rectangle();
   //rct = tab.getBounds();

//   Dimension dim = tab.getPreferredSize();
//   Rectangle rect = tab.getBounds();
   //setSize( rct.getSize() );
//   setSize( dim );
   show();
   pack();
}
}