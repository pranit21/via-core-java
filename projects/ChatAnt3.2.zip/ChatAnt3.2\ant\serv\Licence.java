package ant.serv;

import java.io.Serializable;
import ant.glob.Globals;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class Licence implements Serializable {
	
	
   protected final static long EXPIRATION = Globals.GG * 30 ;
   //public static  long EXPIRATION = Globals.UN_MINUTO ;
   protected static int MAX_USERS = Globals.MAX_USERS;
   private long CalculatedExpir;   
   private boolean Expired = false;   
   private long LastModified = 0;   
   private int Max_Users;   
   private int primoLancio = 0;
   private long Now;

public Licence() {
	   super();
   }
    
/*public Licence(int primoLancio, long expiration) {
	
	this.primoLancio = primoLancio;
	this.expiration = expiration;
}
*/

public long getExpiration() {
	return CalculatedExpir;
}

public long getLastModified() {
	
	return LastModified;
}

public int getMax_Users() {
	return Max_Users;
}

public int getPrimoLancio() {
	return primoLancio;
}

public boolean isExpired() {
	return Expired;
}

public void setExpiration(long Expiration) {
	CalculatedExpir = Now + Expiration;
	double minuti=Expiration/1000/60;
	int giorni = (int) minuti/60/24;
	System.out.println("----> Expiration minuti: " + minuti);
	System.out.println("----> Expiration giorni: " + giorni);
}

public void setExpired(boolean newExpired) {
	Expired = newExpired;
}

public void setLastModified (long LastModified) {
	
	this.LastModified = LastModified;
}

public void setMax_Users (int Max_Users) {
	
	this.Max_Users = Max_Users;
}/**
 * Inserire qui la descrizione del metodo.
 * Data di creazione: (01/04/03 17.58.37)
 * @param newPrimoLancio int
 */
public void setPrimoLancio(int newPrimoLancio) {
	primoLancio = newPrimoLancio;
}


/**
 * @param l
 */
public void setNow(long l) {
	Now = l;
}

}