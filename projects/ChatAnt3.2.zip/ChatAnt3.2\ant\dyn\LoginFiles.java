package ant.dyn;
import java.io.Serializable;
import ant.glob.Globals;


/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class LoginFiles implements Serializable {
	

	protected ChatDirList dir;
	protected String[] listaFiles;

	protected FileRecord[] record;
	protected String nick;

public LoginFiles(String nick) {

   this.nick = nick;
   dir = new ChatDirList(Globals.DirMieiFiles);
   //listaFiles = addLung( dir.getList(), dir.getListLung() );
   creaRecordFiles( dir.getList(), dir.getListLung() );
}

public LoginFiles() {


}

public String[] getListaFiles() {
   return listaFiles;
}

public String getNick(){
		return nick;
}



public void creaRecordFiles (String[] lista, String[] listaLung) {

 record = new FileRecord[ lista.length ];
 for (int i = 0; i<lista.length; i++) 
	record[i] = new FileRecord( lista[i], listaLung[i] );
}

public FileRecord[] getRecordFiles() {
   return record;
}
	private String soloperprova;//private String driveFileSharing;

}