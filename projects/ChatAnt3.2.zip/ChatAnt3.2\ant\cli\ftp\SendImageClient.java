package ant.cli.ftp;

import ant.awt.LabLog;

import java.net.*;
import java.io.*;

import ant.cli.video.AntVideoFrameGrabbing;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
/**
 * 
 * @author A.Formiconi
 * esegue "l'upload". Legge un file e lo manda in DataOutptupStream 
 *
 */
public class SendImageClient extends Thread {
	private boolean DEBUG = true;
	Thread thread;
	private InetAddress address;	 	 	
	private int porta;
	private String str;
	private String nick;
	private Socket server ;
	private String nomeFile;
	private LabLog labLog;
	private boolean toRepository = false;
	private byte[] imageBytes;
	AntVideoFrameGrabbing grabber;
	boolean Stop;
	
public SendImageClient ()

		throws IOException {

}

public void destroy() {
	super.destroy();

	// inserire qui la codifica per il rilascio delle risorse
}

public void run() {
		
	DataOutputStream oStream=null; 		
	try {
		sleep(2000);
	} catch (InterruptedException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	Socket server=null;
	try {
		server = new Socket ( address, 9990 );

	if (DEBUG) System.out.println("---- SendImageGrabbedClient, socket eseguito"); 
    	 
	//BufferedOutputStream out = new BufferedOutputStream(server.getOutputStream());	
	//DataOutputStream oStream = new DataOutputStream(out);
	
	//alternativa
	//oStream = new DataOutputStream(server.getOutputStream());	
	
	} catch (IOException e2) {
		e2.printStackTrace();
	}
	//int BufferSize = imageBytes.length;	
    
	int n;
	  
	//sincronizzare imageBytes
	
 try {
 	
	while (Stop == false) {
     
      	 	
      	oStream = new DataOutputStream(server.getOutputStream());
      	if (DEBUG) System.out.println( "SendImageGrabbed: apro output Stream");

      	//-------------- Parto quando l'immagine � pronta ----------------
      	
      	if (DEBUG) System.out.println( " * ATTENDO * SendImageGrabbed: attendo immagine");
      	
      	synchronized (grabber.stateLock) {
      	   grabber.getStateLock().wait();
      	}   
      	//grabber.waitForState();

      	if (DEBUG) System.out.println( " * PRONTA IMMAGINE * SendImageGrabbed");	
      	imageBytes = grabber.getImageBytes();
      	//---------------------
      	 
      	int BufferSize = imageBytes.length;
      	if (DEBUG) System.out.println("---- SendImageGrabbedClient ottengo immagine da spedire "+BufferSize); 
      	
      	//------------SEND---------
      	oStream.write(imageBytes,0,BufferSize);
      	if (DEBUG) System.out.println("---- SendImageGrabbedClient, immagine spedita!!");	
		oStream.close();
		//---------------------
		if (DEBUG) System.out.println( "SendImageGrabbed: chiudo output Stream");
		
		//Thread.sleep(5000);	
		server = new Socket ( address, 9990 );
		
	} 
	

   } catch ( IOException e ) {
      	System.out.println( "SendImageGrabbed: errore socket "+e );
      	e.printStackTrace();
      	interrupt();
      	thread.interrupt();
      	//break;
   } catch (Exception ex) {
      	System.out.println ("SendImageGrabbed : errore apertura socket :"+ex);
      	ex.printStackTrace();
      	//break;
   } finally {		  	 
		if (null != server) {
			try {
				System.out.println( "---------------SendImageGrabbed: chiudo il socket");
				interrupt();
				thread.interrupt();
				thread = null;		
				server.close (); 
				
				
			}
			catch (IOException e) {
				System.out.println( "----------------SendImageGrabbed: errore chiususra socket " + e);
				interrupt();
				thread = null;		
			}
			//System.out.println( "FtpClient: Chiudo la connessione con "+ server.getInetAddress() ) ;
		}
  }
}

public void start() {
	if (thread == null){
		thread = new Thread(this);
		thread.setDaemon(true);
		thread.start();
	}
 }           
		
 public SendImageClient (byte[] imageBytes, InetAddress address)
	throws IOException {

	    this.address = address;
		this.imageBytes = imageBytes;
}     

 public SendImageClient (
 		AntVideoFrameGrabbing grabber, InetAddress address)
 		throws IOException {

 	this.address = address;
 	this.grabber = grabber;
 }     
             
public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}


}