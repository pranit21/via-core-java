package ant.glob;

import java.awt.Color;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public interface Globals {

//   PORTE
	public static final int PortaVoice_NO_MIC = 5008;
	//Video Conferencing 
	public static final String ConferencingLocalDataPort = "64433"; //Video 
	public static final String ConferencingLocalDataPortAu  = "62233"; //Audio
	public static final String ConferencingReceiverPort  = "65533"; //Audio
	public static final String ConferencingReceiverPortAu    = "63333"; //Audio
	
 // disasteriscare per la versione TRIAL
 // public static final  int MaxUsers = 0x1B; //27 (-25=2)
 //
 public static final  int MAX_USERS = 3; //27 (-25=2) 
 public static final  int Max_Faces = 20;
 public static final int MAX_IMG = Max_Faces +2;
 public static final String VERSION = "3.2"; 

//	-------------------------------
// scadenze : RoomBuster.setProductExpiration
   //	1 ora     = 3.600.000
   //   8 ore     = 28.800.000
   //   1 gg      = 86.400.000
   //   30 gg      = 2.592.000.000
   public static final long GG = 86400000;
   public static final long UN_ORA =3600000;
   public static final  long OTTO_ORE = 28800000;  
   public static final  long ANNO = 31536000000L; 
    
// --- protocollo da usare per il send dei pacchetti per VoIP
//     valori : IP | UDP
   public static final String VoIP_Protocol = "UDP";     
//-------------------------------	
  public static final Color OutputColor = new Color(225,201,244);
  public static final Color OutputColor2 = new Color(201,201,244);
  //public static final Color Parlatori2Color = new Color(231,246,223);
  public static final Color ParlatoriColor = new Color(219,248,202);	
  public static final Color ParlatoriColor2 = new Color(196,251,226);
  public static final Color VocalChatColor = new Color(196,251,226);
  public static final Color CruscottoColor = new Color(0,159,222);	
  public static final Color CruscottoForeColor = new Color(245,23,169);	
  public static final  String NullCommand =          new String("");
  public static final  String HelpCommand = 		 new String("HELP");
  public static final  String ListaFileCommand = 	 new String("LIFF");
  public static final  String LovSpeakCommand =	  new String("LOV1"); //ridireziona su ChatLove
  public static final  String LovqCommand = 		 new String("LOVQ");
  public static final  String LovLoginCommand =	  new String("LOVV"); //richiesta di apertura ChatLove
  public static final  String QuitCommand = 		 new String("QUIT");
  public static final  String RoomExpiredCommand =  new String("INHT");

  public static final  String RiceviBufferCommand = new String("FIL0");
  public static final  String RepositoryCheckCommand = new String("RPCK");
  public static final  String RepositoryUpload = new String("RPUL");
  public static final  String WakeCommand = 		 new String("WAKE");
  public static final  String NumUserCommand = 	  new String("NUMUT");
  public static final  String UPD_LOVE_LIST = 		 new String("L0000"); 
  public static final  String MsgSeparator =      new String(" ==> ");

// -------- vocal
   //public static final  String VocalBusyCommand =  new String("S3BS");
   //public static final  String VocalRefusedCommand =  new String("S4BS");
   public static final  String StartDoubleWayCallCommand  = new String("S2WC");
   public static final  String StopCallCommand  = new String("STCL");  
   public static final  String StopCallCommandGSM  = new String("STCLGSM");
   public static final  String StartSingleWayCallCommand  = new String("S1WC");
   public static final  String ImageGrabbedSendCommand   = new String("IMGG");
   public static final  String StartVideoCommand   = new String("VID2");
   
//---------------- rooms
  public static final  String RoomSpeakCommand =  new String("ROOMSP1");
  public static final  String RoomQuitCommand  =  new String("ROOMQUIT");
  public static final  String RoomLogCommand   =  new String("ROOMLOG");	
  public static final  String NewRoomCommand   =  new String("ROOMNEW");	
  public static final  String RoomUpdateListCommand = 	 new String("ROOMUSR");
  public static final  String RoomUpdStatistiche = 	 new String("ROOMSTA");
  public static final  String UPD_MAIN_LIST = 		      new String("A0000");  

 public static final  String RoomTitleCommand =          new String("ROOMTITLE");
 public static final  String SendGIFCommand =  new String("F0001");
 public static final  String RoomCommand  =	     new String("ROOM"); //ridireziona su ChatLove

//-----------------generali
//public static final  int MaxRooms = 20;
 public static final  int ServerRooms = 8; //serve al processo roomBuster
 public static final String StaticRoomDataCreation = "10/10/2003";

 //public static final  int MaxNumFiles = 15;
 public static final String FieldSeparator = "|";
 public static final String NewRecord = "$";
 public static final String NickNonImpostato = "unknown nick";

 //------------ diagnostici ------
 public static final String Diagn[] = {
 			/*0*/	"Attenzione: il tuo nick � gi� stato preso da qualcun altro !",
 			/*1*/	"Attenzione: per accedere alla chat digita : 'nick' + spazio + <tuonome>",
			/*2*/	"Seleziona almeno una stanza",
			/*3*/	"Hai una conversazione privata in corso." + '\n' + "Chiudila prima di uscire dalla Chat !",
			/*4*/	"La funzione � consentita solamente nella versione stand-alone scricabile dal sito",
			/*5*/	"Seleziona almeno un nick dalla lista..",
			/*6*/	"Il tuo intervento � stato corretamente inserito sul Forum !",		
			/*7*/	"Collegamento non riuscito, il server non � stato attivato",
			/*8*/	"Collegamento ottenuto con ChatAnt !!!",
			/*9*/	"Per consultare il Forum aprire il browser e collegarsi all'indirizzo del server web",
			/*10*/	"acquista ChatAnt su www.chatant.com potrai personalizzare questo software",
			/*11*/	"La licenza � scaduta, acquista ChatAnt. Collegati a www.chatant.com, usufruirai di tutti i servizi di assistenza. Grazie",
			/*12*/	"Questa funzione � disabilitata nella versione gratuita. Scrivi a info@chatant.com o collegati a www.chatant.com per informazioni.",
			/*13*/	"Selezione errata: hai incluso te stesso nella chat privata",
			/*14*/	"Non puoi chattare in privato con te stesso",
			/*15*/	"Questo nick � gi� stato registrato!",
			/*16*/	"Benvenuto tra gli utenti registrati di ChatAnt",
			/*17*/	"..Contento, C'� posta per te!",
			/*18*/	"..Sorry! Nessun nuovo messaggio per te!",
			/*19*/	"Non ti sei ancora registrato su ChatAnt!",
			/*20*/	"Password errata",
			/*21*/	"Digita l\'IP del Server la porta di connessione su \'Connect\'",
			/*22*/	"Chiamata vocale in arrivo per te!",
			/*23*/	"Sistema occupato, se l\' errore si ripresenta resettare il PC",
			/*24*/	"Chiamata rifiutata, interrompi il collegamento",
			/*25*/	"L'utente � occupato, interrompi il collegamento",
			/*26*/	"Numero massimo di utenti raggiunto per la versione trial",
 			/*27*/	"JMF non risponde propriamente, controllare l'installazione",
 			/*28*/	"Il servizio pu� essere terminato solo dal chiamante"
			
};
 public static final String DiagnCommand = new String("D000");
 public static final String DuplicateNick = "D0000";
 public static final String BlankNick = "D0001";
 public static final String VocalRefusedCommand = "D00024";
 public static final String VocalBusyCommand = "D00025";
  //----------------colors
  public static final Color ARANCIO = new Color(15,220,202);
  //public static final  String PropertyPath = "c:/ChatProperties/";
 
  public static final Color GRIGETTO = new Color(127,119,120);
  public static final Color VIOLETTO = new Color(228,212,242);
  public static final  String RoomGIFCommand               = new String("ROOMGIF");
  public static final String DirGIFApplet = "images/";
  public static final String DirGIF = "images";
  public static final String DirSounds = "sounds";
  public static final String DirMieiFiles = "MieiFiles";
  public static final String DirRepository = "Repository"; 
  public static final  String PrivateChatRequestCommand    = new String("A00PC"); //ridireziona su ChatLove 
  public static final  String ChatLoginCommand             = new String("NICK");
  public static final  String CloseWindowCommand           = new String("ROOMCLS");
  public static final String  ReceiveMsgCommand  = new String("A00RM");
  public static final  String ReceiveWakeCommand   =	 new String("A00WK");
  public static final  String RewMainCommand = 		 new String("REW1");
  public static final  String RewRoomCommand = 	  new String("ROOMREW"); 
  public static final  String SendMsgCommand = 		 new String("SDMG");
  public static final  String SwitchRoomCommand = new String("ROOMSWC");
  public static final  String ForumTitleRequestCommand =  new String("FORUTITLE");  
 
 //----------------server
 //public static final  String PropertyForum = "Forum.property";  
 public static final  String PropertyForumFile = "Forum.props"; 	 
 public static final  String ServerProperty = "Server.props"; 	 
 public static final  String ServerLicenceConfigFile = "serv-config.cfg";
  
  public static final Color Bordeaux = new Color(128,0,0); 
  public static final  String ChatForumDir = "ChatForum";  
  public static final  String ChatLoginRegisterCommand     = new String("NICKREG");  
  public static final  String ChatLoginYetRegistredCommand = new String("NIKYREG");  
  //--------------- client
  public static final  String ChatProperties = "ChatProperties"; 
  public static final  String CheckMyMailCommand  =	     new String("MLCHCK");
   public static final  String DeleteMailCommand  =	     new String("DLTMLS");  
   public static final  String FileForumRequestCommand =	  new String("REFO1");  
   public static final Color GRIGETTO2 = new Color(219,215,215); 
   
   //diagnostici provenienti dal server
   public static final String MailForYou = "D00017"; 
   public static final String NewRegistredNick = "D00016"; 
   public static final String NoMailForYou = "D00018"; 
   public static final String NotRegistredNick = "D00019"; 
   public static final String PasswErrata = "D00020"; 
   public static final String YetRegistredNick = "D00015"; 
    
   public static final  String RefreshFileListCommand =	 new String("REF22"); //al refresh dei file     
   public static final  String RegistredNickListCommand =  new String("UPDRN");  
   public static final  String UdpFileListCommand = 		 new String("UPD22");  
   public static final Color Verdino = new Color(0,128,128);  
   public static final Color ViolaScuro = new Color(128,0,128); 
      
}