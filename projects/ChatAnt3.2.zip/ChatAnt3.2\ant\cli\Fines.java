package ant.cli;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import ant.glob.Globals;
import ant.awt.AntGridPanel;
import ant.awt.ClickableGIF;

import ant.awt.TextDisplayField;
import ant.awt.FacesPanel;

import ant.awt.CentrDlgBase;
import ant.cli.forum.ChatPanelForum;
import ant.dyn.ForumRec;


import java.io.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
class Fines extends Frame implements MouseListener {

	private java.awt.List files = new java.awt.List();
	private String listaFile = null;

	private String nick;
	//LightProgressBar bar = new LightProgressBar(127);


public static void main (String[] args) {

  Fines f = new Fines();

}

public void mouseClicked(MouseEvent e)  {




	if  (e.getComponent() == bot) {
		dispose();
	}
}
	public void mouseEntered(MouseEvent e) {

	}
	public void mouseExited(MouseEvent e) {

	}
	public void mousePressed(MouseEvent e) {

	}
	public void mouseReleased(MouseEvent e) {
		//System.out.println("mouseReleased");
	}
/**
 * Inserire qui la descrizione del metodo.
 * Data di creazione: (25/04/02 23.43.16)
 */


	private Button bot, bot1;

	public Fines() {
		//super("ChatAnt: Avviso di chiamata per te..");

		setLayout(new BorderLayout ());
		String userDir=System.getProperty("user.dir");	
		Image appImg = Toolkit.getDefaultToolkit().getImage(
				   //Globals.DirGIF + "f" + i + ".gif" );
					  userDir 
					  + File.separator
					  + Globals.DirGIF 
					  + File.separator 
					  + "Bird.gif" );
		System.out.println(userDir 
							  + File.separator
							  + Globals.DirGIF 
							  + File.separator 
							  + "bird.gif");
		ClickableGIF gif1 = new ClickableGIF(appImg);

  	  Panel dxDow = new Panel();
		dxDow.setLayout(new FlowLayout());
		//dxDow.setSize(75,115);	    
	
		java.awt.List listRooms = new java.awt.List(6);
		listRooms.add("cinema");
		listRooms.add("cultura");
		listRooms.add("teatro");
		//listRooms.setSize(45,45);
		listRooms.getPreferredSize();
		listRooms.setFont(new Font("Mm", Font.ITALIC, 10)); 
		listRooms.setBackground(java.awt.Color.cyan);
		dxDow.add(listRooms);

		MenuBar mb = new MenuBar();
		Menu men = new Menu("cglioni");
		men.add("uno");
		men.add("due");
		men.add("tre");
		mb.add(men);
		setMenuBar(mb);

		//dxPan0.add(dxDow);
		gif1.setSize(20,20);
		add(gif1);
		
		//add(bar);
		

		//openExplorer();

	
		//runn.start();
		setVisible(true);
		toFront();
		setSize(200,200);
		show();

	//	updateBar();
   }                                                               


public void openExplorer() {

	String drive = "C:";
	String sep = File.separator;
	
	String path= "Programmi"
	    + sep + 
	    "Internet Explorer" + sep + 
	    "IEXPLORE.exe c:/aa.htm";

	File fi = new File(drive+sep+path);
//    if (!fi.exists()) {
//							drive = "D:";
  try {
		Process p=Runtime.getRuntime().exec(drive+sep+path);
		BufferedReader in=new BufferedReader(new InputStreamReader(p.getInputStream()));
//		PrintWriter out=new PrintWriter(p.getOutputStream(),true);
		String response=in.readLine();
	//		if (response.indexOf("error=2") == 0) //Errore
	//		{
	 
		    System.out.println(response);
//			out.println("n");
			in.close();
//			out.close();
		}
			catch (java.net.UnknownHostException x2) {
			//mbox= new javaCenterMSGBox(null, "ERRORE", "Failed to find host - " + m_mailhost +  "- "+ x1.toString());
			System.out.println(x2.getMessage());
		}
			catch (IOException x1) {
		   //mbox= new javaCenterMSGBox(null, "ERRORE", "Failed to find host - " + m_mailhost +  "- "+ x1.toString());
			System.out.println(x1.getMessage());
		}


		
}

public void updateBar() {

	try {
  for (int num =0; num<10000; num++){
	  Thread.sleep(10);
	  //bar.setValue(num);
  }
	}
  catch (InterruptedException e) {}
}
}