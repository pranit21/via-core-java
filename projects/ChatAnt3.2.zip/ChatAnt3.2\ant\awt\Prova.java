/*
 * Created on Nov 23, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.awt;

import java.awt.*;
import ant.cli.util.Ringer;
import ant.glob.Globals;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class Prova extends Frame {

	int[] cols = {24, 12, 5, 13}; //file(55), lungh, freccetta, owner	
	
//	private FormattedList files = new FormattedList(cols);
	String[] titoli =  {"File", "Lungh", "-->", "Owner"};
	
	int[] numericFields = {1}; //posizione dei neumerici -1
	
	private FormattedListPanel files = 
           new FormattedListPanel(cols, titoli, 
           numericFields, Color.gray, Globals.VIOLETTO, "");


	public static void main(String[] args) {
		
		Prova p = new Prova();
		
		
		System.out.println("2222");
		p.draw();
		p.show();
		//p.sendDiagn( "Provina", "21");
		//p.startRing();
		
	}
	
	
	public void draw() {
		
	//	Panel p0 = new Panel( new BorderLayout() );
	
		files.removeAll();
			files.setBackground(Color.lightGray); 
			//files.setSize(dim.width, dim.height -50); //-50 perch� sotto c'� il pannello del bottone
			//files.setSize();
			
	//		p0.add ("Center", files);
	//	add(p0);
	//files.setSize(200,200);

      String arr[] = {"ioioi", "23456", "--", "fgkfglfk"};
	  String arr2[] = {"boioi", "457", "--", "fgkfglfk"};
	  String arr3[] = {"zoioi", "12545", "--", "fgkfglfk"};
	   
      
	  files.add(arr);
	  files.add(arr2);
	  files.add(arr3);
	  files.add(arr);
	  files.add(arr2);
	  //add(files);
	  Panel mainPanel = new Panel( new BorderLayout() );

//	  Panel mainPanel01 = new Panel( new BorderLayout(2,2) );
	  
//		   mainPanel01.add("North", messageList);

	  Panel mP1 = new Panel( new BorderLayout() );
	  //mP1.add("Center", mainPanel01 );
	  
	  mP1.add("North", files );
	 
	
	  TextArea txMsg = new TextArea();		        
	  txMsg.setName("MsgInput");
	  txMsg.setFont(new Font("Mia", Font.PLAIN, 12));
	  txMsg.setBackground(Color.darkGray);
	  txMsg.setForeground(Color.white);
	  txMsg.setEditable(true);
	  txMsg.setText("fsdlfkjsd dklfjdfl kjdf ldkfjsdflkj flkdjlkfjdlfkjflk dlkjsdlfkjflskjsflkj ldkfjdflksj");
   
		  mainPanel.add ("North", mP1);
		  mainPanel.add ("Center", txMsg);

	  add("Center", mainPanel);
	 // files.setSize(500,250);	
	  //messageList.setSize(mP1.size());
	 
 

	  Panel p0 = new Panel( new BorderLayout() );
	  add ("South", p0);

	  Panel p1 = new Panel( new GridLayout(1,2) );
	  p0.add("East", p1);
	
	  EnterExitEnlightButton botOK =  
			 new EnterExitEnlightButton("Delete");
	  botOK .setBackground(Globals.CruscottoColor);
	  p1.add( botOK );
	  
	  pack();
	  setSize(600,400);
	  
	  setVisible(true);

	  
	  
	  
	  
	  	
	}
	
	public void sendDiagn(String title, String nDiagn) {

		//CentrDlgBase dErr = new CentrDlgBase((Frame) this, title, nDiagn, true, true);
		//CentrDlgOkAnnull dErr = new CentrDlgOkAnnull((Frame) this, title, nDiagn, true);
	}
	 private void startRing() {
	 
	Ringer ring = new Ringer();   
	ring.start();
	
	 }
}
