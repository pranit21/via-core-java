package ant.awt;

import java.awt.*;
import java.awt.event.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class ImageContainer extends Frame {
	
	public Image myimg = null;
		
	public ImageContainer () {
		
		
		setLayout(null);
		setSize(320,240);
		
				
	 addWindowListener ( new WindowAdapter() {
	 public void windowClosing(WindowEvent e) {
 		 
	 }
	} );

	 	//botEsci.addMouseListener(
	//	new MouseAdapter() {
	//		public void MouseClicked(MouseEvent e)
	//			  { quit(e); }	
	//			}
	//);	
	
	show();
}

 
  public void setImage(Image img) 
  {
	this.myimg = img;
	repaint();
  }
    
  public void paint(Graphics g) 
  {
	if (myimg != null) 
	{
	  g.drawImage(myimg, 0, 0, this);
	}
  }


public void destroy() {
	this.destroy();
}




}