package ant.cli.vocal.panel;

import ant.cli.vocal.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.IOException;

import ant.glob.Globals;
import ant.cli.ChatCliente;
import ant.cli.ChatFrame;
//import ant.awt.LabLog;
import ant.awt.AntProgressBar;
import ant.cli.util.ContaSecondi;
import ant.cli.vocal.AntSendClient;
import ant.cli.vocal.AntServerReceive;
import ant.cli.vocal.Session;
import ant.awt.EnterExitEnlightButton;
import ant.awt.TextDisplayField;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */


public class ChatPanelVocal extends Panel  implements ItemListener{
	
  //private final static int porta = 36502;	
  private int trial=0; //numero di prove fatte per trovare la linea
  private AntSendClient asc;
  private AntServerReceive asr;
  private String nick;
  private Label laNick;
  //public LabLog labLog;	      
  private ChatCliente cliente;
  private EnterExitEnlightButton botOK;
  private TextDisplayField txInterlocutore, labLog;
  private ContaSecondi timer;
  private ChatCliente cli;
  private ChatFrame frame;
  String[] listaDest;
  //private String nickDestinatario;
  public java.awt.List txListTalk;
  public TextArea txMsg = null;

  Checkbox ckSilence, ckGSM, ckProtocol_IP, ckProtocol_UDP, ckNoCompress;
  String protocol;
  String codecType ;		
  boolean checkSilence ;
  
  private String daContatt="";
  AntProgressBar prgBar = new AntProgressBar(70);
  AntProgressBar prgBarSpk = new AntProgressBar(70);
  Checkbox siMic, noMic;
  
  CheckboxGroup cbg = new CheckboxGroup();
  CheckboxGroup cbg2 = new CheckboxGroup();
  CheckboxGroup cbg3 = new CheckboxGroup();
  private String selectedNick;
  //private vsjtalk talkGSM;
  private Session vocalSession;
  SendVoiceParameters param ;

  public ChatPanelVocal(ChatCliente cli, String[] listaDest) {
	
	  this.listaDest = listaDest;
	  this.cli = cli;	
	  this.frame = cli.frame;
	 
	  drawPanel();

	 }   


public void drawPanel() {
	
	//ClickableGIF gif1 = new ClickableGIF(cli.GIFs[Globals.Max_Faces]);
	//ClickableGIF gif2 = new ClickableGIF(cli.GIFs[Globals.Max_Faces +1]);
	//ClickableGIF gif11 = new ClickableGIF(cli.GIFs[Globals.Max_Faces]);
	Label empty = new Label("");
	
	
	
	
	setLayout(new BorderLayout (5,5));
	setBackground(Globals.OutputColor2);
    

	//Panel main = new Panel(new BorderLayout());
	Panel main = new Panel( new BorderLayout( 10, 10 ) ) {
			  public Insets getInsets() { return new Insets( 10,10,10,10 ); } };

	  
      Panel sopra = new Panel(new GridLayout(3,1)); //ri,co
	  	laNick = new Label("Contatto vocale con --> " + daContatt, Label.CENTER);
	    laNick .setFont( new Font("Dialog", Font.BOLD, 14) );
	  	sopra.add(new Label(""));
	  	//sopra.add(laNick, BorderLayout.CENTER );
        sopra.add(laNick);
	    sopra.add(new Label(""));
	main.add("North", sopra);
	
	  Panel sotto = new Panel(new BorderLayout(4,4));
	  sotto.add( "North", new Label("Il tuo interlocutore ha il microfono?", Label.CENTER));
	             
	main.add("Center", sotto);
	
          //Panel panMic = new Panel(new FlowLayout(1));//center  
	    Panel panMic = new Panel(new GridLayout(4,2));//ri,co 4,3
	        Label lab01 = new Label("???");
	        siMic = new Checkbox(" SI\' ", cbg, false);
	        noMic = new Checkbox(" NO ", cbg, false);
	        
			ckProtocol_IP=  new Checkbox("IP", cbg2, false);
			ckProtocol_UDP= new Checkbox("UDP", cbg2, false);	 
	        ckProtocol_UDP.setState(true);  
			ckProtocol_UDP.setEnabled(false);
	        ckProtocol_IP.setEnabled(false);
			   	 
			//ckSilence = new Checkbox("check silence",cbg3, false);
			ckGSM = new Checkbox("GSM Compression",cbg3, false);
			ckGSM.addItemListener(this);
	        ckNoCompress = new Checkbox("no compress",cbg3, false);
			ckNoCompress  .addItemListener(this);          

	        siMic .addItemListener(this);
	        noMic .addItemListener(this);
			ckProtocol_IP  .addItemListener(this);
			ckProtocol_UDP.addItemListener(this);
	        
			ckGSM .addItemListener(this);          
	      	
	      	//panMic.add(gif1);
	      	//panMic.add(gif2);
	      	
	      	panMic.add(siMic);
	      	panMic.add(noMic);
	      	
			//panMic.add(ckProtocol);  

			panMic.add(ckGSM);  
			panMic.add(ckNoCompress);
			
			panMic.add(ckProtocol_IP);
	        panMic.add(ckProtocol_UDP);

			ckSilence = new Checkbox("check silence");
          	panMic.add(ckSilence);  
            panMic.add(empty);  
			  
	      	//panMic.add(empty);
			//panMic.add(empty);  
			
	    sotto.add( "Center", panMic );
	
		Panel p0 = new Panel( new BorderLayout() );
		
		    Panel crusc = new Panel( new GridLayout(1,4) );
            //Panel crusc = new Panel( new FlowLayout(FlowLayout.LEFT,1,1) );
            
			botOK = new EnterExitEnlightButton("  Chiama  ");
			botOK .setBackground(Globals.CruscottoColor);
			
			labLog = new TextDisplayField("..Seleziona un nick e Chiama" ); 
	        labLog.setBackground(Globals.ARANCIO); 
	        
	        txInterlocutore = new TextDisplayField("       ???" );
	        txInterlocutore.setForeground(Color.green);
	        txInterlocutore.setBackground(Color.darkGray);
			txInterlocutore.setFont(new Font("Mm", Font.PLAIN, 12));

			timer = new ContaSecondi(); 
			timer.setFont(new Font("xx", Font.ITALIC, 12));
			timer.setBackground(Globals.Verdino);
	        timer.setForeground(Globals.Bordeaux);
	        
			crusc.add( labLog);
			crusc.add( txInterlocutore);
	        crusc.add( botOK);
			crusc.add( timer );
			//crusc.add("West", labLog);
			//crusc.add("Center", txInterlocutore);
			//crusc.add("East", botOK);
	        
		p0.add("North", crusc);
			
			//p0.add("North", labLog);

		Panel p1 = new Panel( new GridLayout(1,2) ); //ri-co
		p0.add("East", p1);
	        Panel panBar1 = new Panel( new BorderLayout() );
	              panBar1.add("Center", prgBar);
	              panBar1.add("West", new Label("input mic. "));
	        Panel panBar2 = new Panel( new BorderLayout() );
	              panBar2.add("Center", prgBarSpk);
				  panBar2.add("West", new Label("output spk."));
		p0.add("Center", panBar1);
	    p0.add("South", panBar2);
	
	sotto.add ("South", p0);

	
		botOK.addActionListener( new ActionListener() {
		   public void actionPerformed (ActionEvent e)
		   {
			onButtonClick(botOK.getLabel());
		   }
		} );
			
	add( "Center", main ); 
	   
	txListTalk = new java.awt.List(100, true);
	txListTalk.setBackground(java.awt.Color.blue);
	txListTalk.setFont(new Font("Mm", Font.PLAIN, 12));
	txListTalk.setBackground(Globals.CruscottoColor);
	txListTalk.addItemListener(this);
	add("East", txListTalk);

	loadListDest();

	setVisible(true);
	//toFront();
	show();
	}                                     

public void loadListDest() {
	
   for (int i=0; i<listaDest.length; i++) {
  
      System.out.println("nome nick da aggiungere lista = "+listaDest[i]);
 	  txListTalk.add(listaDest[i]);
   }	  
}

public void itemStateChanged(ItemEvent e) {
	
	daContatt = txListTalk.getSelectedItem() != null 
	          ? txListTalk.getSelectedItem() : "";
	laNick.setText("Contatto vocale con --> " + daContatt);
	ckSilence.setState(false);
	if ( e.getSource().equals(ckGSM) ) {
		
		if (ckGSM.getState()){
			siMic.setState(true);
			siMic.setEnabled(false);
			noMic.setEnabled(false);
			
			ckProtocol_IP.setState(true);
			ckProtocol_UDP.setEnabled(false);
			ckSilence.setEnabled(false);
		} else {
			siMic.setState(false);
			noMic.setState(true);
			siMic.setEnabled(true);
			noMic.setEnabled(true);			
			ckProtocol_IP.setState(false);
			ckProtocol_UDP.setState(true);
			ckSilence.setEnabled(true);
		}
	} 	
	
	if ( e.getSource().equals(ckNoCompress) ) {
		siMic.setState(false);
		noMic.setState(true);
		siMic.setEnabled(true);
		noMic.setEnabled(true);		
		ckProtocol_UDP.setState(true);
		ckSilence.setState(true);
		ckSilence.setEnabled(true);
	}
		
}
	   
public void onButtonClick(String label)  {


	if (label.trim().equals("Chiama") && daContatt != "") {
	   botOK.setLabel("Interrompi");
	   if (!this.ckGSM.getState()){
		  onStartCall();
	   }
	   else{   
		  onStartCall_GSM();
	   }	   
	 }
	  
	 else if (label == "Interrompi") {	 
		 botOK.setLabel("  Chiama  ");	
		 onStopCall();		
	 }
	 else {
	  frame.sendDiagn	("Attenzione !", "5"); //selezionare un nick	 
	 }
  
}

/*
public void paint(Graphics g){
  //System.out.println("--paint");    
 }
public void validate(){
	//System.out.println("--validate");   
}
*/

/*
public void paint(Graphics g){
  //System.out.println("--paint");    
 }
public void validate(){
	//System.out.println("--validate");   
}
*/

public void onStartCall_GSM(){
	
	selectedNick = txListTalk.getSelectedItem();
	
	avvertiRicevente_GSM();
	
	
	java.net.InetAddress servAddr=null;
	String host = cli.seekNickIPAddress( selectedNick );
	
	System.out.println("--ChatPanelVocal------effettuo-----chiamata GSM per " + host);
	//new ant.cli.vocal.gsm.vsjtalk(host).startPhone();
	
	vocalSession = new Session() ;
	vocalSession.startGSMSession(host);
	
	//talkGSM = new vsjtalk(host);
	//talkGSM.startPhone();
}

public void onStartCall(){
	
	String command=null;
	String host;
	selectedNick = txListTalk.getSelectedItem();
	
	//asr = null;
	//asc = null;
	
	//boolean ok = false;

    startSendClient();
	
    frame.enableAllButtons(false);
    frame.setButtonsBlocked(true);
}

private void avvertiRicevente_GSM() {
	
	String command;
	
	command = Globals.StartDoubleWayCallCommand + "GSM" +
		Globals.FieldSeparator + selectedNick + //L'ALTRO: smisto il messaggio a colui che attiver� il SendClient
		Globals.FieldSeparator + frame.getNick(); // IO
	sendString(command);	
}

private void avvertiRicevente() {
	
	String command;
	
	if ( siMic.getState()) { //double conversation
	    //		--- output Casse
	    
		command = Globals.StartDoubleWayCallCommand +
				  Globals.FieldSeparator + selectedNick + //L'ALTRO: smisto il messaggio a colui che attiver� il SendClient
		          Globals.FieldSeparator + frame.getNick(); // IO
	}
	else {	//SINGLE 
		command = Globals.StartSingleWayCallCommand +
		          Globals.FieldSeparator + selectedNick
		        + Globals.FieldSeparator + frame.getNick();  //nuova linea		     		        		        
	}          

	
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	
	if ( siMic.getState()) { //double conversation
		//	--- output Casse	
		//asr = new AntServerReceive(Globals.PortaVoice_NO_MIC +1, prgBarSpk);
		//asr.start();
		vocalSession.setProgressBar(prgBarSpk);
		vocalSession.startServerReceive();		 
	}
	
	sendString(command);
	System.out.println("-------VocalPanel----- avvertito ricevente");
	
	//labLog.setText("...linea mic attiva!");
	//timer.start();
	
	System.out.println("------------- report nick collegati ------------");
	printAddresses();
	System.out.println("-->PanelVocal : ho chiesto di conversare con " + selectedNick) ;
	System.out.println("-->PanelVocal : mi vorrei connettere con address dell'interlocutore :" + cli.seekNickIPAddress( selectedNick ));
	System.out.println("------------- report nick collegati fine------------");
}


private void sendString(String command) {
	try { 
		System.out.println("---------> "+command);
		cli.SendString( command );
		labLog.setText("..chiamata inoltrata al destinatario");
		txInterlocutore.setText( cli.seekNickIPAddress( selectedNick ) );
	} catch (IOException ex) {
		System.err.println(getClass().getName() + "errore su onCall");
		ex.printStackTrace();
	}
}


private void startSendClient() {
	
	param = setSendVoiceParams();	
    //asc = null;
 
	//SendvocalSession vocalSession = new SendvocalSession( this, asc, asr ) ;
	vocalSession = new Session( this ) ;
	
	vocalSession.setConnParams(param);

	avvertiRicevente(); 
	
	vocalSession.connectClient();
	// ================= LINEA OK !!!!! ======================
		
}

/*
private void connectClient() {
	while (asc != null && !asc.lineaOK && trial < 4) {
			trial++;
			System.out.println("......ChatVocalPanel, AntSendClient -- tentativo n. " + trial);
			stopVocalThreads();
			try {
				Thread.sleep(1000*3);			
				startSendClient();
			} catch (InterruptedException e2) {
				e2.printStackTrace();
			}		 	
	}
	//-----------------------------------------  
	if (asc != null && asc.lineaOK) 
		trial = 0; 
	else {
		System.out.println("-------- collegamento impossibile -----------");
		onStopCall();
		return;
	} 
}

*/

private SendVoiceParameters setSendVoiceParams() {
	
	if ( ckSilence.getState() ) checkSilence = true;
	else checkSilence = false;
	if ( ckGSM.getState() ) {
		codecType = "GSM";		
	} 
	if ( ckProtocol_IP.getState() ) protocol = "IP";
	if ( ckProtocol_UDP.getState() ) protocol = "UDP";
	
	else codecType = "";
		
	//protocol = ant.glob.Globals.VoIP_Protocol;
			
		SendVoiceParameters param = new SendVoiceParameters();
		param.selectedNick = cli.seekNickIPAddress( selectedNick );
		param.porta = Globals.PortaVoice_NO_MIC;
		param.labLog = labLog;
		param.prgBar = prgBar;
		param.protocol = protocol;
		param.codecType = codecType;		
		param.checkSilence = checkSilence;
	return param;
}

public void printAddresses(){
	
	//Enumeration k = hashFile.keys();
	//	while (k.hasMoreElements ())
	for (Enumeration e = cli.regFil.NickIPAdresses.keys(); e.hasMoreElements(); )	{ 
		String nick = (String) e.nextElement();
	    String addr = ( (String)cli.regFil.NickIPAdresses.get(nick) );
		
		System.out.println("-- nick = " +  nick); 
		System.out.println("-- address = " +  addr + "\r\n"); 
	}
}


public void onStopCall(){
	
try {		
	if (!this.ckGSM.getState()) {	
	  cli.SendString( Globals.StopCallCommand + selectedNick);
	} 
	else {
	  System.out.println("..interrompo chiamata GSM");	
	  cli.SendString( Globals.StopCallCommandGSM + selectedNick);
	  System.out.println("...ho comandato al mio interlocutore di chiudere");
	  
      vocalSession.stopGSMSession();
	 
      	  	
	  //if (talkGSM != null) talkGSM.stopCall();
	  //talkGSM=null;
    }
    
	labLog.setText("..chiamata interrotta");
	
} catch (IOException ex) {
	System.err.println(getClass().getName() + "errore su onStopCall");
	ex.printStackTrace();
}

	//timer.stop();
	
	frame.enableAllButtons(true);
	frame.setButtonsBlocked(false);
	
	vocalSession.stopVocalThreads();
	
}

/*
private void stopVocalThreads() {
	
	if (asc != null) {	
		asc.setStop();
		asc.cancel();
		asc = null ;		
	}
	if (asr != null) {
	   asr.setStop();
	   asr.cancel();
	}
	asc=null;
	asr=null;
}
*/

public void onCancel()  {
   frame.onBackFromMessage();
	
}


}