package ant.awt;

import java.awt.List;
import java.awt.Font;
import java.util.StringTokenizer;
import ant.glob.Globals;

import ant.cli.UpdatableComponent;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class FormattedList extends List implements UpdatableComponent {

	int FieldLength[];
	String line;
	int NumFields;
	String[] Fields;
	
public FormattedList() {
	super();
}
public FormattedList( int FieldLength[] ) {
	
	super();
	this.FieldLength = FieldLength;

	setFont( new Font("Monospaced", Font.PLAIN, 11) ); 
	//setFont( new Font("SansSerif", Font.PLAIN, 10) );
	//setFont( new Font("Dialog", Font.PLAIN, 10) ); 
}
public void add(String line) {

	int i = 0;
	int spaces = 0;
	String field = ""; 
	Fields = new String[FieldLength.length];
	
	StringTokenizer st = new StringTokenizer(line, Globals.FieldSeparator);
	
	while (st.hasMoreTokens()) {	   	
	    Fields[i++] = st.nextToken();
	}

	for (i=0; i < Fields.length; i++) {
	   spaces = FieldLength[i] - Fields[i].length();
	   field = field +  Fields[i] + addSpace(spaces);	   
	}
	
	super.add( field.trim() );
	field = "";
}

public void orderAlphabetically(String line) {


	record = new String[super.countItems()];
	
	for (int j=0; j < super.countItems(); j++) {
		 this.select(j);
		 record[j] =  super.getSelectedItem();
	}	 

	orderAlphabetically2();
	super.removeAll();
	for (int n=0; n < record.length; n++) {
		super.add(record[n]);	
	//super.add( field.trim() );
	}
}
public String addSpace(int n) {

	String s = "";
	for (int i=0; i < n; i++)
	   s += " ";
	
	return s;    
	
}

public int getLength(int i) {

	
	return FieldLength[i];
}

public int getPosition(int pos) {

	int Position = 0;
	for (int i=0; i < pos; i++) {
	   Position += FieldLength[i];
	}	
	return Position;
}

	String[] record;

public void addForOrder(String line) {

	int i = 0;
	int spaces = 0;
	String field = ""; 
	Fields = new String[FieldLength.length];
	
	StringTokenizer st = new StringTokenizer(line, Globals.FieldSeparator);
	
	while (st.hasMoreTokens()) {	   	
	    Fields[i++] = st.nextToken();
	}

	for (i=0; i < Fields.length; i++) {
	   spaces = FieldLength[i] - Fields[i].length();
	   field = field +  Fields[i] + addSpace(spaces);	   
	}
	
//	super.add( field.trim() );
//    record = new String[this.countItems()];
	field = "";
}

public void orderAlphabetically() {


	record = new String[super.countItems()];
	
	for (int j=0; j < super.countItems(); j++) {
		 this.select(j);
		 record[j] =  super.getSelectedItem();
	}	 

	orderAlphabetically2();
	super.removeAll();
	for (int n=0; n < record.length; n++) {
		super.add(record[n]);	
	//super.add( field.trim() );
	}
}

public void orderAlphabetically2 () {

  String keyNext, next;
  for (int j=0; j < record.length; j++) {
	   for (int i = j+1; i < record.length; i++) {

		   next = record[i];
		   keyNext = record[i].substring( 0, FieldLength[0] );
	       if (keyNext.compareTo( record[j].substring( 0, FieldLength[0] ) ) < 0) {
	          record[i] = record[j];
	          record[j] = next;	       
	       }
	   
	   }
  
  }

  
}

public void orderAlphabetically3(String line) {

  String app, appNext;
  for (int j=0; j < this.countItems(); j++) {
	   for (int i = j+1; i < this.countItems(); i++) {
		   this.select(i);
		   app = this.getSelectedItem().substring( 0, FieldLength[0]);
		   this.select(j);
		   appNext =this.getSelectedItem().substring( 0, FieldLength[0]);
		   
	       if (app.compareTo(appNext) < 0) {
	          //this.replaceItem()
	       
	       }
	   
	   }
  
  }
}
}