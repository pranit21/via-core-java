package ant.cli.panels;
import java.awt.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
import java.awt.event.*;
import java.util.*;

import java.io.IOException;

import ant.glob.Globals;
import ant.awt.EnterExitEnlightButton;

import ant.awt.LabLog;

import ant.awt.FormattedListPanel;
import ant.cli.ChatCliente;
import ant.cli.ChatFrame;
import ant.dyn.MyVectorMail;
import ant.dyn.EMail;
public class ChatPanelViewMail extends Panel {
	

	String RegistredNickList;	
	public TextField txTitle, txTo;	
	private MyVectorMail vectMail = new MyVectorMail();

	private String nick;

	public LabLog labLog;	      
	private ChatCliente cliente;
	private Button botOK;
	ChatFrame frame;
	private String nickDestinatario, nickMittente;
	public TextArea txMsg = null;
	int[] cols = {25, 57, 18};	
	/*String[] titoli =  {"Mittente                ", 
			"Titolo                                                 ",
			"Orario            "};	
	*/
	String[] titoli =  {"Mittente", 
			"Titolo",
			"Orario"};
    private FormattedListPanel messageList = 
		     new FormattedListPanel(cols, titoli);	
				
 public ChatPanelViewMail(ChatFrame frame, MyVectorMail vectMail, String nick) {
	
	this.frame = frame;
	this.nickMittente = nick;
	this.vectMail = vectMail;
		
	drawPanel();

 }     
 public void drawPanel() {
	
	setLayout(new BorderLayout ());
	setBackground(Color.lightGray);

	Panel mainPanel = new Panel( new BorderLayout(2,2) );

//	Panel mainPanel01 = new Panel( new BorderLayout(2,2) );
	  
//	     mainPanel01.add("North", messageList);

	//Panel mP1 = new Panel( new BorderLayout() );
	
	//mP1.add("West", messageList ); //north
	messageList.lista.addItemListener(ItemLst);	
	
	txMsg = new TextArea("", 16,1, TextArea.SCROLLBARS_VERTICAL_ONLY);		        
	txMsg.setName("MsgInput");
	txMsg.setFont(new Font("Mia", Font.PLAIN, 12));
	txMsg.setBackground(Color.darkGray);
	txMsg.setForeground(Color.white);
	txMsg.setEditable(true);

		mainPanel.add ("South", messageList);//north
		mainPanel.add ("Center", txMsg);//center

	add("Center", mainPanel);
	messageList.setSize(750,100);	
	//messageList.setSize(mP1.size());
	 
/*	txListTalk = new java.awt.List();
	txListTalk.setBackground(java.awt.Color.blue);
	txListTalk.setFont(new Font("Mm", Font.PLAIN, 12));
	txListTalk.setBackground(Globals.CruscottoColor);
	    add("East", txListTalk);
	loadListDest();    

	txListTalk.addMouseListener( new MouseAdapter() { 
	      public void mouseClicked( MouseEvent e ) {
		    setTxTo();  
		    //txTo.setText(txListTalk.getSelectedItem());  
		  }
	   }
	  );
*/

	Panel p0 = new Panel( new BorderLayout() );
	add ("South", p0);

	Panel p1 = new Panel( new GridLayout(1,2) );
	p0.add("East", p1);
	
	EnterExitEnlightButton botOK =  
	       new EnterExitEnlightButton("Delete");
	botOK .setBackground(Globals.CruscottoColor);
	p1.add( botOK );
	
	botOK.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		  onDeleteMail(txMsg.getText());
	       }
	} );

	setVisible(true);
	loadMails();
	
	//toFront();
	//show();
 }
 
public void onCancel()  {

   frame.onBackFromMessage();
	
}

	
	private ItemListener ItemLst = new ItemListener() {

	  public void itemStateChanged( ItemEvent e ) {

	     onMailSelected();		
	  }
	};	
	//private FormattedList messageList = new FormattedList(cols);                               
   
   public void loadMails() {
	
//  DataClient dtCli = new DataClient();
//  dtCli.loadListFromString( RegistredNickList, txListTalk);
	for (Enumeration e = vectMail.elements() ; e.hasMoreElements(); ) {
	    EMail eMail = (EMail) e.nextElement();
		messageList.
		   addValue( eMail.getMittente() == null ? " ?" : eMail.getMittente(), 0 );
		messageList.
		   addValue( eMail.getTitolo()   == null ? " ?" : eMail.getTitolo(), 1 );
		messageList.
		   addValue( eMail.getOrario()   == null ? " ? " : eMail.getOrario(), 2 );
		   
	    messageList.writeRow();	   
	}
	
}

public void onDeleteMail(String msg)  {


  try {

 	 frame.cli.sendObject(
	 	 Globals.DeleteMailCommand + messageList.getSelectedRow());
 	 messageList.remove(messageList.getSelectedRow());

   }
  catch (IOException ex) {
	   System.err.println(getClass().getName() + "errore su onSendMessage");
   	   ex.printStackTrace();
   }
   frame.onBackFromMessage();
  
}

public void onMailSelected()  {
	
	EMail eMail = ((EMail) vectMail.elementAt( messageList.getSelectedRow()));
	txMsg.setText( eMail.getMessaggio() == null ? " --- nessun testo ---" 
		                                       : eMail.getMessaggio() );

}

}