/*
 * Created on 15-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class Packetizer {
	
	int countPackets;
	private int MAX_PACKETS;
    boolean packet_complete=false;

	int packetLength;
	byte[] newData, unpackedData;
	int tokenPos;
	/* syntax
	public static void arraycopy(Object src,
								 int srcPos,
								 Object dest,
								 int destPos,
								 int length)
	*/
	
	Packetizer(int packetLength, int max_packets) {
		
		this.packetLength = packetLength;
		this.MAX_PACKETS = max_packets;
		newData = new byte[packetLength * MAX_PACKETS];
		unpackedData = new byte[packetLength];
		//tokenPos = packetLength * MAX_PACKETS;
	}
	Packetizer(int packetLength) {
		
		this.packetLength = packetLength;
		MAX_PACKETS = 4;
		newData = new byte[packetLength * MAX_PACKETS];
		unpackedData = new byte[packetLength];
		//tokenPos = packetLength * MAX_PACKETS;
	}
	
	
	public void packetize(byte[] data) {
		
		if (countPackets < MAX_PACKETS) {			
			appendBytes(data, countPackets*packetLength);
			countPackets ++;
			packet_complete = false;
			
		} 
		if (countPackets == MAX_PACKETS) {			
			countPackets = 0;
			packet_complete = true;
		}
	}

    public void flush() {
		countPackets = 0;    	
    }
    
	private void appendBytes(byte[] data, int destPos) {
	
	   System.arraycopy (data, 0,//data.length -1,
									 newData,
									 destPos ,
		                             packetLength);
	}
	
  public byte[] unpack(byte[] data) {
	
	byte [] unpackedData = new byte [packetLength];
	if (countPackets <= MAX_PACKETS -1) {
   	   
	   System.arraycopy (data, tokenPos,//data.length -1,
	                     unpackedData,
						 0,
						 packetLength);
		countPackets++;				 
		tokenPos += packetLength;		
		//return unpackedData;	
	} else {
		//tokenPos = packetLength;
		tokenPos = 0;
		countPackets = 0;
	} 
	return unpackedData;	
    	 
	}
	

	/**
	 * @return
	 */
	public byte[] getPacketizedData() {
		return newData;
	}

	/**
	 * @return
	 */
	public boolean isPacket_complete() {
		return packet_complete;
	}

}
