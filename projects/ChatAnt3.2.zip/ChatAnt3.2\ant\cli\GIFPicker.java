package ant.cli;

/**
 * Insert the type's description here.
 * Creation date: (10/01/03 16.10.29)
 * @author: Administrator
 */

import java.awt.Panel;
import java.awt.Image;
import java.awt.Toolkit;

import ant.awt.AntGridPanel;
import ant.awt.ClickableGIF;
import ant.cli.panels.*;
 
import java.util.Vector;
import ant.glob.Globals;

import java.net.URL;
import java.awt.Frame;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class GIFPicker extends Panel {

	private ClickableGIF gif;
	private AntGridPanel tabGIF;
	private Panel panGIF;
	private Image appImg;
	private Frame owner;

	
/**
 * GIFPicker constructor comment.
 */
public GIFPicker() {
	super();
}

public void show() {
	
//	if ( owner instanceof  ChatFrameChooseGuy ) 
//  	  tabGIF = new AntGridPanel(2,2,2,2); //2,2 ri-co//4,4 = span
//	else	
	 tabGIF = new AntGridPanel(2,2); //4,4 = span
	 
	ClickableGIF gif;
	Image appImg;
	 
	 for (int i = 0; i < Globals.Max_Faces; i++) {
		// System.out.println("gifPicker show");		 
		//----------------------------- 
		// nell'Applet sostituire con :
 		//---->Image imma = getImage(getCodeBase(), "images/f" + i + ".gif");  	
 		if (isAPPLET) {
 		   appImg = GIFs[i];
   		   System.out.println("Applet:gifPicker show: immagine:"+ appImg.toString());
  		   System.out.println("Applet:gifPicker show: immagine:"+ appImg.getSource());
//  		   System.out.println("Applet:gifPicker show: immagine:"+ appImg.getHeight());
  		   }
   		else {
 	       appImg = Toolkit.getDefaultToolkit().getImage(
	            Globals.DirGIF + getTipo() + i + ".gif" );
 	        System.out.println("No Applet:gifPicker show: immagine:"+ appImg.toString());
   		}
	    gif = new ClickableGIF( appImg, i );
	    gif.setSize(dim,dim);
 		gif.addMouseListener(new GIFListener(owner) );
		tabGIF.add( gif );
		loadedGIF.addElement( gif );
	 }
	 
	 tabGIF.setBounds(1,1,18,320);
	 //tabGIF.setBackground(java.awt.Color.red);
	 owner.add(tabGIF);	
	 

	}

	private Vector loadedGIF = new Vector();









public Image getGIF( int i ) {
		
  return ((ClickableGIF)loadedGIF.elementAt(i)).getImage();	

}public ClickableGIF getGIF( int i, int pos ) {
	
	int index = ((ClickableGIF)loadedGIF.elementAt(i)).getIndex();
	
	if ( index == pos ) {
	   return ( (ClickableGIF)loadedGIF.elementAt(i) );
	   }
	else 
	   return null;	
}

	private Image[] GIFs;
	private boolean isAPPLET = false;
	private URL Url;

public GIFPicker(Frame owner) {
	this.owner = owner;
	isAPPLET = false;	
}

public GIFPicker(Frame owner, Image[] GIFs) {
	
	this.owner = owner;
	this.GIFs = GIFs;
	isAPPLET = true;
	//System.out.println("gifPicker costruttore");
	
	}

	private int dim;

public String getTipo() {

	if ( owner instanceof  ChatFrameChooseGuy ) {
	dim=50;	
	return	 "face";
	}
	else {
		dim=16; 
		return "f";
		
	}
}
}