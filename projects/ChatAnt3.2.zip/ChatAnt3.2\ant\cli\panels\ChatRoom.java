package ant.cli.panels;
import java.awt.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
import java.awt.event.*;
import java.util.*;

import ant.cli.ChatCliente;
import ant.cli.OutputFactory;
import ant.glob.Globals;

import java.io.IOException;
public class ChatRoom extends ChatRoomPanel implements ActionListener {
	   
	private ChatCliente cli;
	private String mess;
	private String nic;
	int numRoom;
    private OutputFactory outFact;
   
  public ChatRoom ( ChatCliente cli, String nic, int numRoom, Image[] GIFs) {
	
	//super("ChatRoom: La tua Chat privata..");
	this.cli = cli;
	this.nic = nic;
	this.numRoom = numRoom; 	
		
	creaFrame();
	setSize(400, 305);
		
	txInput.addActionListener(this);

	outFact =  new OutputFactory( txOutput, txInput, 
				  scrollingOutput, GIFs, cli.frame );
	
}


public void AddText( String s )
{
	 outFact.AddText( s, nic );
	 /*
	if (s.indexOf(Globals.MsgSeparator) >= 0) {
	   txOutput.add( labColorSwitcher( s ), Red ); }
	else {     
	   txOutput.add( s, true ); } //true = grigetto
	
	cli.frame.show();

	//if ( shift )
	   scrollingOutput.setScrollPosition( 0, txOutput.getBounds().height );
*/
	
}
 
public void destroy() {
	this.destroy();


}

public void actionPerformed(ActionEvent e) {
	
  if ((e.getSource().equals(txInput)) && (e.getID()==1001)) {

	  	 mess = (String) txInput.getText();
	  	 if (mess.length() != 0) {
		  	sendString( (String) txInput.getText() );
		 	
	     }
// ho dato invio a vuoto
  }
}


public void quit() {
//non ci passa mai	
	cli.frame.btnPriv.setEnabled(true);
	try {
	 cli.SendString( Globals.CloseWindowCommand );
	} catch (IOException ex) {
	    System.out.println("ChatRoom: errore su sendString");  
	    ex.printStackTrace();
	 }
//	 dispose();
	 
}



public void sendString( String mess ) {

	 try {
	  cli.SendString(  Globals.RoomSpeakCommand + mess );
	  
	 } catch (IOException ex) {
	   System.out.println("ChatRoom: errore su sendString");  
	   ex.printStackTrace();
	 }
	  txInput.setText ("");
	
}

public void updCruscotto( String s, int i ) {
	
 if (i == numRoom) {
	 
	StringTokenizer st = new StringTokenizer( s, Globals.FieldSeparator );
	cli.frame.labRoom.setText( st.nextToken() ); 
	cli.frame.labNumUtenti.setText( st.nextToken() ); 
	cli.frame.labAccessi.setText( st.nextToken() );	 
	
   }
}  



public void onGIFReceive(String line) throws IOException {
	 		
//	� arrivata la stringa :
//	[ROOMSP1](gi� tagliato)nick --> mess + F0001 + GIFSequence

	outFact.onGIFReceive( line );
}

public void onGIFSend(String GIFSequence) {

	try {
	 cli.SendString(	 
	 	Globals.RoomGIFCommand 
	 	+ txInput.getText()
	 	+ Globals.SendGIFCommand 
	 	+ GIFSequence	
	 	);
	 
	  } catch (IOException ex) {
	   System.out.println("ChatRoom: errore su sendString");  
	   ex.printStackTrace();
	 }
   txInput.setText ("");
}
public void updateRoomList( String lista ) {

	//dataCli.setRoomData ( lista );
	//dataCli.updateRoomList( listRooms, room );

/*	String app = null;
	int i = 0;
	StringTokenizer st = new StringTokenizer( lista, Globals.NewRecord );
	listRooms.removeAll();
	while (st.hasMoreTokens()) {
	   app = st.nextToken();
	   listRooms.add( app );
	   if (room != null) room.updNumUsers( app, i );
	   i++;
	}
*/ 
}

public void updateRoomUserList( String line ) {
	
	  txListTalk.removeAll();
	  
	  StringTokenizer st = new StringTokenizer(line, Globals.FieldSeparator);
	  while (st.hasMoreTokens())
	 	  txListTalk.add(st.nextToken());	 
	}



public int getNumRoom() {
	return numRoom;
}

}