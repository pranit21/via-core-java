package ant.cli;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Component;

import java.awt.Image;
import ant.awt.ClickableGIF;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class GIFListener extends MouseAdapter  {

 Component owner;
/**
 * GIFListener constructor comment.
 */
public GIFListener() {
	super();

}
/**
 * GIFListener constructor comment.
 */
public GIFListener(Component owner) {
	this.owner = owner;
}
public void mouseClicked(MouseEvent e) {
	
	//if  (e.getComponent() instanceof ClickableGIF) {
	
	img = ( (ClickableGIF)e.getComponent() ).getImage();
	int GIFIndex = ( (ClickableGIF)e.getComponent() ).getIndex();
	
	(( ChatFrame )owner).onFaceClick(img, GIFIndex ); 	
}

 int GIFIndex;
 Image img;
}