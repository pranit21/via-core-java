package ant.cli.util;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ChatFileManager {
	String nomeFile;
	String path;
/**
 * Commento del constructor ChatFileWriter.
 */
public ChatFileManager() {
	super();
}
/**
 * Commento del constructor ChatFileWriter.
 */
public ChatFileManager(String nomeFile) {
	this.nomeFile =  nomeFile;
}
/**
 * Commento del constructor ChatFileWriter.
 */
public ChatFileManager(String path, String nomeFile) {
	this.nomeFile =  nomeFile;
	this.path = path;
}
public void display()  throws IOException {
	
//		Process p = Runtime.getRuntime().exec("cmd /c " + nomeFile);
   String shell = "";

   try {
		//String sys = System.getProperty("os.version");
		String sys2 = System.getProperty("os.name");
		//String sys3= System.getProperty("os.arc");

		//sys2 = "sistema Windows 2000 sds";
		if (sys2.indexOf("Windows 2000") > -1) { 
			shell = "cmd /c ";
		}
		if (sys2.indexOf("Windows XP") > -1) { 
			shell = "cmd /c ";
		}

		if (sys2.equals("Windows 98") || sys2.equals("Windows 95")) { 
			shell = "start /m ";	

		} else 	{ 		
			shell = "cmd /c ";
		}
		Runtime.getRuntime().exec(shell + nomeFile);
	
   }
   catch (java.io.IOException e) {} 

} 
/**
 * Inserire qui la descrizione del metodo.
 * Data di creazione: (04/06/03 22.34.39)
 */
public void write(String str)  throws IOException {
	
  BufferedWriter out2 =
	  new BufferedWriter(
		new FileWriter( nomeFile ));
	  
	  out2.write(str);
	
  	  out2.close();	
	}
/**
 * Inserire qui la descrizione del metodo.
 * Data di creazione: (04/06/03 22.34.39)
 */
public void write(StringBuffer sb) throws IOException {
	
  BufferedWriter out2 =
	  new BufferedWriter(
		new FileWriter( nomeFile ));
	  
	  out2.write(sb.toString());
	   
  	  out2.close();	
	}
}
