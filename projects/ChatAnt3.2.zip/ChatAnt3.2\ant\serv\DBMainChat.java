package ant.serv;

import java.util.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class DBMainChat {
	
	private Hashtable registroChat = new Hashtable() ;
	
/**
 * Commento del constructor RegistroFile2.
 */
public DBMainChat() {
	super();
}
public synchronized void add(String nick, ChatServer thread) {
	
   registroChat.put(nick, thread);
//   System.out.println("RegistroFile: dopo del put in hashtable");
	  
}
public Hashtable getChatters() {
	
   return registroChat;	  
}
public int getNumUsers() {
	
   return registroChat.size();	  
}
public synchronized void remove(String nick) {
	
	if ( (nick != null) && (registroChat.containsKey( nick )) )	
	    registroChat.remove( nick );
}
}