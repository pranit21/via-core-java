/*
 * Created on Nov 24, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli;
import ant.cli.util.Ringer;
import ant.cli.vocal.MicSpkLevels;

/**
 * @author *
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Prova {

	public static void main(String[] args) {
		
		//Ringer rng = new Ringer();
		//rng.start();
		boolean uno = false;
		boolean due = true;
		System.out.println ( uno | due ) ; 
		
		//MicSpkLevels ms = new MicSpkLevels();
		//ms.show(); 
	}
}
