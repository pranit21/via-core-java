/*
 * Created on 7-apr-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author p
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

package ant.cli.video;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;

import javax.media.*;
import javax.media.format.*;
import javax.media.util.*;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import com.sun.image.codec.jpeg.*;

import ant.cli.ChatFrame;

public class CopyOfShowImageGrabbedPanel extends Panel implements ActionListener 
{
  public static Player player = null;
  public CaptureDeviceInfo di = null;
  public MediaLocator ml = null;
  //public JButton capture = null;
  public Buffer buf = null;
  public Image img = null;
  public VideoFormat vf = null;
  public BufferToImage btoi = null;
  public ImagePanel imgpanel = null;
  private ChatFrame chatFrame;
  private java.net.InetAddress receiverIP; 
  private  String nick; 
  private int contClick;
  private Label info;
  
  Frame f;
  
  public CopyOfShowImageGrabbedPanel() {   
  }
  
  public CopyOfShowImageGrabbedPanel(Image bufImg) {
	this.img = bufImg;
	draw();
  }
  
  public void refreshMonitor(Image bufImg) {
  	imgpanel.setImage(bufImg);
  	//f.pack();
  }
  
  public void draw() {	 	
  	
	setLayout(new BorderLayout());
	//final Frame f = new Frame("AntImage monitor");
    f = new Frame("AntImage monitor");
    
	f.addWindowListener(new WindowAdapter() {
	  public void windowClosing(WindowEvent e) {
	  f.dispose();
	  }
	});
    
	f.add("Center",this);
	f.setVisible(true);
    
	imgpanel = new ImagePanel();
	//capture = new JButton("Capture");
	//capture.addActionListener(this);
      
  //add(capture,BorderLayout.CENTER);
  info = new Label();
  add(info,BorderLayout.SOUTH);
  info.setText("immagine:");
  info.setForeground(Color.BLUE);
  info.setBackground(Color.BLUE);
  add(imgpanel,BorderLayout.CENTER);
  setSize(new Dimension(320,550));
  
  Dimension Dim = new Dimension(320,550);
  int w = Dim.width;
  int h = Dim.height;
  Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
  if ( w >= d.width )  w = d.width - 10;
  if ( h >= d.height ) h = d.height - 10;
  //setSize( w, h );
  f.setLocation( ( d.width - w ) / 2, ( d.height - h ) / 2 );
  
  info.setText("pixels :");
  imgpanel.setImage(img);
  f.pack();
    
 }
  
  public void draw(ChatFrame frame) 
	{
	  Frame f = new Frame("SwingCapture");
	  CopyOfShowImageGrabbedPanel cf = new CopyOfShowImageGrabbedPanel();
	  f.add("Center",cf);
	  f.pack();
	  f.setSize(new Dimension(320,550));
	  f.setVisible(true);
	}
  
 
  public void actionPerformed(ActionEvent e) {  	
	  // Convert it to an image
	  btoi = new BufferToImage((VideoFormat)buf.getFormat());
	  img = btoi.createImage(buf);

	  // show the image
	  imgpanel.setImage(img);
  }
  
 
  
  class ImagePanel extends Panel 
  {
	public Image myimg = null;
    
	public ImagePanel() 
	{
	  setLayout(null);
	  setSize(320,240);
	}
    
	public void setImage(Image img) 
	{
	  this.myimg = img;
	  repaint();
	}
    
	public void paint(Graphics g) 
	{
	  if (myimg != null) 
	  {
		g.drawImage(myimg, 0, 0, this);
	  }
	}
  }
  
  


  public static void saveJPG(Image img, String s)
  {
	BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
	Graphics2D g2 = bi.createGraphics();
	g2.drawImage(img, null, null);

	FileOutputStream out = null;
	try
	{ 
	  out = new FileOutputStream(s); 
	}
	catch (java.io.FileNotFoundException io)
	{ 
	  System.out.println("File Not Found"); 
	}
    
	JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
	
	JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bi);
	param.setQuality(0.5f,false);
	encoder.setJPEGEncodeParam(param);
    
	try 
	{ 
	  encoder.encode(bi); 
	  out.close(); 
	  System.out.println("------ AntVideoFrameGrabbing : creata immagine " + s);
	}
	catch (java.io.IOException io) 
	{
	  System.out.println("IOException"); 
	}
  }
  
}



