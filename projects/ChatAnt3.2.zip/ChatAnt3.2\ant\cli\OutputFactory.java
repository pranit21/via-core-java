package ant.cli;

import java.awt.*;
import java.io.IOException;

import ant.glob.Globals;
import ant.awt.AntGridPanel;
import ant.awt.AntHGridPanel;
import ant.awt.ClickableGIF;
import ant.cli.panels.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class OutputFactory  extends ChatRoomPanel  {

	private AntGridPanel txOutput;
	public TextField txInput = null;
	String msg;
	Frame owner;

	ScrollPane scrollingOutput;

	private String nic;

	boolean SWC=true;
 	private char[] GIFIndexes = new char[Globals.Max_Faces*2];

	boolean Red;							 

	public Image[] GIFs;

public OutputFactory ( AntGridPanel txOutput, 
	TextField txInput, 	ScrollPane scrollingOutput, 
	Image[] GIFs, Frame owner ) {
	
	this.txOutput = txOutput;
	this.txInput = txInput;
	this.owner = owner;
	this.scrollingOutput = scrollingOutput;
	this.GIFs = GIFs;
	
	
}
public void AddText( String s, String nic )
{
	this.nic = nic;
	
	if (s.indexOf(Globals.MsgSeparator) >= 0) {
	   txOutput.add( labColorSwitcher( s ), Red ); }
	else {     
	   txOutput.add( s, true ); } //true = grigetto
	
	//cli.frame.show();
	owner.show();

	//if ( shift )
	scrollingOutput.setScrollPosition( 0, txOutput.getBounds().height );
	
}
public boolean isBlankLine(String msg) {
 
  return  msg.indexOf(Globals.MsgSeparator + Globals.SendGIFCommand) > -1 ? true 
	  : false;	
}
public Label labColorSwitcher( String s ) {
	


   Red = false;	
   Label lab = new Label( s ) ;
   	
   if ( s.substring(
	   0, s.indexOf(Globals.MsgSeparator)).equals(nic) )
	   { 
	  lab.setForeground(Color.red);
	  Red = true;
   }
	if ( SWC ) {
	   SWC = false;	   
	   lab.setBackground(Globals.OutputColor);
	   }
	else {
	   lab.setBackground(Globals.VIOLETTO) ;
	   SWC = true;
	   }
	return lab;
		
}
public void onGIFReceive(String line) throws IOException {
	 		
//	� arrivata la stringa :
//	[ROOMSP1](gi� tagliato)nick --> mess + F0001 + GIFSequence


	  int ch = line.indexOf(Globals.SendGIFCommand);
	  String msg = line.substring( 0, ch );
	  GIFIndexes = line.substring(ch +5).toCharArray();  
	
 	  String index = "";
 	  //ClickableGIF gif;

	  AntHGridPanel p = new AntHGridPanel();
	  	  
	  for (int j=0; j < GIFIndexes.length; j+=2)
 	  {	 	     
 	    //trasformo l'array di char in String

	    index = new String(GIFIndexes, j, 2);    				

		int n = (Integer.parseInt(index));
		ClickableGIF gif = new ClickableGIF( GIFs[n] ); 	
 		gif.setSize(16,16);
 		p.add( gif );	 		 							
 	   }
	  

	if ( !(isBlankLine( line )) ) {
	   AddText( msg, nic );
	   txOutput.add( p ); 
	} 
	else {

  	   Panel onlyGIF = new Panel(new FlowLayout(FlowLayout.LEFT) );	   
	   //onlyGIF.add( new Label( msg ) );
	   onlyGIF.add( labColorSwitcher( msg ) ); 	
	   // System.out.println("ricevo solo faccetta!!");
	   onlyGIF.add( p );	 
 	   txOutput.add( onlyGIF );
		
	} 
	 
 	owner.show();
  	scrollingOutput.setScrollPosition( 0, txOutput.getBounds().height );

}
public void refreshScreen() {

	owner.show();
	txInput.requestFocus();

}
}
