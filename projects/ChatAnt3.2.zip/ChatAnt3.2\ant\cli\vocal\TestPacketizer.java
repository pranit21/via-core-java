/*
 * Created on 15-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class TestPacketizer {

	public static void main(String[] args) {
		
		byte[] data = { '0', '1', '2', '3', '4' };
		byte[] data2 = { '5', '6', '7', '8', '9' };
		byte[] data3 = { 10, 11, 12, 13, 14 };
		byte[] data4 = { 15, 16, 17, 18, 19 };
		//String[] data2 = {"1", "2" };
		print( data );
		System.out.println(""); 
		Packetizer p = new Packetizer(5, 8);
		
		//for (int i =0; i<4 ; i++) {
			p.packetize(data) ;	
		p.packetize(data2) ;	
		p.packetize(data3) ;	
		p.packetize(data4) ;
			
	p.packetize(data) ;	
	p.packetize(data2) ;	
	p.packetize(data3) ;	
	p.packetize(data4) ;			
		//}
		
		if (p.isPacket_complete()) {
				
		data = p.getPacketizedData();
		print( data );
		}
		
	byte[] data5;	
	for (int i =0; i<8 ; i++) {		
		data5 = p.unpack(data);
		System.out.println(""); 
		System.out.println(" ----- unpacked data -----"); 
		print( data5 );
	}
	
	}
	
	static void print(byte[] data) {
		
		for (int i=0; i< data.length; i++) {
			System.out.print( data[i] + ", " );
		
		}
	
	}
}
