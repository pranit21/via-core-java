/*
 * Created on Nov 22, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.util;
import java.applet.*;
import java.net.MalformedURLException;
import java.io.File;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class Ringer extends Thread {
	
	public static AudioClip onceClip;	
	private Thread thread;
	private java.net.URL url;
	private AudioClip audioClip = null;
	
	
  public Ringer() {
  	
	try {
			//url = new java.net.URL("file:\\a_java\\audio_clip\\cipcip.au");
		String appUrl= "file:\\" + ant.cli.ChatCliente.userDir 
		   + File.separator
		   + ant.glob.Globals.DirSounds 
		   + File.separator 
		   + "doorbell.au";
		url = new java.net.URL(appUrl);   
			
			
			audioClip = Applet.newAudioClip(url);
         
		} catch (MalformedURLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
  }	
  public static void main(String[] args) {
		
		 AudioClip audioClip = null;
		 java.net.URL url;
		 try {
			 url = new java.net.URL("file:\\a_java\\audio_clip\\doorbell.au");
			 audioClip = Applet.newAudioClip(url);
		
         
		 } catch (MalformedURLException e2) {
			 // TODO Auto-generated catch block
			 e2.printStackTrace();
		 }
	     audioClip.loop();
	}
	
  public void interrupt() {

  	thread.stop();
	audioClip.stop();
	thread = null;
	}
	
  public void destroy() {
		super.destroy();
  }

  public void init() {		

  }	
			
  public void run() {
	
		//System.out.println("--- start play");
		//audioClip.play();
		audioClip.loop();
		//System.out.println("--- stop play");		
	 
	   /*
		try {
		sleep(1000);
		}	catch (Exception ex) {
			System.out.println ("FtpClient : errore apertura socket :"+ex);
		}
		finally {
		  //System.out.println ("FtpClient : chiudo il thread");
		  interrupt();
		}
		*/
	}

	public void start() {
		if (thread == null){
			thread = new Thread(this);
			setDaemon(true);
			thread.start();
		}
	 }           
			
}
