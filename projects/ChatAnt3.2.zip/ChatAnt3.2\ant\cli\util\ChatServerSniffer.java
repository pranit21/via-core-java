package ant.cli.util;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

import java.io.IOException;


import java.net.Socket;import ant.cli.ChatCliente;public class ChatServerSniffer {
		
	Thread tr;



	private ChatCliente cli;	private String ipAddr;	private int porta;	Socket server;private Sniffer snf = new Sniffer();private class Sniffer extends Thread {

	public void run() {

	  //setPriority( getPriority() - 1 );
	  while ( true ) {
	    try {
	
		    try
		  {	    
		  sniff();
		  }
		  catch(IOException e)
		    {
			}
	  
		   sleep( 60000 );
		  }
		
	    catch ( InterruptedException e ) {
	    }
	  }	     
	}
  }public ChatServerSniffer(ChatCliente cli, String ipAddr, int porta)  {
	this.cli = cli; 
	this.ipAddr = ipAddr;
	this.porta = porta;

	snf.start();
}public void sniff()  throws IOException {
	
	try {
		//System.out.println("Sniff su "+ ipAddr + " ,porta = " + porta );
		server = new Socket(ipAddr, porta);
	    cli.sendDiagn("Attenzione !", "8", false); //collegamento ottenuto
	    cli.reInit(server);
	    //System.exit(0);
	    snf.interrupt();
		
	} catch (java.net.ConnectException e) {
  	  System.err.println("No replay from AntServer, http://" + ipAddr + ":" + porta);
	}
}

}