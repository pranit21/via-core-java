package ant.dyn;

/**
 * Inserire qui la descrizione del tipo.
 * Data di creazione: (23/02/03 18.32.27)
 * @author: Administrator
 */
import java.io.Serializable;
import java.awt.TextField;import java.awt.TextArea;public class ForumInterv implements Serializable {

	/*
	 *  * This file is part of ChatAnt

	ChatAnt is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	ChatAnt is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


	Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
	 */

 private String selectedForum; private String txAutore; private String txText; private String txTitolo;public ForumInterv(String selectedForum, String txAutore,  
		  String txText, String txTitolo) {
	
 this.selectedForum=selectedForum;  
 this.txAutore=txAutore;  
 this.txText=txText;
 this.txTitolo=txTitolo;
}/**
 * Insert the method's description here.
 * Creation date: (20/03/03 17.09.14)
 * @return int
 */
public String getSelectedForum() {
	return selectedForum;
}/**
 * Insert the method's description here.
 * Creation date: (20/03/03 17.09.14)
 * @return java.awt.TextField
 */
public String getTxAutore() {
	return txAutore;
}/**
 * Insert the method's description here.
 * Creation date: (20/03/03 17.09.14)
 * @return java.awt.TextArea
 */
public String getTxText() {
	return txText;
}/**
 * Insert the method's description here.
 * Creation date: (20/03/03 17.09.14)
 * @return java.awt.TextField
 */
public String getTxTitolo() {
	return txTitolo;
}

}