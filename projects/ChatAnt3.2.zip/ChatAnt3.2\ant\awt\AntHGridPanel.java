package ant.awt;

import java.awt.*;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class AntHGridPanel extends Panel {

  public static final Font bold  = new Font( "dialog", Font.BOLD, 12 );
  public static final Font plain = new Font( "dialog", Font.PLAIN, 12 );

  private FlowLayout layout;


  private String line;
  private String ri;
  private int riga;
  private int RowChar;
  Image img;

public AntHGridPanel() {

  super();

  setLayout(layout = new FlowLayout( FlowLayout.LEFT, 2, 0 ) );
 

}

private AntHGridPanel( LayoutManager layout ) {
}
public Component add(Component c) {

  return super.add(c);
}




public Component add(Image img) {

	this.img = img;  
	ClickableGIF gif = new ClickableGIF(img);
	//gif.setSize(16,16);

  return super.add(gif);
}


public AntHGridPanel(int span0, int span1 ) {

  super();

  setLayout(layout = new FlowLayout( FlowLayout.LEFT, 2, 0 ) );
 

}
}