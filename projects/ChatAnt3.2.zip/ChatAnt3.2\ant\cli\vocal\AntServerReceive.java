package ant.cli.vocal;

import java.net.*;
import java.io.*;
import javax.sound.sampled.*;

import ant.awt.AntProgressBar;
import ant.glob.Globals;

public class AntServerReceive implements Runnable {
	 
	//private static final int porta = 5002
	//private static final int porta2 = 5004;

    int maxsize = 512;
    private int porta;
	private Thread thread;
	private AudioFormat format;
	SourceDataLine line;
	DatagramPacket receivePacket;
	DatagramSocket socketUDP;
	Socket socketIP;
	private boolean sock_close = true;
	private boolean IP_Protocol = true;
	private boolean STOP = false;
	private AntProgressBar prgBar;
	private int ss, somma;
	private static final int SOGLIA_PER_BYTE = 127;

	//ByteArrayOutputStream out;
	AudioInputStream audioInputStream;
	DataInputStream inStream;
	int frameSizeInBytes;
	int bufferLengthInBytes;
	File file;
	int cont;
	AUWriter writer;
	ServerSocket serverSocket;
	static final int BIT = 8;	
	//Packetizer packetizer = new Packetizer(512, 4);
	
	public AntServerReceive(int porta) {
	    this(porta, null);
	}
	public AntServerReceive(int porta, AntProgressBar prgBar) {

		this.porta = porta;
		this.prgBar = prgBar;
		
		IP_Protocol = getVoIPProtocol();
	}
	
	public void start() {
		thread = new Thread(this);
		thread.start();
	}

public void run() {

	format = new AudioFormatFactory().getFormat(BIT);
	//format = new AudioFormatFactory().getFormatGSM();
	
	try {	
		if (IP_Protocol) {		
		    serverSocket = new ServerSocket(porta);
		    System.out.println(".. AntServerReceive IP started on port " + porta );
		} else {
			socketUDP = new DatagramSocket( porta );
			sock_close = false;
			System.out.println(".. AntServerReceive UDP started on port " + porta );
		}
	} catch (IOException e) {
			System.out.println("--AntServerReceive, eccezione aperura socket " + e.toString());
			return;
		}

 try {

	System.out.println("..server-casse pronto per connessioni su porta "+porta);
	
	if (IP_Protocol) {
	   socketIP = serverSocket.accept();
	   System.out.println(".. AntServerReceive: client IP accepted: " + socketIP.toString());
	   inStream = new DataInputStream(socketIP.getInputStream());
     }
	
	DataLine.Info info = new DataLine.Info(SourceDataLine.class,format);
	line = (SourceDataLine)AudioSystem.getLine(info);
	line.open(format,line.getBufferSize());

	frameSizeInBytes = format.getFrameSize();
	int bufferLengthInFrames = line.getBufferSize() / BIT;
	bufferLengthInBytes = bufferLengthInFrames * frameSizeInBytes;
	byte[] data = new byte[bufferLengthInBytes]; //=512
			
	System.out.println("--receive <-- getBufferSize = "+ line.getBufferSize() );
	System.out.println("--receive <-- bufferLengthInFrames = "+ bufferLengthInFrames );
	System.out.println("--receive <-- bufferLengthInBytes = "+ bufferLengthInBytes );
	System.out.println("--receive <-- data.length = "+ data.length ); //=512

    line.start();
	writer = new AUWriter(format, bufferLengthInBytes);    
    System.out.println(".. AntServerReceive: speakers enabled");
      
    while (STOP == false) {
	  //while (in.read(data)!=-1) {	        

        receive(data);
 		//updateWindowBar(data);	
	
    }
	
	
	System.out.println("-- AntServerReceive: Chiamata conclusa");  

  } catch (SocketException e) {
		   System.out.println(".. AntServerReceive, speakers logoff!" );
  
  } catch (Exception e) {
			System.out.println("-- AntServerReceive, eccezione : " + e.toString());
			e.printStackTrace();
  }

  /*finally {
    thread = null;
	//if (!sock_close) {
		 socket.close();
		 sock_close = true;  
		 line.drain();
		 line.stop();
	     line.close();
		System.out.println("..AntServerReceive stopped");
	//}
	
  }
  */
}

  private void receive(byte[] data) throws IOException {
  
	if (!IP_Protocol) {	/* UDP protocol */
		receiveUDP();		
        // asterisc per i test		
		// testScritturaAU(receivePacket.getData());	
		//--------------------------	

		 line.write( receivePacket.getData(),  
		            0, receivePacket.getLength() ); 
		//aggiunto
		updateWindowBar(receivePacket.getData());	          
		
		/* test spacchettamento
		//receivePacket = new DatagramPacket(data, 512*4);
		//socketUDP.receive(receivePacket);				        
		byte[] data2;
		for (int i =0; i<4 ; i++) {			
		   data2 = packetizer.unpack(receivePacket.getData());		   
		   line.write( data2, 0, 512 );
		}
		*/	   				    	
	} else {  // *** IP PROTOCOL
		inStream.read(data);	
		line.write(data, 0, data.length);
		testScritturaAU(data);
			
	}
  }

private void receiveUDP() throws IOException {
 	
	receivePacket = new DatagramPacket(new byte[maxsize],maxsize);
	socketUDP.receive(receivePacket);
}

private void testScritturaAU(byte[] data) {

	//--------	  istruzioni per il debug	  
	if (cont < 150)  {
	   cont++;
	   System.out.println("cont " + cont);
	   writer.writeData(data); //istruzione per il debug
	} else {
		//	--------	  scrittura file audio istruzioni per il debug
		writer.closeWriteData();
		writer.saveToFile("c:\\zz\\output_audio.au", AudioFileFormat.Type.AU);
		// ------------	   
	}

}
  
 public void setStop() {
	STOP = true;
 }



 public void cancel() {
	System.out.println("..AntServerReceive: richiedo cancel");
    thread = null;
	chiudiSocket();
		//line.drain();
		line.stop();
		line.close();	
   		System.out.println("==================AntServerReceive: chiamata conclusa");
	} 

private void chiudiSocket() {
	try {
		 
		if (!sock_close) {
			if (!IP_Protocol)  socketUDP.close();
			else               serverSocket.close();
			sock_close = true;
		}
			 
	} catch (IOException e) {
	  e.printStackTrace();
	}
	 
}

/*
 private void  parseSample(byte[] data) {
 	
  //byte[] = receivePacket.getData(); //=1024
  for (int i=0; i<5; i++) {  //1000 sample
	  System.out.print(" " + data[i] + "  " );
  }
  System.out.println(" ");

 } 
*/

private void updateWindowBar(byte[] data){ 
	
	//updateBar0(receivePacket.getData()); mettere if per UDP

    double somma2=0;
	for (int i=0;  i < 512 ; i+=2) {

		somma2 += Math.abs ( data[i] );
		//System.out.print(" " + data[i] + "  " );
	}
	updateBar( (int) somma2 / 256 );
  }

 public void updateBar(int val) {	
	 if (prgBar != null) prgBar.setValue(val);
 }

 private boolean getVoIPProtocol() { 
    return (Globals.VoIP_Protocol.equals("IP")) ? true : false ;
 }
 
/*

private void receiveUDP_new() throws IOException {
 	
	   int len=0;
	   receivePacket = new DatagramPacket(new byte[maxsize],maxsize);
	   socketUDP.receive(receivePacket);
	 
	   len = receivePacket.getLength();
	   	
}

public static void main(String[] args) {

        porta = Integer.parseInt(args[0]);
		AntServerReceive jvms = new AntServerReceive(porta);
		jvms.start();
}


   
 private void receiveUDP_prova() throws IOException {
 	
 	// riceve un array di byte di misura variabile
 	// se ad esempio maxsize � impostato a 64 e io mando 512 
 	// legge 512, se � impostato a 2024 e io mando 512 legge 2024
 	// sembra che questo non dia alcun fastidio, 
 	// tuttavia in questo caso dovrei ridurre i 2048 a 512 con un arraycopy
 	// ricordando che len = receivePacket.getLength(); = 512 (maxsize=2048)
 	
 	//int len = 0;
	//do {
		receivePacket = new DatagramPacket(new byte[maxsize],maxsize);
		socketUDP.receive(receivePacket);
		//dp = new DatagramPacket(new byte[maxsize],maxsize);
		//mysock.receive(dp);

	//  len = receivePacket.getLength();
	//	if (len > (maxsize >> 1))  
	//		maxsize = len << 1;
	//	}
	//while (len >= receivePacket.getData().length);
 			
 }
 
 
private void writeData(byte[] data) {
   //System.out.print("scrivo....");
   out.write(data, 0, bufferLengthInBytes);
}


private void closeWriteData() {

   try
   {
	   out.flush();
	   out.close();

   } catch (IOException ex) {
		   ex.printStackTrace();
   }

   byte audioBytes[] = out.toByteArray();
   ByteArrayInputStream bais = new ByteArrayInputStream(audioBytes);
   audioInputStream = new AudioInputStream(bais, format, audioBytes.length / frameSizeInBytes);

   long milliseconds = (long)((audioInputStream.getFrameLength() * 1000) / format.getFrameRate());
   double duration = milliseconds / 1000.0;

   try {
	   audioInputStream.reset();
	   System.out.println("---chiudo");
   } catch (Exception ex) {
	   ex.printStackTrace();
	   return;
   }
}




public void saveToFile(String name, AudioFileFormat.Type fileType) {

	if (audioInputStream == null) {
		//reportStatus("No loaded audio to save");
		return;
	} else if (file != null) {
		//createAudioInputStream(file, false);
	}

	// reset to the beginnning of the captured data
	try {
		audioInputStream.reset();
	} catch (Exception e) {
		//reportStatus("Unable to reset stream " + e);
		return;
	}
	String fileName;
	File file = new File(fileName = name);
	try {
		if (AudioSystem.write(audioInputStream, fileType, file) == -1) {
			throw new IOException("Problems writing to file");
		}
	} catch (Exception ex) {
	   //reportStatus(ex.toString()); }
	//samplingGraph.repaint();
	}
	System.out.println("---salavagto");
 }
*/

}