package ant.awt;
import java.awt.*;
import java.awt.event.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
class FinesError extends Frame {

public static void main (String[] args) {

  FinesError f = new FinesError("eroore");

}








public FinesError() {
	
		setLayout(new BorderLayout ());

		setTitle("ChatAnt : errore");
		add(MesgError);

		setVisible(true);
		toFront();
		show();

	 addWindowListener ( new WindowAdapter() {
	 public void windowClosing(WindowEvent e) {
 		dispose();
	 }
	} );

}                                       

private Component MesgChoice =
	new PanelMesg( "Scegli indicatore", PanelMesg.ModeInfo );
private Component MesgError =
	new PanelMesg( "fd�flkd�fldk", PanelMesg.ModeError );
private Component MesgLoad =
	new PanelMesg( "Ererueirueiru", PanelMesg.ModeWait );
private Component MesgValues =
	new PanelMesg( "Valori mancanti", PanelMesg.ModeInfo );

public FinesError(String msgErr) {

	
/* MesgLoad =
	new PanelMesg( msgErr, PanelMesg.ModeWait );
 MesgError =
	new PanelMesg( msgErr, PanelMesg.ModeError );
 MesgChoice =
	new PanelMesg( "Scegli indicatore", PanelMesg.ModeInfo );
*/ 
MesgValues = new PanelMesg( msgErr, PanelMesg.ModeInfo );

		setLayout(new BorderLayout ());
		setSize(150,150);

		setTitle("ChatAnt : errore");

	if (msgErr.equals("feiuei"))
		add(MesgError);
	else	
		add(MesgValues);
		
		setVisible(true);
		toFront();
		show();

	 addWindowListener ( new WindowAdapter() {
	 public void windowClosing(WindowEvent e) {
 		dispose();
	 }
	} );

}               
}