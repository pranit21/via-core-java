
package ant.cli;

import java.io.*;

import javax.media.util.BufferToImage;

import ant.awt.CentrDlgBase;
import ant.dyn.RegistroDownload;
import ant.dyn.RegistroFile2;
import ant.cli.ftp.FtpClient;
import ant.dyn.FileRecord;
import ant.dyn.LoginFiles;
import ant.dyn.Target;
import ant.glob.Globals;
import ant.cli.util.Ringer;
import ant.cli.video.*;
import ant.cli.vocal.gsm.vsjtalk;

import ant.cli.vocal.MicSpkLevels;
import ant.dyn.ForumRec;

import java.net.Socket;
import java.util.Properties;
//import ant.awt.SplashScreenWindow;
import java.awt.Toolkit;
import java.awt.Frame;
import java.applet.Applet;

import ant.cli.panels.*;
import ant.cli.util.DataClient;
import java.net.URL;
import java.awt.Image;
import java.net.InetAddress;
//import ant.cli.util.ChatServerSniffer;
import java.util.StringTokenizer;
import ant.dyn.MyVectorInterventi;
import ant.cli.util.ChatFileManager;
import ant.cli.vocal.*;
import ant.cli.vocal.AntSendClient;
import ant.cli.vocal.AntServerReceive;
import ant.dyn.MyVectorMail;
import ant.dyn.RepositoryFiles;
import ant.dyn.MyVectorInterventiRoom;
import java.util.Enumeration;
import ant.cli.vocal.Session ;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatCliente extends Applet implements Runnable {

	private MyVideoAudioReceiver video; 
	protected NickAdmin nickAdm;
	private Thread thread;
	private int porta;
	private String str;
	//public boolean RoomInhibited = false;
	protected ChatLover lov;
	
	
	//private AntServerReceive asr;
	//private AntSendClient asc;
	//private vsjtalk talkGSM;
	private Session vocalSession; 

	private ObjectInputStream iObjStream;
	private ObjectOutputStream oObjStream;
	private Socket server;
	public Image[] GIFs;
	public boolean isAPPLET = false;
	
	private static String serverAdrsParam;
	private String ipAddr;
	//private String driveFileSharing;
	public Properties p;		
	public static String userDir;
	private InetAddress address;

	private RegistroFile2 fiTemp = new RegistroFile2();
	public ChatFrame frame;
	private boolean isChecked = false;
	public RegistroFile2 regFil = new RegistroFile2();
	public RegistroFile2 regFilRepo = new RegistroFile2();
	private ChatRoom room;
	private String title, forumName;
	MicSpkLevels levels;
	ClientVoiceCommander voiceCommander;
	
	//public Image GuyGIFs[] = null;


public ChatCliente() throws IOException {
		isAPPLET = true;
		//System.out.println("costruttore di ChatCliente");
	}

	/**
	 * Restituisce le informazioni su questo applet.
	 * @return una stringa di informazioni su questo applet
	 */
	public String getAppletInfo() {
		return "ChatCliente\n"
			+ "\n"
			+ "Inserire qui la descrizione del tipo.\n"
			+ "Data di creazione: (27/11/01 11.18.42)\n"
			+ "@author: TheBigAnt\n"
			+ "";
	}

private void handleException(java.lang.Throwable exception) {

	System.out.println("--------- ECCEZIONE  ---------");
	exception.printStackTrace(System.out);
}

// eliminata perch� va male nell' Applet
//static {
//	userDir = System.getProperty("user.dir");
//	System.out.println("--------- eseguito userdir ");
//} 

public void init() {
	
	nickAdm = new NickAdmin();
	voiceCommander = new ClientVoiceCommander(this, nickAdm);	
	
	try {
		//PolicyEngine.assertPermission(PermissionID.FILEIO);
		//System.out.println("init di ChatCliente");
		if (isAPPLET)	{
 		  //porta = Integer.parseInt(getParameter("porta"));
	      URL Url = getCodeBase();
	      System.out.println("Applet, init di ChatCliente, URL = " + Url.toString());
		  GIFs = getGIFs(Url);
		}
		else {
		  //System.out.println("init di ChatCliente StandAlone");
		 
		  userDir = System.getProperty("user.dir");	
	      System.out.println("--- UserDir = "+ userDir);	
		  //readPropertyFile();//il file delle propriot� risiede sul client
		                     //solo nel caso di applic. stand alone.	  
		  GIFs = getGIFsNoApplet();    
		}
		
		frame = new ChatFrame(title, this, isAPPLET);
		//System.out.println("init di ChatCliente fatto, ChatFrame aperta");
		
	} catch (java.lang.Throwable ivjExc) {

		handleException(ivjExc);
	}
}

public void run() {

	try {
			
		if (!getInitParametri()) 
		    throw new java.net.ConnectException( getClass().getName() +" -- IP del ChatServer mancante");;
		
		getSocket();
		if (server == null)
			throw new java.net.ConnectException( getClass().getName() +" -- ChatServer non attivo");
		 
		iObjStream = new ObjectInputStream(server.getInputStream());
		oObjStream = new ObjectOutputStream(server.getOutputStream());
		
		System.out.println("..connected to " + getClienteAddress());//Alina/156.54.188.154
		System.out.println("..local address = " + server.getLocalAddress().getHostAddress());//=127.0.0.1
		//System.out.println("..local InetAddress = " + server.getLocalAddress().getLocalHost());		
		frame.enableLoginButton();
		
		while (true) {

			checkInput(iObjStream.readObject());
		}
	}
	
	 catch (java.net.ConnectException e) {
		//e.printStackTrace();
		//System.out.println("Nessun problema: ChatAnt riprover� a ricollegarsi");
		//gli do la possibilit� di riconnettersi ad un altro IPAddress
		
	} catch (ClassNotFoundException e) {
		System.out.println("errore  " + e);
		e.printStackTrace();
		
	} catch (OptionalDataException e) {
		System.out.println("errore  " + e);
		e.printStackTrace();
		
	} catch (IOException e) {
		System.out.println("errore " + e);
		e.printStackTrace();
		
	} catch (Exception e) {
		System.out.println("Errore  " + e);
		e.printStackTrace();
		
	} finally {
		try {
			//##if (null != server) server.close();
			//##thread.interrupt(); //##ripristinare nella versione definitiva
			
			if (null != server) {	
			   server.close();
			   //System.exit(0);
			} 
		  thread.interrupt();
		  
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}

public void SendString(String s) throws IOException {

	//if ((s.indexOf("nick") == 0) || (s.indexOf("NICK") == 0)) {
	//	frame.labNick.setText(s.substring(5));
		//System.out.println("digitato nick");
	//}
	
	try {	
	  oObjStream.writeObject(s);
	} catch (IOException ex) {
		System.err.println(ex.getMessage() + "\n");
		ex.printStackTrace();
		stop();
	}
}
  
	public void sendObject(Object o) throws IOException {

		oObjStream.writeObject(o);
	}

	public void setString(String str) {
		// LOVQ = quit chatLove
		if (str != Globals.LovSpeakCommand) {
			str = (Globals.LovqCommand + str);
		} else {
			frame.btnPriv.setEnabled(true);
		}
		try {
			SendString(str);
		} catch (IOException ex) {
			ex.printStackTrace();
			stop();
		}
	}

	public void start() {
			if (thread == null){
				thread = new Thread(this);
				thread.start();
			}
	}

public void stop() {
	
try {	
	if (isChecked)	SendString( Globals.QuitCommand );
	thread = null;
	System.exit(0);
		
} catch (IOException ex) {
		ex.printStackTrace();
  }   
}


public void checkInput(Object o) throws Exception {

	
if (o instanceof RegistroFile2) {
	onFileListReceive( o );
	
} else if (o instanceof ForumRec) {

	ForumRec record = ( (ForumRec) o );
	frame.onForumTitlesReceive( record );
	 
} else if (o instanceof RepositoryFiles) {

	onRepositoryFilesReceive( o );
	
} else if (o instanceof Target) {

	onVideoReceive((Target) o) ;
	//if (onVideoReceive( (Target) o )
	//	== Target.CONFERENCING_BUSY_PORT)
		
	
} 
else if (o instanceof MyVectorMail) {

	frame.onNewMailForYou( (MyVectorMail) o );

} else if (o instanceof MyVectorInterventi) {

	onREWRequest( (MyVectorInterventi) o );

} else if (o instanceof MyVectorInterventiRoom) {

	onREWRoomRequest( (MyVectorInterventiRoom) o );
			
			
} else if (o instanceof StringBuffer) {

   //System.out.println("Ricevo fileforum");
   /*StringBuffer sb = new StringBuffer();
   sb = (StringBuffer) o;
   String drive = userDir.substring(0, userDir.indexOf(":") +1);
   ChatFileManager fm = new ChatFileManager(
	    drive + File.separator + "MieiFiles" 
	    + File.separator + forumName);
   fm.write(sb);
   */
   onViewForum( o );
   

} else if (o instanceof RegistroDownload) {
		RegistroDownload regdow = new RegistroDownload();
		regdow = ((RegistroDownload) o);
		//System.out.println("Instance of RegistroDownload Chat Client");
		//System.out.println("ChatClient: divento donatore di file");
		//System.out.println("nome file da donare ="+ regdow.getNomeFile());
		//System.out.println("nick donatore (mio)="+ regdow.getNickDonatore());
		startFtpDonatore(regdow.getNomeFile(), regdow.getAddressRichiedente());
} else if (o instanceof String) {
		  checkServerCommand((String) o);
		}
//else throw new Exception( getClass().getName() +" Oggetto SCONOSCIUTO ricevuto dal server "); 
}

public void checkServerCommand(String line) throws IOException {
	//System.out.println("arriva :" +line);
try {
	if (line.indexOf(Globals.NumUserCommand) == 0) {
		// AGGIORNAMENTO NUMERO UTENTI COLLEGATI
		onNumUserCommand(line);
		return;
	}

	if ((line.indexOf(Globals.LovSpeakCommand) == 0)
		|| (line.indexOf(Globals.RoomCommand) == 0)) {

		onLoveOrRoomCommand(line);
		return;
	}
	
	
	
	
	
	if (line.indexOf(Globals.DiagnCommand) == 0) {
		onDiagn(line);
		return;
	}
	if (line.indexOf(Globals.UdpFileListCommand) == 0) {
		// AGGIORNAMENTO LISTA FILES
		regFil.reset();
		return;
	}
	if (line.indexOf(Globals.UPD_MAIN_LIST) == 0) {
		// AGGIORNAMENTO LISTA UTENTI

		frame.onChattersRefreshListCommand(line);
		return;
	}
	if (line.indexOf(Globals.RegistredNickListCommand) == 0) {
		//precarico la lista dei nick registrati
		frame.setRegistredNickList(line.substring(5));
		return;
	}
	if (line.indexOf("L0000") == 0) {
		// aggiornamento lista della finestra Love
		lov.clearChatterList();
		StringTokenizer st =
			new StringTokenizer(
				line.substring(5),
				Globals.FieldSeparator);
		while (st.hasMoreTokens())
			lov.addChatter(st.nextToken());
		return;
	}
	if (line.indexOf(Globals.ReceiveWakeCommand) == 0) {
		ChatAvviso avviso =
			new ChatAvviso(frame, line.substring(5), false);
		avviso.show();
		return;
	}
	if (line.indexOf(Globals.ReceiveMsgCommand) == 0) {
		boolean isMessage = true;
		onMessageReceive(line, isMessage);
		return;
	}
	if (line.indexOf(Globals.PrivateChatRequestCommand) == 0) {
		//creo una nuova finestra per la creazione della nuova
		//finestra (lista Love)
		onPriChatReqReceivedCommand(line);
		return;
	}
	if (line.indexOf(Globals.RoomExpiredCommand) == 0) {
		// la stanza � scaduta non posso pi� chattare da quella stanza
		// altrimenti il server prende errore
		onRoomExpiredCommand();
		return;
	}
	if (line.startsWith(Globals.ImageGrabbedSendCommand)) {
		StringTokenizer st = new StringTokenizer(line, "|");
		st.nextToken();
		st.nextToken();
		int numbytes = Integer.parseInt(st.nextToken());
		String chiManda = st.nextToken();
		onImageGrabbingReceiveActivation(numbytes, chiManda);
		return;
	}
	if (line.indexOf(Globals.SendGIFCommand) > 0) {
		//insieme al testo ricevo una faccetta

		frame.onGIFReceive(line);
		return;
	}
	
	//check dei comandi vocali
	if ( voiceCommander.checkVoiceCommand(line) ) {
		return;
	}
	
	displayChatLine(line);

} catch (IOException ex) {
	ex.printStackTrace();
	stop();
} catch (Exception ex) {
	ex.printStackTrace();
}

}

private void onRoomExpiredCommand() {
	//RoomInhibited = true;
	frame.onRoomExpired();
}

public void displayChatLine(String line) {

		//frame.txOutput.setForeground(Color.red);
		//int ch = line.indexOf(" ===>");
		//String appNick = "";
		//if ( ch > -1 ) 
		//	 appNick = line.substring(0, ch -1);

		frame.AddText(line, true);
}

	public InetAddress getClienteAddress() throws Exception {

		try {
			address = server.getInetAddress().getLocalHost();
			//server.getLocalAddress().getHostAddress()
		} catch (Exception e) {
			throw new Exception("getInetAddress di Cliente non riuscito");
		}
		return address;
	}
	
	public String getLocalAddress() throws Exception {

		try {
			return server.getLocalAddress().getHostAddress();
		} catch (Exception e) {
			throw new Exception("getLocalAddress di Cliente non riuscito");
		}
	}

	public String getChatServerAddress() {
	   return ipAddr;
	}

public static void main(java.lang.String[] args) {

//	if (args.length==0) {
//			System.out.println("Comando: java ant.cli.ChatCliente <nome host>");
//	} else {
	  try {
		
		ChatCliente cli = new ChatCliente();
		cli.isAPPLET = false;
		//--- ripristinare se l'Applet nonva pi� ------
		//Frame frame = new Frame("ChatApplet");
		//frame.add(cli);
		//frame.setVisible(true);
		
		cli.init();
		cli.start();
	}
	catch ( IOException e ) { e.printStackTrace(); }	
//  }
}

public void onEnter(String str) {

 if (str.trim().length() != 0) {

	try {
		SendString(str);
	} catch (IOException ex) {
		ex.printStackTrace();
		stop();
	}
	frame.txInput.setText("");
 }
		// ho dato invio a vuoto mandare diagn
}





public void onNumUserCommand(String line) {

	DataClient dataCli = new DataClient(line.substring(5));
	frame.labNumUtenti.setText("utenti on-line: " + dataCli.getField(0));
	frame.labAccessi.setText("accessi tot.: " + dataCli.getField(1));
	frame.labRoom.setText("..Sala Ospiti");
}



public void sendDiagn(String title, String nDiagn, boolean okAnn) {

  if (!okAnn) { 
     CentrDlgBase dErr = 
         new CentrDlgBase((Frame) frame, title, nDiagn, true);
  }
  else {
     CentrDlgBase dErr = 
		   new CentrDlgBase(
		      (Frame) frame, title, nDiagn, true, okAnn, nickAdm);
  }
    
}

public void setRoom(ChatRoom room) {

		this.room = room;
	}

public ChatCliente(int porta, Image[] GIFs) throws IOException {

		this.porta = porta;
		this.GIFs = GIFs;

		isAPPLET = true;
		System.out.println("init da fare");
	}

public Image[] getGIFs(URL Url) {

	Image[] GIFs = new Image[Globals.MAX_IMG];
	int i = 0;
	for ( i = 0; i < Globals.Max_Faces; i++) {
		GIFs[i] = getImage(Url, Globals.DirGIFApplet + "f" + i + ".gif");
		//System.out.println(
		//	"immagine:" + Url + Globals.DirGIFApplet + i + ".gif");
	}
	GIFs[i] = getImage(Url, Globals.DirGIFApplet + "speak1.gif");
	i+=1;
	GIFs[i] = getImage(Url, Globals.DirGIFApplet + "speak2.gif");
		
	return GIFs;
}

public void onLoveOrRoomCommand(String line) throws IOException {

if (line.indexOf(Globals.LovSpeakCommand) == 0) {
	if ( lov != null ) lov.AddText(line.substring(4));
	/*if (line.indexOf("Per favore chiudi questa finestra!") > 0) {
	   try { Thread.sleep(5000); }
	   catch (InterruptedException e) {System.out.println ( e.toString() );}
	   lov.quit(); //da abend
	} */   
} else

if (line.indexOf(Globals.RoomTitleCommand) == 0) {	

	//riempio e aggiorno la lista delle room attive	+ statistiche	
	frame.updRoomListAndCruscottoRoom(line.substring(9));



} else

if (line.indexOf(Globals.RoomUpdateListCommand) == 0) {	
	// AGGIORNAMENTO LISTA UTENTI ROOM
	room.updateRoomUserList(line.substring(7));
	
} else

if (line.indexOf(Globals.RoomSpeakCommand) == 0) {	
	if ( frame.getSelectedRoomIndex() <= frame.getMaxRoomNumber()-1 )	
	   room.AddText(line.substring(7));
} else

if (line.indexOf(Globals.RewRoomCommand) == 0) { //non si usa pi�
	
	/*if (line.substring(7).indexOf(Globals.SendGIFCommand) > 0)
	   room.onGIFReceive(line.substring(7));
	else   	
	   room.AddText(line.substring(7));
	*/   
} else

if (line.indexOf(Globals.RoomGIFCommand) == 0) {	
	room.onGIFReceive(line.substring(7));
	}	

}

public void onPriChatReqReceivedCommand(String line) {

	String listaLove = line.substring(5);
	frame.btnPriv.setEnabled(false);
	lov = new ChatLover(listaLove, this, frame.labNick.getText());

}

public Image[] getGIFsNoApplet() {
	
	GIFs = new Image[Globals.MAX_IMG];
	Image appImg = null;
	//userDir = System.getProperty("user.dir");//prova asterisco

    int i = 0;   
	for (i = 0; i < Globals.Max_Faces; i++) {
		
 	        appImg = Toolkit.getDefaultToolkit().getImage(
			//Globals.DirGIF + "f" + i + ".gif" );
			   userDir 
			   + File.separator
			   + Globals.DirGIF 
			   + File.separator 
			   + "f" + i + ".gif" );
 	        
 	        GIFs[i] = appImg;
 	        //System.out.println("No Applet:showGIFs: immagine:"+ appImg.toString());
	 }
	 
	//System.out.println("carico immagine" +i);
	GIFs[i] = Toolkit.getDefaultToolkit().getImage(
				  userDir + File.separator + Globals.DirGIF + File.separator 
				  + "speak1.gif" );
	i+=1;			  
	System.out.println("carico immagine" +i);				  
	GIFs[i] = Toolkit.getDefaultToolkit().getImage(
				 userDir + File.separator + Globals.DirGIF + File.separator 
				 + "speak2.gif" );
	System.out.println("caricate imm");	
		       
	 return GIFs;
}



public void onMessageReceive(String line, boolean isMessage) {

	//Ringer ring = new Ringer();     
	//ring.start();
	ChatAvviso avviso = 
		   new ChatAvviso(frame, line.substring(5), false, isMessage);
	avviso.show();
}

	
	public void exit() {

	//sendDiagn("Attenzione !", "7");	//collegamento non riuscito
	frame.dispose();
	//System.exit(0);

}

private boolean getPropertyParams() {

	ipAddr = p.getProperty("ServerIP");
 	porta  = Integer.parseInt( p.getProperty("Porta") );
 	return (ipAddr.length() > 0);
 	
} 

private void onImageGrabbingReceiveActivation(int numbytes, String chiManda) {
	try {
		ant.cli.ftp.ReceiveImageServer grab = 
		     new ant.cli.ftp.ReceiveImageServer(numbytes, chiManda);
		grab.start();     
	} catch (IOException e) {
		e.printStackTrace();
	}
	 
}
public void onFileListReceive(Object o) {

	fiTemp = ( (RegistroFile2) o );
	FileRecord[] records = fiTemp.records;
	String nick = fiTemp.nick;
	
	
	regFil.putFilesByNick(nick, records);
	
	regFil.putAddressByNick(nick, fiTemp.getNickLocalAddress());
	
	System.out.println("ChatClient: ricevuto nome nick   = " + fiTemp.nick);//ok
	System.out.println("ChatClient: ricevuto indirizzoIP =" + fiTemp.getNickLocalAddress() );

} 

public void onRepositoryFilesReceive(Object o) throws IOException {

	    RepositoryFiles rf = new RepositoryFiles();
		rf = ( (RepositoryFiles) o );
		FileRecord[] records = rf.getRecordFiles();
		String nick = rf.getNick();
		//regFil.reset();
		regFilRepo.putFilesByNick(nick, records);
		
		frame.onRepositoryFilesReceive();
	
} public void onFileListRefresh() {

	try {
		SendString(Globals.RefreshFileListCommand);
		if (!(isAPPLET)) {
		   //System.out.println("fatto sendObject: mando file");
		   sendObject(
			   new LoginFiles( 
				   frame.labNick.getText() ) );
		   //System.out.println(" file mandati....");
		}   
	} catch (IOException ex) {
		ex.printStackTrace();
		stop();
	}
	
}private void readPropertyFile() throws IOException {

	p = new Properties();
	try {
	   p.load(new FileInputStream(
		       userDir 
			   + File.separator
			   + Globals.ChatProperties
			   + File.separator 
			   + "client-config.props" ));
		                      
	}
	catch (IOException e) {
		System.err.println("errore su lettura client-config.props");
		e.printStackTrace();
		throw new IOException("errore su lettura client-config.props");
	}
}public void reInit(Socket server) {

	this.server = server;
	
	try {
		//PolicyEngine.assertPermission(PermissionID.FILEIO);
		//System.out.println("init di ChatCliente");
		
		if (isAPPLET)	{
 		  //porta = Integer.parseInt(getParameter("porta"));
	      URL Url = getCodeBase();
	      //System.out.println("init di ChatCliente Applet, URL = :" + Url.toString());
		  GIFs = getGIFs(Url);
		}
		else {
		  //System.out.println("init di ChatCliente StandAlone");	
	      System.out.println("UserDir = "+ userDir);	
		  //readPropertyFile();//il file delle propriot� risiede sul client
		                     //solo nel caso di applic. stand alone.	  
		  GIFs = getGIFsNoApplet();  	    
		}
		frame = new ChatFrame(title, this, isAPPLET);
		//System.out.println("init di ChatCliente fatto, ChatFrame aperta");
		
	} catch (java.lang.Throwable ivjExc) {

		handleException(ivjExc);
	}

	start();
	run();
}

public void getSocket() throws Exception {
	
	try {
		//PolicyEngine.assertPermission(PermissionID.FILEIO);
		System.out.println(" ..connecting to "+ ipAddr + " , port " + porta );
		server = new Socket(ipAddr, porta);

	} catch (Exception e) {
	    sendDiagn("Attenzione !", "7", false);	
		System.err.println("socket non riuscito ");
	    //e.printStackTrace();
		//throw new Exception("socket non riuscito");
		
	// --------## asteriscato per la vesione trial-ripistinare i punti ##-----------
	//
	//------------nel caso in cui il server � off-line
	//------------il processo pinga il server per capire quando viene attivato
	//            da ripristinare nella versione definitiva, 
	//            funziona, ma ora confonderebbe le idee
	//
	//##	new ChatServerSniffer(this, ipAddr, porta);
	//##	exit();
	//
	//--------------------------------------------------------
	}

	//----------------------------SplashScreen Formica
	//Thread.sleep(5000);
	//if (!(isAPPLET)) new SplashScreenWindow();
	//--------------- non funziona bene, perch�?----------
	
}

private boolean getInitParametri() throws IOException, NumberFormatException {
	
	if (!(isAPPLET)) {	
	   readPropertyFile();//il file delle propriet� client-config.props risiede sul client
		                  //solo nel caso di applic. stand alone.	  	
	   if (!getPropertyParams()) { 
	   	  sendDiagn("Attento!", "21", false);
	   	  return false; 
	   	} 
	}
	else {
	   //nell'Applet = ip address del server	   
	   ipAddr = getParameter("host");
	   porta = Integer.parseInt(getParameter("porta"));
	}
	return true;
}

public void onDiagn(String line){

	if (line.indexOf(Globals.DuplicateNick) == 0) {
		sendDiagn("T'ha detto male !", line.substring(4, 5), false);
		frame.labNick.setText(Globals.NickNonImpostato);
		frame.onAutentication();
	}

	else if (line.indexOf(Globals.YetRegistredNick) == 0) {
		sendDiagn("Mi dispiace...", "15", false);//Questo nick � gi� stato registrato
		frame.labNick.setText(Globals.NickNonImpostato);
		frame.onAutentication();
	}
	else if (line.indexOf(Globals.NotRegistredNick) == 0) {
		sendDiagn("Attenzione...", "19", false);//Non sei ancora registrato
		frame.labNick.setText(Globals.NickNonImpostato);
		frame.onAutentication();
	}
	else if (line.indexOf(Globals.PasswErrata) == 0) { //pwd errata
		sendDiagn("Attenzione...", "20", false);//Non sei ancora registrato
		frame.labNick.setText(Globals.NickNonImpostato);
		frame.onAutentication();
	}

	else if (line.indexOf(Globals.MailForYou) == 0) {
		sendDiagn("Buone notizie...", "17", false);//posta per te
//		frame.onNewMailForYou();
	}
	else if (line.indexOf(Globals.NoMailForYou) == 0) {
		sendDiagn("Peccato...", "18", false);//no posta per te
	}

	else if (line.indexOf(Globals.NewRegistredNick) == 0) {
		sendDiagn("Complimenti!", "16", false);//set stato registrato
	}

	else if (line.indexOf(Globals.BlankNick) == 0) {
		sendDiagn("..E' necessario autenticarsi !", 
		           line.substring(4, 5), false);
		//frame.txInput.setText("nick ");
	}
	if (line.indexOf(Globals.VocalBusyCommand) == 0) {
		//l'interlocutore � occupato
		sendDiagn("Interrompi la chiamata!", "25", false);
		
	} else
	if (line.indexOf(Globals.VocalRefusedCommand) == 0) {
		//l'interlocutore � occupato
		sendDiagn("Interrompi la chiamata!", "24", false);
	} 
	
	
}

public int onLogin(String command, String str) {

	if (str.trim().equals("")) {
		onDiagn(Globals.BlankNick);
		return -1;
	}
	isChecked = true;
	try {
		
		//SendString(Globals.ChatLoginCommand + str);
		SendString(command + str);
		sendMyFileList();
		
		//if (!(isAPPLET)) {
		   //System.out.println("fatto sendObject: mando file");
		//   sendObject(
		//	   new LoginFiles( 
		//		   frame.labNick.getText() ) );
		   //System.out.println(" file mandati....");
		//}   
	} catch (IOException ex) {
		ex.printStackTrace();
		stop();
	}
	return 0;	
}

public void onOpenForumRequest(String forumName) throws IOException {

	this.forumName = forumName;
	try {
	   SendString(Globals.FileForumRequestCommand + forumName);
	}
	catch (IOException e) {
		e.printStackTrace();
		stop();
	}
}	
	
public void onUpdStatisticheRoom() throws IOException {

		try {
		   SendString(Globals.RoomUpdStatistiche);	  
		}
		catch (IOException e) {
			e.printStackTrace();
			stop();
		}
	
}

public void startFtpDonatore(String nomeFile, InetAddress addressRichiedente)
	throws Exception {

	try {
		new FtpClient(nomeFile, addressRichiedente).start();
		//System.out.println("PArtito FtpClient");
	} catch (Exception e) {
		e.printStackTrace();
		new Exception("startFtpDonatore, Eccezione su FtpClient ");
	}

}

public void onREWRequest(MyVectorInterventi registroInterventi) 
   throws IOException, Exception {

 for (Enumeration e = registroInterventi.elements(); e.hasMoreElements(); )	  
	 checkInput (e.nextElement());	 
}


private int onVideoReceive(Target target) throws IOException { 

	if (video!=null && target.Action == Target.STOP_CONFERENCING) {
	   video.close();
	   video=null;
	   nickAdm.setVideoConferencing_Busy(false);
	   return Target.CONFERENCING_STOPPED;
	}
	
	if (nickAdm.isVideoConferencing_Busy())
		return Target.CONFERENCING_BUSY_PORT;
	
    video = new MyVideoAudioReceiver( 
   		seekNickIPAddress(target.getSenderNick()), target);	
    nickAdm.setVideoConferencing_Busy(true);
    return Target.CONFERENCING_STARTED;
    
}


public void onREWRoomRequest(MyVectorInterventiRoom registroInterventi) 
   throws IOException, Exception {

 for (Enumeration e = registroInterventi.elements(); e.hasMoreElements(); )	{ 
 
	Object str0 = e.nextElement();
	String str = (String) str0; 
	if (str.substring(7).indexOf(Globals.SendGIFCommand) > 0)
	   room.onGIFReceive(str.substring(7));
	else   	
	   room.AddText(str.substring(7));
 }	   	 
}

public void onViewForum(Object o) throws IOException {

   StringBuffer sb = new StringBuffer();
   sb = (StringBuffer) o;
   String drive = userDir.substring(0, userDir.indexOf(":") +1);
   ChatFileManager fm = new ChatFileManager(
	    drive + File.separator + "MieiFiles" 
	    + File.separator + forumName);
   fm.write(sb);
   fm.display();

   
}

public void reconnect() {
	
	try {
	    
	  	if (isChecked)	SendString( Globals.QuitCommand );
		ChatCliente cli = new ChatCliente();
		cli.isAPPLET = false;
		cli.init();
		cli.start();
	}
	catch ( IOException e ) { e.printStackTrace(); }	
}

  public void sendMyFileList() throws IOException {

	if (!(isAPPLET)) {
	   //System.out.println("fatto sendObject: mando file");
	   sendObject( new LoginFiles( frame.labNick.getText() ) );
	  //System.out.println(" file mandati....");
	}   
  }
  
  public String seekNickIPAddress(String nick) { 
		return regFil.seekNickIPAddress(nick);
  }
  
}