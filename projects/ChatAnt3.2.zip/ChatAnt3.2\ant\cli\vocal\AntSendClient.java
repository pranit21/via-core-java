package ant.cli.vocal;

import java.net.*;
import java.io.*;

import javax.sound.sampled.*;
import ant.awt.AntProgressBar;
import ant.awt.TextDisplayField;
import ant.cli.vocal.panel.*;
import ant.glob.Globals;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class AntSendClient implements Runnable, LineListener
    {

    public boolean lineaOK = false;
	InetAddress  servAddr;
	private int porta, contPorta, broadPort;
	private TextDisplayField labLog;
	private AntProgressBar prgBar;
	private String host;
	private AudioFormat format;
	private DatagramPacket sendPacket;
	private DatagramSocket socketUDP;
	private Socket socketIP;
	private TargetDataLine line;
	int i = 0;
	int frameSecondo = 0;
	int somma = 0, ss = 0;
	double idx = 0;
	//int idxx;
	boolean Strascico = false;
	int CICLI = 10;
	int cicli;
	int bufferLengthInBytes;

	//private static final int SOGLIA = 6300; 50 cicli di isSilence()
	//private static final int SOGLIA = 11340; //90 cicli di isSilence()
	private static final int SOGLIA = 22680; //180 --> n.b. in ufficio faceva 22860
	private int SogliaReale = 0;
	private static final int SOGLIA_RIDOTTA = SOGLIA - 360;
	private static final int SOGLIA_PER_BYTE = 127;
	//private LightProgressBar bar = new LightProgressBar(SOGLIA_PER_BYTE);

//leggo da mirofono e scrivo su stream

	private Thread thread;
	private boolean sock_close = true;
	private boolean STOP = false;
	private boolean checkSilence = true;
	String codecType;

	//private static final double SOGLIA2 = 2.95; //1.92; //1.73

	boolean Parlo, sended;

	SilenceDetector detector;
	boolean BroadTransmit;
	DataOutputStream outStream;
	private static int MAX_PORTS_OPENED = 4;
	boolean IP_Protocol;
	static final int BIT = 8;
	//Packetizer packetizer;

//leggo da streal e scrivo su dispositivo output (casse)

  public AntSendClient(String host, int porta ) throws LineUnavailableException {

     this (host, porta, null, null);
  }


  public AntSendClient(String host, int porta,
	  TextDisplayField labLog, AntProgressBar prgBar ) throws LineUnavailableException {

	 this(host, porta, labLog, prgBar, Globals.VoIP_Protocol, 
	  		true, ""
	  		);  

  }

  public AntSendClient(String host, int porta,
            TextDisplayField labLog, AntProgressBar prgBar, 
            String VoIP_Protocol ,
			boolean checkSilence, String codecType
  )
                   throws LineUnavailableException {

	 System.out.println ("-- AntSendClient inzializzato on port " + porta);

	this.labLog = labLog;
	this.prgBar = prgBar;
	this.host = host;
	this.porta = porta;
	
    this.IP_Protocol = (VoIP_Protocol.equals("IP") ? true : false );  

	format = new AudioFormatFactory().getFormat(BIT);
    //format = new AudioFormatFactory().getFormatGSM();
    
  }
  
  public AntSendClient(SendVoiceParameters param)
					throws LineUnavailableException {

	 System.out.println ("-- AntSendClient inzializzato on port " + porta);

	 this.labLog = param.labLog;
	 this.prgBar = param.prgBar;
	 this.host = param.selectedNick;
	 this.porta = param.porta;
	 this.IP_Protocol = (param.protocol.equals("IP") ? true : false ); 
	 this.codecType = param.codecType;
	 this.checkSilence = param.checkSilence;
	 format = new AudioFormatFactory().getFormat(BIT);
	 
	 System.out.println ("\t--  selectedNick: " + host);
	 System.out.println ("\t--  porta: " + porta);
	 System.out.println ("\t--  protocol: " + param.protocol);
	 System.out.println ("\t--  selectedNick: " + host);
	 System.out.println ("\t--  checkSilence: " + checkSilence);
  } 

private boolean isGSM(){
	return codecType.equals("GSM");
}


  public void start() {
		thread = new Thread(this);
		thread.start();
	}

 public void run() {

  try {
  	    
  	    //Thread.sleep(1000); appena levato
	    if (labLog != null) labLog.setText("..Send (mic) in attesa di connessione su porta " + porta);

		//	nell'istruzione sotto ottengo l' indirizzo del CLIENT, cio� di me stesso e non va bene!
		//  InetAddress  servAddr = InetAddress.getLocalHost(); //indirizzo del SERVER
	
		//  ottengo l' indirizzo di chi fa da  SERVER casse (per il Vocal), OK!
		servAddr = InetAddress.getByName(host);
		System.out.println(".. AntSendClient, getLocalHost di chi mi ascolta: " + servAddr);

        connect();

		detector = new SilenceDetector(checkSilence);
		//packetizer = new Packetizer();
	    sock_close = false;

		DataLine.Info info = new DataLine.Info(TargetDataLine.class,format);
	    line = (TargetDataLine) AudioSystem.getLine(info);
		//line.open(format,line.getBufferSize()); //errato dava 500 anziche 512

		System.out.println(".. AntSendClient: opening line");    
	    line.addLineListener(this);
	    
	
	lineaOK = false;    

		try {
							    	
			System.out.println(".. AntSendClient: provo ad aprire la linea");
		    System.out.println("...... " +line.getFormat().toString());
			checkOpenLine();
			
			line.open(format, 4096 * (BIT/8));
			lineaOK = true;
			 
		} catch (LineUnavailableException e) { 
			lineaOK = false;
			chiudiSocket();
			line.stop();
			e.printStackTrace();
			throw new LineUnavailableException(); 
		}

		
	    //line.open(format, 4096 * (BIT/8)); //512
		System.out.println(".. AntSendClient: line opened !!!!");   
	    if (labLog != null) labLog.setText(".. AntSendClient: mic attivato");

		int frameSizeInBytes = format.getFrameSize();
		int bufferLengthInFrames = line.getBufferSize() / BIT;
		bufferLengthInBytes = bufferLengthInFrames * frameSizeInBytes;
		byte[] data = new byte[bufferLengthInBytes];

		  System.out.println("--" + format.toString());
		  System.out.println("-- sampleRate = " + format.getSampleRate());
		  System.out.println("-- frameSizeInBytes = "+ frameSizeInBytes );
		  System.out.println("-- getBufferSize = "+ line.getBufferSize() );
		  System.out.println("-- bufferLengthInFrames = "+ bufferLengthInFrames );
		  System.out.println("-- bufferLengthInBytes = "+ bufferLengthInBytes );
		  System.out.println("-- data.length = "+ data.length ); //=500

	line.start();
	
	//-----------------
	// determina di volta in volta la soglia del silenzio
	  if (checkSilence) {  
	  	
		new ThresholdDetector(this, detector, line, bufferLengthInBytes).start();
	    System.out.println("lanciato detecrot e mi blocco");
	    semaforo(); //aggiunto
	    System.out.println("finito detector");
		//Thread.sleep(1000); //prima
	  }  
	//-----------------

	int cont = 0;
	//contPorta = 0;

	if (labLog != null) labLog.setText(".. client connesso !");
	System.out.println(".. AntSendClient : connesso!");

	while (line.read(data,0,bufferLengthInBytes)!=-1 && STOP == false) { //data.length=500 perch� non 512 ?

		
		 if (!IP_Protocol)  {
		    sendPacket = new DatagramPacket(
		                  data, bufferLengthInBytes, servAddr,
		                  //getPorta() //getione multiporta
		                  porta );
	     }	      
		 send(data);
		 line.flush(); //AGGIUNTO
	}


  } catch (SocketException e) {
		  System.out.println("..AntSendClient: SocketException! ");
		  e.printStackTrace();


 } catch (LineUnavailableException e) {
	     System.out.println("..SendClient: Linea occupata! ");
	     if (labLog != null) labLog.setText("Linea occupata!");
		 System.out.println("..Linea occupata! ");
		 e.printStackTrace();
	     //throw new LineUnavailableException("...Linea accupata");


 } catch (Exception e) {
		System.out.println("AntSendClient: eccezione : " + e.toString());
		e.printStackTrace();

 }

 finally {


 }

}


private void checkOpenLine() {
	if (line.isOpen()){
		System.out.println(".. AntSendClient: ERRORE , LA LINEA E APERTA");
		 line.close(); }
	if (line.isActive()) {
		System.out.println(".. AntSendClient: ERRORE , LA LINEA E ATTIVA");
		line.close();} 
}

public void update(LineEvent e) {
	System.out.println("---------- lineEvent---------");
	System.out.println("FramePosition = " + e.getFramePosition());
	System.out.println("---------- lineEvent---------");
	//System.out.println("UPDATE!!!!!!!!!!!!!!!!!!!!! qualcosa � successo");
}

 private void connect() 
   throws SocketException, IOException, InterruptedException {
 
	if (!IP_Protocol)
	   socketUDP = new DatagramSocket();
	else {	
	   connectIP(); 			
	}
 }

 private void connectIP() throws InterruptedException,IOException {

    boolean Connected = false;
    while (! Connected) { 
		 Connected = true;  	   	
	     Thread.sleep(3000); 	
		try {
			 System.out.println("... AntSendClient: Trying IP connection.... ");
			 socketIP = new Socket(servAddr, porta);	 
		} catch (IOException e) { Connected = false; }
    } //end while
	outStream = new DataOutputStream(socketIP.getOutputStream());
 }
 
  private void send(byte[] data) throws java.io.IOException {
        
        if (!IP_Protocol) { //** UDP Protocol ** 
		   sended = detector.send(socketUDP, data, sendPacket); //controlla anche isSilence
/* ------------- in alternativa a sopra:	   packetizza e non controlla isSilence
           	data = detector.packetize( data ); // packetizza e non isSilence
		    if (data != null)  {
		    	System.out.println("--- client: send data");
				sendPacket = new DatagramPacket(
				          data, bufferLengthInBytes*4, servAddr, porta );	    		    	
		    	socketUDP.send( sendPacket );
	    	} 
*/		//	fine in alternativa a sopra:

        } else  //** IP Protocol ** 
		    sended = detector.send(socketIP, data, outStream);

	    if (sended) {
	    	updateWindowBar( (int) detector.getSomma() / 256 );
			//System.out.println("---  parlo da porta "+ broadPort);
			//System.out.println("---parlo");  
	    }
	
  }

 public void updateWindowBar(int val) {
	   if (prgBar != null) prgBar.setValue(val);
 }

 private void chiudiSocket() {

 try {
 
	 if (!sock_close) {
		 if (!IP_Protocol)  socketUDP.close();
		 else               socketIP.close();
		 sock_close = true;
	 }
	 
 } catch (IOException e) {
   e.printStackTrace();
 }
 
 }

 public void cancel() {
	STOP = true;

	chiudiSocket();
	//line.drain(); provo a levarlo
	if (line!=null) {
		line.stop(); 
		line.close();
		line=null;
	}
	thread = null;
	System.out.println("=======cancel======== AntSendClient, chiamata conclusa");
	if(labLog != null)labLog.setText("..Send, chiamata conclusa");


/*
	line.drain();
	line.stop();
	line.close();
	if (!sock_close) socket.close();
	sock_close = true;
	thread = null;
	System.out.println("AntSendClient: closed");
*/
 }

 //public synchronized void startThresholdDetector(
 //   SilenceDetector detector, TargetDataLine line, int bufferLengthInBytes) {
 public synchronized void semaforo() {
	
	 //while (true) {
		 
		  notify();
		  try {
			 wait();
			
		 } catch (InterruptedException e) {
			
			 e.printStackTrace();
		 }
		
	 //}
 }



 public void setStop() {
	STOP = true;

 }


 private int getPorta() {

   //mai utilizzato: sembra che non serva a niente splittare i pacchhetti
   // su pi� porte (BroadTransmit)

   if (!BroadTransmit) return porta;

   if (contPorta > MAX_PORTS_OPENED) {
	   contPorta = 0;
	   broadPort = porta;
	   return porta;
   }
   else {
	   contPorta++;
	   return broadPort++;
   }

 }



}