/*
 * Created on 22-mag-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ant.serv;

import java.util.Vector;
import java.util.Enumeration;
import java.io.IOException;
import ant.dyn.Target;
import ant.dyn.TargetVideoVector;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class VideoCommandChecker {
	ChatServer c;
	DBNick dbNick;
	
	VideoCommandChecker(DBNick dbNick){
	   
	   this.dbNick = dbNick;
	
	}
	
  private void broadcast(Vector target) {
  	
  	for (Enumeration e=target.elements(); e.hasMoreElements();) {
	  	 Target t = (Target)e.nextElement();
  		 String nickRicevente = t.getReceiverNick();
	  	 ChatServer c = dbNick.getThread( nickRicevente ); 
	  	 try {
	  	 c.oObjStream.writeObject ( t );    
	  	 } catch (IOException ex) {
	  	 c.interrupt();
	  	 }
  	}
  	
  }
  
  public void verificaComandi(Object o) {
  	
  	Vector target = (TargetVideoVector) o;
  	
  	broadcast(target);
  	/*
  	String nickRicevente = target.getReceiverNick();
  	
	ChatServer c = dbNick.getThread( nickRicevente ); 
	try {
		c.oObjStream.writeObject ( target );    
	} catch (IOException ex) {
		c.interrupt();
	}
	*/
  }

}
