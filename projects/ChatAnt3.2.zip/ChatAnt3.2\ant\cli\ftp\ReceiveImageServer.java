package ant.cli.ftp;
import java.net.*;
import java.io.*;

import ant.cli.panels.ChatFinListaFile;
import ant.cli.video.AntVideoFrameGrabbing;
import ant.dyn.RegistroDownload;
import ant.awt.LabLog;
import java.awt.Component;
import ant.awt.PanelMesg;
import java.awt.Image;

import javax.media.*;
import javax.media.format.*;
import javax.media.util.*;
import javax.media.control.*;
import javax.media.protocol.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import com.sun.image.codec.jpeg.*;
import javax.imageio.stream.*;
import ant.cli.video.ShowImageGrabbedPanel;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ReceiveImageServer extends Thread {

	private boolean DEBUG = false;
	private String chiManda;
	private ShowImageGrabbedPanel viewer; 
	boolean Stop;
	int numBytes;
	protected BufferedInputStream iStream;
	protected BufferedOutputStream oStream;
	public Thread thread;

	public Socket client;
	public String nomeFile;
	public String nickDonatore;
	public RegistroDownload regdow;

	public ServerSocket server;
	private LabLog labLog;
	private Component MesgValues =
		 new PanelMesg( "Download successful !", PanelMesg.ModeInfo );
	public ChatFinListaFile parent;

	private RegistroDownload listaFiles;

public void run()  {

 int cont=0;
 
 try {

	  server = (server == null) ? new ServerSocket(9990) : server;	
	  System.out.println ("========== ReceiveImage, in attesa di connessioni !");
	  //client = server.accept ();
	  //if (DEBUG) System.out.println ("==== ReceiveImage, donatore : " + client.getInetAddress ());	
	
	  //BufferedInputStream in = new BufferedInputStream( client.getInputStream ());
	  //  DataInputStream iStream = new DataInputStream( client.getInputStream () );
	  //  ByteArrayOutputStream oStream = new ByteArrayOutputStream();
	 
	  //------------- ok (*)
	  //byte buf[] = new byte[ numBytes ]; OK
	  //----------------------------
	  int BufferSize = 2048;  
	  byte buf[] = new byte[ BufferSize ];  
	  int n;
	  int totBytes=0;
	
	/* OLD OK (*)
		while ( ( n = iStream.read( buf, 0, numBytes ) ) != -1 ) {
		  totBytes += numBytes;
		}
	*/
	while (Stop = true) {
		client = server.accept();		
		DataInputStream iStream = new DataInputStream( client.getInputStream () );
		ByteArrayOutputStream oStream = new ByteArrayOutputStream();
		if (DEBUG) System.out.println("------>>> receiveImage : aperto input stream!!!");	
		
		cont++;
		while ( ( n = iStream.read( buf, 0, BufferSize ) ) != -1 ) {
			//	  oStream.write( buf );
		  oStream.write( buf, 0, n );
		  totBytes = totBytes + BufferSize;  
		}
	    System.out.println("------>>> receiveImage : ricevuti byte!!! : "+totBytes);	
		iStream.close();
	    		
	    //java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit(); 
	    //Image img = tk.createImage(buf);
		//System.out.println("------ receiveImage : immagine creata !");
	     
		//------------------------------------    
		//0k	(*)
		//ByteArrayInputStream stream = new ByteArrayInputStream(buf);
		//BufferedImage bufImg  = javax.imageio.ImageIO.read(stream);
	   //--------------------------------------
	    byte[] buf2 = oStream.toByteArray();
	    oStream.close();
	    ByteArrayInputStream stream = new ByteArrayInputStream(buf2);
	    BufferedImage bufImg  = javax.imageio.ImageIO.read(stream);
	    //AntVideoFrameGrabbing.saveJPG(bufImg,"c:\\myVideoCapture99.jpg");
	  
	   //apre il pannello per visualizzare l'immagine
	    if (cont==1) 
	   	  viewer =  new ShowImageGrabbedPanel(this, bufImg, chiManda);
	    else { 
	   	  if (DEBUG) System.out.println ("-----ReceiveImage: refreshMonitor");
	   	  viewer.refreshMonitor(bufImg);
	    }
	    
	    //Thread.sleep(5000);

 } //FINE WHILE X ogni Immagine ricevuta

} catch (java.net.BindException ex) {
	ex.printStackTrace();
	close();
	//labLog.setText("..Attendere: up/downLoading in corso sul tuo PC");
	//labLog.setColor(java.awt.Color.pink);
} catch (Exception ex) {
	System.out.println ("-----ReceiveImage: errore ricezione dati: ");
	ex.printStackTrace ();
	close();
}

if (null != client) {
   System.out.println( "======== ReceiveImage: Chiudo la connessione con "+client.getInetAddress() ) ;
   try {
	  client.close ();
	  }
   catch (IOException e) { 
	  System.out.println( "------ReceiveImage: errore close socket " + e.getMessage() );
	  e.printStackTrace();
	  }
 }

try {
  if ( server != null )  server.close();
  thread = null;
  interrupt();
  } 
catch (IOException e) {
  System.out.println( "------ReceiveImage: errore close socket " +e);
  }

}

public void start () {

	if (thread == null) {
		thread = new Thread(this);
		thread.start();
	}

}     	 	 	 	 	 	 	 

public void close() {
	
	try {
		if ( server != null )  
			server.close();
		if ( client != null ) 
			client.close ();
		interrupt();
		stop();
		client=null;
		thread = null;
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public ReceiveImageServer(String nomeFile, ChatFinListaFile parent) 
   throws IOException {
	   
	  this.nomeFile = nomeFile;
	  this.parent = parent;
   }                     

 public ReceiveImageServer(int numbytes, String chiManda) 
	  throws IOException {
	  this.numBytes = numbytes;
	  this.chiManda = chiManda; 
 }  

public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}

public static void saveJPG(Image img, String s)
{
  BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
  Graphics2D g2 = bi.createGraphics();
  g2.drawImage(img, null, null);

  FileOutputStream out = null;
  try
  { 
	out = new FileOutputStream(s); 
  }
  catch (java.io.FileNotFoundException io)
  { 
	System.out.println("File Not Found"); 
  }
    
  JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
	
  JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bi);
  param.setQuality(0.5f,false);
  encoder.setJPEGEncodeParam(param);
    
  try 
  { 
	encoder.encode(bi); 
	out.close(); 
  }
  catch (java.io.IOException io) 
  {
	System.out.println("IOException"); 
  }
}
  

}