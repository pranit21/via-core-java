package ant.cli.util;

import java.awt.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ContaSecondi  extends Label implements Runnable {
		
	    public int sec = 0;
		public int min = 0;
		public int ore = 0;
	    private boolean Interrupt = false;
		String ora;
		Thread tr;


public ContaSecondi()  {
	
	azzera();
	Interrupt=false;

}

private void azzera() {

  setText("00:00:00");
  sec = 0; min = 0; ore = 0;
}

  public void stop() {
	
		if (tr != null) {
			
			tr.interrupt();
		    Interrupt = true;
	        tr = null;
        }   
		azzera();
   }


public void run() {
	
  try {
	
	//for (;;)
	while (!Interrupt)

	{
		  sec++;
			
		  if (sec == 60) {
			  sec = 0;
			  min++;
	      }

	      if (min == 60) {
		  	  min = 0;
		  	  ore++;
	      }

		  ora = String.valueOf(ore)
		        + ":" + formatNum( min )
		        + ":" + formatNum( sec );
		  setText(ora);
		  

		  Thread.sleep(1000);

		  

	
  } //fine for

		
  }  catch(InterruptedException e)
			  {
			  }  
  finally {
		 stop();
		
	   }
  
}





	public void start() {
			//Thread d = new Daemon();
	        //d.setDaemon(true);

		        azzera();
			    Interrupt=false;
	            tr = new Thread(this);
	            tr.setDaemon(true);
	            tr.start();



			//run();
	}
	
private String formatNum(int num) {

  return (num < 10) ? '0' + String.valueOf( num )
					:  	    String.valueOf( num );
}}