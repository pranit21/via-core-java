package ant.awt;
import java.awt.Window;
import java.awt.Frame;
import java.awt.MediaTracker;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Graphics;

import java.io.File;import ant.glob.Globals;public class SplashScreenWindow extends Window {


	/*
	 *  * This file is part of ChatAnt

	ChatAnt is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	ChatAnt is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


	Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
	 */
 Image splashImage;

public SplashScreenWindow() {
  super(new Frame());

  splashImage = getFormica();
  //Toolkit.getDefaultToolkit().getImage(imgName);

  MediaTracker mt = new MediaTracker(this);
  mt.addImage(splashImage,0);
  try {
	mt.waitForID(0);
  } catch (InterruptedException e) {}
		
  showSplashScreen();
  
  try {
   Thread.sleep(4000);
  } catch (InterruptedException e) {}
  
  hideSplashScreen();
  //System.exit(0);

} 

 public void showSplashScreen() {
  // Calcola le dimensioni
  int w = splashImage.getWidth(null);
  int h = splashImage.getHeight(null);
  // Dimensiona la finestra
  setSize(w,h);
  // Centra la finestra sullo schermo
  Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
  setLocation((d.width - w) / 2,(d.height - h) / 2);
  // Mostra la finestra
  setVisible(true);
 }  

 public void hideSplashScreen() {
  setVisible(false);
  dispose();
 }  

 public void paint(Graphics g) {
  g.drawImage(splashImage,0,0,null);
 }  

 public static void main(String args[]) {
  SplashScreenWindow sst = new SplashScreenWindow();
  sst.showSplashScreen();
  try {
   Thread.sleep(10000);
  } catch (InterruptedException e) {}
  sst.hideSplashScreen();
  System.exit(0);
 }    

public Image getFormica() {

	// solo per la versione TRIAL Stand alone !!!
	//questo metodo da errore nell'Applet
	
	//Image appImg = null;
	String userDir = System.getProperty("user.dir");
	
	return  Toolkit.getDefaultToolkit().getImage(
	   userDir 
	   + File.separator
	   + Globals.DirGIF 
	   + File.separator 
	   + "FORMICA.jpg" );
 	        
	// return Formica;
}}