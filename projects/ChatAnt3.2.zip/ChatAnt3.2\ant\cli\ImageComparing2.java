/*
 * Created on Nov 24, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli;
import java.awt.*;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ImageComparing2 {

	int totaleDifferenze;
	long sommaQuadrati;
	int nOsservazioni;
	
	public static void main(String[] args) {
		
		//Ringer rng = new Ringer();
		//rng.start();
		
		boolean uno = false;
		boolean due = true;
		System.out.println ( uno | due ) ; 
		
		//MicSpkLevels ms = new MicSpkLevels();
		//ms.show(); 
		
		ImageComparing2 p = new ImageComparing2();
		p.fai();
		
	}
		
	private void fai() {


		
		long t = System.currentTimeMillis();
		BufferedImage image=null ;
		try {
			image = ImageIO.read(new File("c:\\semafiri2.jpg"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			
		}
		
		
		//RenderedOP = inputR01 = JAI.create("fileload", "c:\\semafiri2.jpg");
		
		//TiledImage tile1 = new TiledImage();
		System.out.println(System.currentTimeMillis() - t);
		
		
		
		Image appImg = Toolkit.getDefaultToolkit().getImage(		
		   "C:" 
		   + File.separator
		   + "semafiri2.jpg" );
		   
	
		//System.out.println(System.currentTimeMillis() - t2);

		Image appImg2 = Toolkit.getDefaultToolkit().getImage(		
		   "C:" 
		   + File.separator
		   + "semafiri2_test.jpg" ); //semafiri2_test
	
	
		ant.awt.ImageContainer frame = new ant.awt.ImageContainer();
		frame.setImage(appImg2);  
		//System.out.println(System.currentTimeMillis() - t2);
			
		//handlepixels(appImg, appImg2, 0,0,100,100);
		
	
		//int w = appImg.getWidth(null);       
		//System.out.println("..........." + w);

		//lavora su BufferedImage
		int h = image.getRaster().getHeight();
		int w = image.getRaster().getWidth();
		//DataBufferInt buf = (DataBufferInt) image.getRaster().getDataBuffer();
		//int data1[] = buf.getData();
		
		
		System.out.println("..........." + h + ", " + w);

		long t2 = System.currentTimeMillis();
		
		
		
	
		w = 80;
		//int h4 = h/4;
		int w4 = 80/4;
			int memH=0, memW=0;
		
		w=0; h=131;
		
		for (int larg = 1; larg < 5; larg++) {
					   	
		   handlepixels(appImg, appImg2, (w)  ,0, 20, h);
		   System.out.println("... " +(w==0?0:w+1) + ", " +0+ ", " +20+ ", "+h+ " ");
		   w+=w4;
		}
		
		
		System.out.println("--------------fien elaborazione per slices");
		
		
		handlepixels(appImg, appImg2, 0,0,80,131);
		
		System.out.println(System.currentTimeMillis() - t2);		
		
	}
	
	
	
	
	/*
	 public static BufferedImage toBufferedImage(Image image) {       
	 	 new ImageIcon(image); //load image        
	 	 int w = image.getWidth(null);       
	 	  int h = image.getHeight(null);        
	 	  BufferedImage bimage = new BufferedImage(w, h, IMAGE_TYPE);       
	 	   //BufferedImage bimage = getDefaultConfiguration().createCompatibleImage(w, h, Transparency.OPAQUE);       
	 	    Graphics2D g = bimage.createGraphics();    
	 	        g.drawImage(image, 0, 0, null);     
	 	           g.dispose();        
	 	           return bimage;    
	 	           }
	*/
	
	
	
	
	
	public void handlesinglepixel(int x, int y, int pixel) {
		int alpha = (pixel >> 24) & 0xff;
		int red   = (pixel >> 16) & 0xff;
		int green = (pixel >>  8) & 0xff;
		int blue  = (pixel      ) & 0xff;
		
		//System.out.println("--- pixel = " + pixel);
		//System.out.print("   " + blue + "   " + red +  "   " + green );
		//System.out.println(" ");
		// Deal with the pixel as necessary...
		
	 }

	public int[] singlePixelValues(int x, int y, int pixel) {
		int alpha = (pixel >> 24) & 0xff;
		int red   = (pixel >> 16) & 0xff;
		int green = (pixel >>  8) & 0xff;
		int blue  = (pixel      ) & 0xff;
		
		//System.out.println("--- pixel = " + pixel);
		//System.out.print("   " + blue + "   " + red +  "   " + green );
		//System.out.println(" ");
		
		
		return new int[] {red,green,blue};
	}
	
	private int comparePixelRGB(int[] pix1, int[] pix2) {
	
	    int difference=0;
	    for (int i=0; i<3; i++) {
			difference += (pix1[i] - pix2[i]);
			sommaQuadrati+=difference*difference;
			nOsservazioni++;
	    }
	    
	    return difference;
	    
	}

	 public void handlepixelsBySlice(Image img, Image img2, int x, int y, int w, int h) {
		
		int[] pixels = new int[w * h];
		PixelGrabber pg = new PixelGrabber(img, x, y, w, h, pixels, 0, w);
		try {
			pg.grabPixels();
		} catch (InterruptedException e) {
			System.err.println("interrupted waiting for pixels!");
			return;
		}
		if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
			System.err.println("image fetch aborted or errored");
			return;
		}
		int[] pixels2 = new int[w * h];
		pg = new PixelGrabber(img2, x, y, w, h, pixels2, 0, w);
		try {
			pg.grabPixels();
		} catch (InterruptedException e) {
			System.err.println("interrupted waiting for pixels!");
			return;
		}

		//elaboro per fette orizzontali
		int h4 = h/4;
		int w4 = w/4;
		int memH=0, memW=0;
		h=0;
		w=0;
		
	  for (int slice = 0; slice < 4; slice++) {
	  	h+=h4;
	  	memW = w;
	  	    	
		for (int j = h; j < h4; j++) {
			w+=w4;
			
			
			for (int i = memW; i < w; i++) {
			   //handlesinglepixel(x+i, y+j, pixels[j * w + i]);
			   int[] pix1 = singlePixelValues(x+i, y+j, pixels[j * w + i]);
			   int[] pix2 = singlePixelValues(x+i, y+j, pixels2[j * w + i]);
			   int diff = comparePixelRGB(pix1, pix2);
			   totaleDifferenze += diff; 
			   System.out.println("diffe risc= " + diff);
			}
			System.out.println("differenza riscontrata = " + totaleDifferenze);
			totaleDifferenze=0;
		}
		
	  }	//for slice
	  
		System.out.println("--- totale differenza  = " + totaleDifferenze);
		System.out.println("--- RMS calcolato      = " + 
		     Math.sqrt(sommaQuadrati / nOsservazioni) );
	 }




	public void handlepixels(Image img, Image img2, int x, int y, int w, int h) {
		
	   int[] pixels = new int[w * h];
	   PixelGrabber pg = new PixelGrabber(img, x, y, w, h, pixels, 0, w);
	   try {
		   pg.grabPixels();
	   } catch (InterruptedException e) {
		   System.err.println("interrupted waiting for pixels!");
		   return;
	   }
	   if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
		   System.err.println("image fetch aborted or errored");
		   return;
	   }
	   int[] pixels2 = new int[w * h];
	   pg = new PixelGrabber(img2, x, y, w, h, pixels2, 0, w);
	   try {
		   pg.grabPixels();
	   } catch (InterruptedException e) {
		   System.err.println("interrupted waiting for pixels!");
		   return;
	   }

	   //elaboro per fette orizzontali
	   for (int j = 0; j < h; j++) {
		   //System.out.println("");
		   for (int i = 0; i < w; i++) {
			  //handlesinglepixel(x+i, y+j, pixels[j * w + i]);
			  int[] pix1 = singlePixelValues(x+i, y+j, pixels[j * w + i]);
			  int[] pix2 = singlePixelValues(x+i, y+j, pixels2[j * w + i]);
			  int diff = comparePixelRGB(pix1, pix2);
			  totaleDifferenze += diff; 
			  //System.out.println("differenza riscontrata = " + diff);
		   }
	   }
	   System.out.println("--- totale differenza  = " + totaleDifferenze);
	   System.out.println("--- RMS calcolato      = " + 
			Math.sqrt(sommaQuadrati / nOsservazioni) );
			
		nOsservazioni=0;			
		sommaQuadrati=0;
		totaleDifferenze=0;
	}

 

	
	
}
