package ant.awt;

import java.awt.Component;
import java.awt.Image;
//import java.awt.Color;
import java.awt.Panel;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Dimension;
import java.awt.FontMetrics;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class FacesPanel extends Panel {

  private String Title;
  protected static int contentGap = 1; //prima 5
  protected static int HSpan = 1;
  protected static int HGap = 1; //prima 2
  protected static int VGap = 1; //2
  protected static int Thickness = 1;
  protected static int TitleHGAP = 4; //prima 5
  protected boolean BorderUp;

  private boolean Up = true;
  private boolean Left = true;
  private boolean Reset = false;
  private Image img;
public FacesPanel() {

  this( "" );
}
public FacesPanel( Image img ) {

   this( "", img ); 
  }            
public FacesPanel( String Title ) {

  this( Title, null );
}  
public FacesPanel( String Title, Image img ) {

  this.Title = Title.trim();
  this.img = img;
  
}  
public void add( Image img ) {
	
  this.img = img;
  if (Reset) HSpan = 0;
  Reset = false;
  HSpan+=16;	
  repaint();	 

}
  public void add( Image img, boolean Reset ) {
	
  this.img = img;
  if (Reset) HSpan = 0;
  HSpan+=16;	
  repaint();	 

}
private void clearGIFs( Graphics g ) {

  Dimension dim = getSize();
  g.clearRect( 1, 1, dim.width, dim.height );
	           
}        
public Insets getInsets() {
// chiamato automaticamente da Layout Manager, come paint( g )

  int top,bottom;
  if ( Up ) {
	top    =  VGap + getTitleHeight() + contentGap;  // dist da margine sopra
	bottom =  VGap + Thickness + contentGap;         // dist da margine sotto
  }
  else {
	top    =  VGap + Thickness + contentGap; 
	bottom =  VGap + getTitleHeight() + contentGap;
  } 
  int left   =  HGap + Thickness + contentGap;         // dist da margine sin
  int right  =  left;                                  // dist da margine dex

  return new Insets( top, left, bottom, right );
}
protected int getTitleHeight() {
	
  int titleHeight = 0;
 
  FontMetrics fm = getFontMetrics( getFont() );
  if ( Title.length() != 0 )
	titleHeight = fm.getHeight();
  return titleHeight;
}
public void paint( Graphics g ) {

  if ( !(img == null ) )
	 g.drawImage(img, 1, 1, 16, 16, this);
	 	
  if ( Up && Left ) 
	paintUL( g );
  else {
	if ( !Up && Left )
	  paintDL( g );
	else {
	  if ( Up && !Left )
		paintUR( g );
	  else
		paintDR( g );
	}
  }
} 
private void paintDL( Graphics g ) {

}
private void paintDR( Graphics g ) {

  Dimension dim = getSize();
  FontMetrics fm = getFontMetrics( getFont() );
  int TitleHeight = getTitleHeight();
  
  //g.setFont( getFont() ); di default
  g.setColor( getBackground() );
 
  g.draw3DRect( HGap,
	            VGap, 
	            dim.width - 2*HGap,
	            dim.height - 2*VGap - TitleHeight/2,
	            BorderUp );
  g.draw3DRect( HGap + Thickness,
	            VGap + Thickness ,
	            dim.width - 2*(HGap + Thickness),
	            dim.height - 2*(VGap + Thickness) - TitleHeight/2,
	            ! BorderUp );

  if ( Title.length() == 0 ) return;
  g.setColor( getForeground() );
  g.clearRect( dim.width - HGap - TitleHGAP - fm.stringWidth( Title ),
	           dim.height - VGap - TitleHeight,
	           fm.stringWidth( Title ),
	           TitleHeight ); 
  g.drawString( Title,
	            dim.width - HGap - TitleHGAP - fm.stringWidth( Title ),
	            dim.height - VGap - fm.getDescent() );
}        
private void paintUL( Graphics g ) {
	
  Dimension dim = getSize();
  FontMetrics fm = getFontMetrics( getFont() );
  int TitleHeight = getTitleHeight();
  
  //g.setFont( getFont() ); di default
  g.setColor( getBackground() );
 
  g.draw3DRect( HGap,
	            VGap + TitleHeight/2, 
	            dim.width - 2*HGap,
	            dim.height - 2*VGap - TitleHeight/2,
	            BorderUp );
  g.draw3DRect( HGap + Thickness,
	            VGap + Thickness + TitleHeight/2,
	            dim.width - 2*(HGap + Thickness),
	            dim.height - 2*(VGap + Thickness) - TitleHeight/2,
	            ! BorderUp );

  if ( Title.length() == 0 ) return;
  g.setColor( getForeground() );
  g.clearRect( HGap + TitleHGAP,
	           VGap,
	           fm.stringWidth( Title ),
	           TitleHeight ); 
  g.drawString( Title, HGap + TitleHGAP, VGap + fm.getAscent() );
}  
private void paintUR( Graphics g ) {
/*	
  Dimension dim = getSize();
  FontMetrics fm = getFontMetrics( getFont() );
  int TitleHeight = getTitleHeight();
  
  //g.setFont( getFont() ); di default
  g.setColor( getBackground() );
 
  g.draw3DRect( HGap,
	            VGap + TitleHeight/2, 
	            dim.width - 2*HGap,
	            dim.height - 2*VGap - TitleHeight/2,
	            BorderUp );
  g.draw3DRect( HGap + Thickness,
	            VGap + Thickness + TitleHeight/2,
	            dim.width - 2*(HGap + Thickness),
	            dim.height - 2*(VGap + Thickness) - TitleHeight/2,
	            ! BorderUp );

  if ( Title.length() == 0 ) return;
  g.setColor( getForeground() );
  g.clearRect( HGap + TitleHGAP,
	           VGap,
	           fm.stringWidth( Title ),
	           TitleHeight ); 
  g.drawString( Title, HGap + TitleHGAP, VGap + fm.getAscent() );
*/}
public void reset() {
	
  Reset = true;
  repaint();

}
public void setTitlePosition( boolean Up, boolean Left ) {

  this.Up = Up;
  this.Left = Left;
}
public void update( Graphics g ) {

  if ( !( Reset ) )
	 g.drawImage(img, HSpan, 1, 16, 16, this);
  else {
	 clearGIFs( g );
	 //g.clearRect(1, 321, 600, 16);
  }	 
}
}