package ant.serv;

import java.io.*;
import java.util.*;

import ant.glob.Globals;
import ant.dyn.MyVectorInterventi;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatServerRooms extends ChatServerBase {
	
  private static Vector rooms = new Vector(); 
  private Room selectedRoom;

  //----------!! sostituisci tutti i getSelectedRoom con selectedRoom

  private int item, newItem;
  private String roomTitle;
  private ChatServer serv;
  private  DBNick dbNick;
  boolean NoExpiration = true;
  private String mess;
  
public void addNick() throws IOException {

	getSelectedRoom(item).addMember(nick, dbNick.getChatters());
	//rooms[item].addMember(nick, dbNick.getChatters());  	      
	//serv.dbChat.remove(nick);
	ChatServer.dbChat.remove(nick);
	
}
public void addRoom(String title) {

  rooms.add( new Room( title ) ); 
  roomBst.update(rooms, serv);  
  
  //roomTitles.add( title );
  
/*  Room oldRoom[] = rooms;
  int newCapacity = rooms.length + 1;
  rooms = new Room[ newCapacity ];
  System.arraycopy( oldRoom, 0, rooms, 0, newCapacity -1 );
  rooms[newCapacity -1] = new Room( title );
  
  String oldTitles[] = roomTitles;
  roomTitles = new String[ newCapacity ];
  System.arraycopy( oldTitles, 0, roomTitles, 0, newCapacity -1 );
  roomTitles[newCapacity -1] = title;
*/
}
public void avvisoPerTutti (Hashtable hash, String nick, String mess) { 

	Enumeration e = hash.elements();
	while (e.hasMoreElements ()) {
	  ChatServer c = null;
	  synchronized (hash) {
		   c = (ChatServer) e.nextElement ();
	  }
		try {
			// spedisco il messaggio al client, lo modifico aggiungendo il nick
			c.oObjStream.writeObject (mess+" "+ nick);
			
			} catch (IOException ex) {
		       c.interrupt();
	 	 }
	  
	}
  }                                                    
public void doLog( String line ) throws IOException {
	
	StringTokenizer st = new StringTokenizer(line.substring(7), 
		   Globals.FieldSeparator);
	
	 item = Integer.parseInt( st.nextToken() );	
	 nick = st.nextToken();
	
	addNick();
	
	aggiornaListaUtenti( getSelectedRoom(item).getChatters(), 
		Globals.RoomUpdateListCommand );
		
	//if (! isMember( nick ) ) {
	mess = Globals.RoomSpeakCommand + " .. � entrato ";
   	avvisoPerTutti(getSelectedRoom(item).getChatters(), nick, mess);
	  //}
	mess = Globals.NullCommand 
	       + " .. ed entra in " 
	       + getSelectedRoom(item).getTitle();
	       
	serv.avvisoPerTutti( ChatServer.dbChat.getChatters(), nick, mess);
	
	aggiornaListaUtenti( ChatServer.dbChat.getChatters(), Globals.UPD_MAIN_LIST );
	//aggiorna la lista della chat principale di tutti gli utenti della chat principale  

	//sendRoomTitlesToAll(); //RoomTitleCommand aggiorna i cruscotti e i record delle room
    //asterisco per prova
}
public void doQuit() throws IOException {
	
  transferNick();
  
  aggiornaListaUtenti( 
	  getSelectedRoom(item).getChatters(), Globals.RoomUpdateListCommand );
  
  mess = Globals.RoomSpeakCommand + " .. esce dalla stanza :";
  avvisoPerTutti( getSelectedRoom(item).getChatters(), nick, mess );

  mess = Globals.NullCommand + " .. rientra ";
  serv.avvisoPerTutti(ChatServer.dbChat.getChatters(), nick, mess);
  
  aggiornaListaUtenti( ChatServer.dbChat.getChatters(), Globals.UPD_MAIN_LIST ); 
  
  sendRoomTitlesToAll();
  
  serv.sendNumUtentiCollegati();
 }                    

public Room getSelectedRoom(int item) throws IOException {
	//System.out.println(">>>getSelectedRoom:item=" + item);
	//if ( item > rooms.size() -1 ) 
	//   throw new IOException(); //es. 8 (index deve essere < di size)
	//else   
	   return ( (Room)rooms.elementAt(item) );
}

public void onNewRoom(String title) throws IOException {

  msg = msg.substring(7);
  addRoom( msg );
  mess = Globals.NullCommand + 
		" .. � diponibile una nuova stanza : " + msg;
  serv.avvisoPerTutti(ChatServer.dbChat.getChatters(), "", mess);
  sendRoomTitlesToAll();
}
public void preLoginMessage() 
   throws java.io.IOException {	  
}

public void transferNick() throws IOException {

	getSelectedRoom(item).remove(nick);
	ChatServer.dbChat.add( nick, dbNick.getThread(nick) );
}
public void sendRoomTitles ( ObjectOutputStream oObjStream ) 
	throws IOException {

  oObjStream.writeObject(  getRoomTitleCommand() );
} 
                             
public void sendRoomTitlesToAll () throws IOException {

  simpleBroadcast(dbNick.getChatters(), getRoomTitleCommand() );
}  

private void sendInhibiteRoomCommand()  throws IOException {
	
  simpleBroadcast(dbNick.getChatters(), Globals.RoomExpiredCommand );
}

public void startRooms() {
	
	
//	for (int i=0; i < Globals.ServerRooms; i++) {
//	    if  ( roomTitles[i] != null )
//		   rooms.add( new Room( roomTitles[i], NoExpiration ) );		
//	}

	//roomBst.update(rooms);
}
public int verificaComandi( ChatServer server, 
	                        DBNick dbNick, String nick, String msg, 
	     			        ObjectInputStream iObjStream, 
	     			        ObjectOutputStream oObjStream ) 
	 throws java.io.IOException, InterruptedException, ClassNotFoundException {

	this.serv = server; 
	this.nick = nick;
	this.dbNick = dbNick;
	this.iObjStream = iObjStream;
	this.oObjStream = oObjStream;
	
	if ( msg.indexOf( Globals.RoomLogCommand ) == 0 ) {  
		doLog( msg );
	  }
	
	else if ( msg.indexOf( Globals.SwitchRoomCommand ) == 0 ) {
	  onSwitchRoom( msg );
	  }
	  
	else if ( msg.indexOf( Globals.RoomUpdStatistiche ) == 0 ) {
		onUpdateStatitisticheRoom();
		}
	
	else if ( msg.indexOf( Globals.NewRoomCommand ) == 0 ) {
	  onNewRoom( msg );
	  }
	   
	else if ( (msg.indexOf(Globals.RoomSpeakCommand) == 0) ) {
	
	  msg = msg.substring(7);
	  roomBroadcast(nick, msg);
	  getSelectedRoom(item).registraIntervento(msg, nick);	
	 
	  
	  }
	else if (Globals.RewRoomCommand.equals( msg )) {
		
	   onREWRoomCommand( getSelectedRoom(item).getRegistroInterventi() );
	   
	}	
	else if ( msg.indexOf( Globals.RoomGIFCommand ) == 0 ) {
	
	  msg = msg.substring(7);
	  broadcast (Globals.RoomGIFCommand, 
	           getSelectedRoom(item).getChatters(), msg, nick);
	  getSelectedRoom(item).registraIntervento(msg, nick); //aggiunto 
	  }
	   
	else if ( msg.indexOf( Globals.RoomQuitCommand ) == 0 ) {
	  doQuit();
	  } 
	else if ( msg.indexOf( Globals.CloseWindowCommand ) == 0 ) {
	  return doHaltMe();
	  }   
  return VAI_AVANTI;
}

private void roomBroadcast(String nick, String msg) throws IOException {
	System.out.println(">>>broadcast:item=" + item);
	System.out.println(">>>rooms.size()=" + rooms.size());
	//rooms.size()=8 per 8 stanze
	//item = indice : parte da 0
	// if (item > rooms.size() -1) return;
	
	 broadcast (Globals.RoomSpeakCommand, 
	             getSelectedRoom(item).getChatters(), msg, nick);
}

public String getRoomTitleCommand() throws IOException  {
	
 String command = Globals.RoomTitleCommand;

 for (int i = 0; i < rooms.size(); i++) {
	command += 
	    getSelectedRoom(i).getTitle() 
	  + Globals.FieldSeparator 
	  + String.valueOf( getSelectedRoom(i).getNumUsers() ) 
	  + " users"
	  + Globals.FieldSeparator
	  + String.valueOf( getSelectedRoom(i).TOT_ACCESSI )
	  + " accessi"
	  + Globals.FieldSeparator 
	  + getSelectedRoom(i).getToStringExpirationDate()
	  + Globals.NewRecord;
 }
 return command;
}

public void stopRoom(int index)  throws IOException,InterruptedException  {
	
	roomBroadcast("ChatAnt", "..Per favore uscite tutti !!! La stanza � scaduta e sta per essere distrutta");
	try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	ChatServer.dbChat.add( nick, dbNick.getThread(nick) );
	roomBroadcast("ChatAnt", "..La stanza � stata distrutta");
	sendInhibiteRoomCommand();
	
	System.out.println(">>>indice selzionato="+ index);
	rooms.removeElementAt(index -1);
	sendRoomTitlesToAll(); //RoomTitleCommand aggiorna i cruscotti e i record delle room
}

 public ChatServerRooms(Vector rooms) {
	  this.rooms = rooms;
 }

public int doHaltMe() throws IOException {
	
//il client ha chiuso brutalmente la finestra
  getSelectedRoom(item).remove(nick);
  
  aggiornaListaUtenti( 
	  getSelectedRoom(item).getChatters(), Globals.RoomUpdateListCommand );
  
  mess = Globals.RoomSpeakCommand + " .. rientra in Salone ";
  avvisoPerTutti( getSelectedRoom(item).getChatters(), nick, mess );
  
 return QUIT;
 }           


public void onSwitchRoom(String line) throws IOException {

 // msg = msg.substring(7);

	StringTokenizer st = new StringTokenizer(line.substring(7), 
		   Globals.FieldSeparator);
	
	item = Integer.parseInt( st.nextToken() );
	newItem = Integer.parseInt( st.nextToken() );	
	nick = st.nextToken();
	
	switchNick(item, newItem);

	aggiornaListaUtenti( getSelectedRoom(newItem).getChatters(), 
		Globals.RoomUpdateListCommand );

	aggiornaListaUtenti( getSelectedRoom(item).getChatters(), 
		Globals.RoomUpdateListCommand );	
	
	mess = Globals.RoomSpeakCommand + " .. � entrato ";
   	avvisoPerTutti(getSelectedRoom(newItem).getChatters(), nick, mess);

//	sendRoomTitlesToAll(); //si puo eliminare: RoomTitleCommand aggiorna i cruscotti e i record delle room
//sostituisco con
    //sendRoomTitles();
	item = newItem;
}

public void onUpdateStatitisticheRoom() throws IOException {

//	lancia RoomTitleCommand che aggiorna i cruscotti e i record delle room	
 System.out.println("aggiorno statisciche");
 sendRoomTitlesToAll(); 
	 
}

public void switchNick(int item, int newItem) throws IOException {
    
    //prima sincronizzato
	getSelectedRoom(newItem).addMember(nick, dbNick.getChatters());
   
	mess = Globals.RoomSpeakCommand 
	       + " .. si trasferisce in "
	       + getSelectedRoom(newItem).getTitle();
	avvisoPerTutti( getSelectedRoom(item).getChatters(), nick, mess );	
	getSelectedRoom(item).remove(nick);	
}

public void  onREWRoomCommand(MyVectorInterventi registroInterventi) 
	 throws IOException {
	
	/*  for (Enumeration e = registroInterventi.elements()
		             ; e.hasMoreElements(); )
	  
	  	  oObjStream.writeObject ( Globals.RewRoomCommand 
		  	                      + e.nextElement() 
		  );
		  
      }
    */  
	ant.dyn.MyVectorInterventiRoom regInt = new ant.dyn.MyVectorInterventiRoom();
	for (Enumeration e = registroInterventi.elements(); e.hasMoreElements(); )	  
		regInt.addElement ( Globals.RewRoomCommand + e.nextElement() );   
		
	oObjStream.writeObject ( regInt );
}
      
}