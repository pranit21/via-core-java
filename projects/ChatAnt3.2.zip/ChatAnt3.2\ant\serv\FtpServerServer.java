package ant.serv;
import java.net.*;
import java.io.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class FtpServerServer extends Thread {

	protected BufferedInputStream iStream;
	protected BufferedOutputStream oStream;
	public Thread thread;

	public Socket client;
	public String nomeFile;
	public String nickDonatore;
	public ServerSocket server;


public void run()  {

 try {

// server = (server == null) ? new ServerSocket(9990) : server;	
 
 System.out.println( "...AntFtpServer attivato, in attesa di ricevere il file..." ) ;
 
 client = server.accept ();
 
 System.out.println( "..Collegato al client " );
 System.out.println ("FtpServerServer, donatore : " + client.getInetAddress ());
	
  BufferedInputStream in = new BufferedInputStream( client.getInputStream ());
  DataInputStream iStream = new DataInputStream( in );
  FileOutputStream fout = new FileOutputStream( new File(
		 getDrive() + File.separator + "Repository"
		 + File.separator + "Rep_" + nomeFile ) );
		 
  DataOutputStream oStream = new DataOutputStream(fout);

  int BufferSize = 2048;
  byte buf[] = new byte[ BufferSize ];  
  int n;
  int totBytes=0;

	while ( ( n = iStream.read( buf, 0, BufferSize ) ) != -1 ) {

	  oStream.write( buf, 0, n );
	  totBytes += BufferSize;
	  
	}
	
	fout.close();
	iStream.close();
	oStream.close();
	in.close();

	System.out.println("..Download terminato ! " + totBytes +" ricevuti");

 } catch (java.net.BindException ex) {
	     System.out.println("..Attendere: up/downLoading in corso sul tuo PC");

 } catch (Exception ex) {
	     System.out.println ("FtpServerServer: errore ricezione dati: ");
		 ex.printStackTrace ();
 }

 if (null != client) {
   System.out.println( "..Ftp ServerServer: Chiudo la connessione con "+client.getInetAddress() ) ;
   try {
	  client.close ();
	  }
   catch (IOException e) { 
	  System.out.println( "Ftp ServerServer: errore close socket " + e.getMessage() );
	  e.printStackTrace();
	  }
 }

try {
  if ( server != null )  server.close();
  thread = null;
  interrupt();
  } 
catch (IOException e) {
  System.out.println( "Ftp Server: errore close socket " +e);
  }

}

public void start () {

	if (thread == null) {
		thread = new Thread(this);
		thread.start();
	}

}     	 	 	 	 	 	 	 


public FtpServerServer(String nomeFile) 
   throws IOException {
	   
	  this.nomeFile = nomeFile;
	  server = (server == null) ? new ServerSocket(9990) : server;
   }                     


public FtpServerServer() throws IOException {
	
	server = (server == null) ? new ServerSocket(9990) : server;
 }                     

public void setNomeFile(String nomeFile){
	this.nomeFile = nomeFile;
}

public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}

}