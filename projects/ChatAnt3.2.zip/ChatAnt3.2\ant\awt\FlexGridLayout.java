package ant.awt;

import java.awt.*;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class FlexGridLayout implements LayoutManager {

  private int hgap;
  private int vgap;
  private int rows;
  private int cols;

  private int[] w, h;
  private int ncomp, ncols, nrows;
  private Insets insets;
/**
 * Creates a grid layout with a default of one column per component,
 * in a single row.
 */
public FlexGridLayout() {

  this( 1, 0, 0, 0 );
}
/**
 * Creates a grid layout with the specified number of rows and 
 * columns. All components in the layout are given equal size. 
 * <p>
 * One, but not both, of <code>rows</code> and <code>cols</code> can 
 * be zero, which means that any number of objects can be placed in a 
 * row or in a column. 
 * @param     rows   the rows, with the value zero meaning 
 *                   any number of rows.
 * @param     cols   the columns, with the value zero meaning 
 *                   any number of columns.
 */
public FlexGridLayout( int rows, int cols ) {

  this( rows, cols, 0, 0 );
}
/**
 * Creates a grid layout with the specified number of rows and 
 * columns. All components in the layout are given equal size. 
 * <p>
 * In addition, the horizontal and vertical gaps are set to the 
 * specified values. Horizontal gaps are placed at the left and 
 * right edges, and between each of the columns. Vertical gaps are 
 * placed at the top and bottom edges, and between each of the rows. 
 * <p>
 * One, but not both, of <code>rows</code> and <code>cols</code> can 
 * be zero, which means that any number of objects can be placed in a 
 * row or in a column. 
 * @param     rows   the rows, with the value zero meaning 
 *                   any number of rows.
 * @param     cols   the columns, with the value zero meaning 
 *                   any number of columns.
 * @param     hgap   the horizontal gap. 
 * @param     vgap   the vertical gap. 
 * @exception   IllegalArgumentException  if the of <code>rows</code> 
 *                   or <code>cols</code> is invalid.
 */
public FlexGridLayout( int rows, int cols, int hgap, int vgap ) {

  if ( ( rows == 0 ) && ( cols == 0 ) )
	throw new IllegalArgumentException( "rows and cols cannot both be zero" );

  if ( ( rows < 0 ) || ( cols < 0 ) || ( hgap < 0 ) || ( vgap < 0 ) )
	throw new IllegalArgumentException( "no argument can be negative" );

  this.rows = rows;
  this.cols = cols;
  this.hgap = hgap;
  this.vgap = vgap;
}
/**
 * Adds the specified component with the specified name to the layout.
 * @param name the name of the component.
 * @param comp the component to be added.
 */
public void addLayoutComponent( String name, Component comp ) {

  //System.out.println( name + ":" + comp );
}
private void compute( Container p ) {

  ncomp = p.getComponentCount();
  nrows = rows;
  ncols = cols;
  insets = p.getInsets();

  if ( nrows > 0 )
	ncols = ( ncomp + nrows - 1 ) / nrows;
  else
	nrows = ( ncomp + ncols - 1 ) / ncols;
  if ( ncomp == 0 ) return;

  h = new int[ nrows ];
  w = new int[ ncols ];
  Dimension d;
  for ( int c = 0; c < ncols; c++ ) {
	for ( int r = 0; r < nrows; r++ ) {
	  int i = r * ncols + c;
	  if ( i < ncomp ) {
		d = p.getComponent( i ).getPreferredSize();
		if ( d.width  > w[ c ] ) w[ c ] = d.width;
		if ( d.height > h[ r ] ) h[ r ] = d.height;
	  }
	}
  }
}
/**
 * Gets the number of columns in this layout.
 * @return     the number of columns in this layout.
 */
public int getColumns() {

  return cols;
}
/**
 * Gets the horizontal gap between components.
 * @return       the horizontal gap between components.
 */
public int getHgap() {

  return hgap;
}
/**
 * Gets the number of rows in this layout.
 * @return    the number of rows in this layout.
 * @since     JDK1.1
 */
public int getRows() {

  return rows;
}
/**
 * Gets the vertical gap between components.
 * @return       the vertical gap between components.
 * @since        JDK1.1
 */
public int getVgap() {

  return vgap;
}
/** 
 * Lays out the specified container using this layout. 
 * <p>
 * This method reshapes the components in the specified target 
 * container in order to satisfy the constraints of the 
 * <code>FlexGridLayout</code> object. 
 * <p>
 * The grid layout manager determines the size of individual 
 * components by computing the maximum preferred width of components
 * in the same column and maximum preferred height of components
 * in the same row.
 *  
 * @param      target   the container in which to do the layout.
 * @see        java.awt.Container
 * @see        java.awt.Container#doLayout
 */

public void layoutContainer( Container parent ) {

  synchronized ( parent.getTreeLock() ) {

	compute( parent );
	if ( ncomp == 0 ) return;

	for ( int c = 0, x = insets.left; c < ncols; c++ ) {
	  for ( int r = 0, y = insets.top; r < nrows; r++ ) {
		int i = r * ncols + c;
		if ( i < ncomp )
		  parent.getComponent( i ).setBounds( x, y, w[ c ], h[ r ] );
		y += vgap + h[ r ];
	  }
	  x += hgap + w[ c ];
	}
  }
}
/**
 * Minimum size of the container argument using <code>FlexGridLayout</code>
 * equals his preferred size.
 *  
 * @param       target   the container in which to do the layout.
 * @return      the minimum dimensions needed to lay out the 
 *                      subcomponents of the specified container.
 * @see         java.awt.FlexGridLayout#preferredLayoutSize
 * @see         java.awt.Container#doLayout
 */
public Dimension minimumLayoutSize( Container parent ) {

  return preferredLayoutSize( parent );
}
/** 
 * Determines the preferred size of the container argument using 
 * this flex grid layout. 
 * <p>
 * 
 * @param     target   the container in which to do the layout.
 * @return    the preferred dimensions to lay out the 
 *            subcomponents of the specified container.
 * @see       java.awt.Container#getPreferredSize()
 */
public Dimension preferredLayoutSize( Container parent ) {

  //System.out.println( this + ":" + parent );
  //System.out.println( this + ":" + parent.getTreeLock() );
  synchronized ( parent.getTreeLock() ) {

	compute( parent );

	Dimension d = 
	  new Dimension( insets.left + insets.right + ( ncols - 1 ) * hgap,
					 insets.top + insets.bottom + ( nrows - 1 ) * vgap );
	if ( ncomp == 0 ) return d;

	int i;
	for ( i = 0; i < ncols; i++ ) d.width  += w[ i ];
	for ( i = 0; i < nrows; i++ ) d.height += h[ i ];

	return d;
  }
}
/**
 * Removes the specified component from the layout. 
 * @param comp the component to be removed.
 */
public void removeLayoutComponent( Component comp ) {
}
/**
 * Sets the number of columns in this layout to the specified value.
 * @param        cols   the number of columns in this layout.
 * @exception    IllegalArgumentException  if the value of both 
 *               <code>rows</code> and <code>cols</code> is set to zero
 *               or <code>cols</code> is negative.
 */
public void setColumns( int cols ) {

  if ( cols < 0 )
	throw new IllegalArgumentException( "cols cannot be negative" );

  if ( cols + rows == 0 )
	throw new IllegalArgumentException("rows and cols cannot both be zero");

  this.cols = cols;
}
/**
 * Sets the horizontal gap between components to the specified value.
 * @param        hgap   the horizontal gap between components.
 * @exception    IllegalArgumentException  if or <code>hgap</code> is negative.
 */
public void setHgap( int hgap ) {

  if ( hgap < 0 )
	throw new IllegalArgumentException( "hgap cannot be negative" );

  this.hgap = hgap;
}
/**
 * Sets the number of rows in this layout to the specified value.
 * @param        rows   the number of rows in this layout.
 * @exception    IllegalArgumentException  if the value of both 
 *               <code>rows</code> and <code>cols</code> is set to zero
 *               or <code>cols</code> is negative.
 */
public void setRows( int rows ) {

  if ( rows < 0 )
	throw new IllegalArgumentException( "cols cannot be negative" );

  if ( rows + cols == 0 )
	throw new IllegalArgumentException("rows and cols cannot both be zero");

  this.rows = rows;
}
/**
 * Sets the vertical gap between components to the specified value.
 * @param        vgap  the vertical gap between components.
 * @exception    IllegalArgumentException  if or <code>vgap</code> is negative.
 */
public void setVgap( int vgap ) {

  if ( vgap < 0 )
	throw new IllegalArgumentException( "vgap cannot be negative" );

  this.vgap = vgap;
}
/**
 * Returns the string representation of this flex grid layout's values.
 * @return     a string representation of this flex grid layout.
 */
public String toString() {

  return getClass().getName() + "[hgap=" + hgap + ",vgap=" + vgap +
		 ",rows=" + rows + ",cols=" + cols + "]";
}
}