package ant.awt;

import java.awt.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class PanelMesg extends PanelMesgBase {
public PanelMesg( String msg, int Mode ) {

  super( new BorderLayout() );

  Label lab = new Label( "  " + msg + "  ", Label.CENTER );
  lab.setBackground( tColors[ Mode ][ 0 ] );
  lab.setForeground( tColors[ Mode ][ 1 ] );
  Panel c = new Panel();

  c.add( lab );

  add( BorderLayout.NORTH, new Label( "   ...warning" ) );
  add( BorderLayout.CENTER, c );
  setBackground(Color.lightGray);
}
}