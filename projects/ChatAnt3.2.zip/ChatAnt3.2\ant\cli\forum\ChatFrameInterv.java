package ant.cli.forum;

import java.awt.*;
import java.awt.Color;
import java.awt.event.*;

import ant.glob.Globals;

import java.awt.event.WindowAdapter;

import java.awt.event.WindowEvent;
import ant.cli.ChatFrame;
import ant.cli.util.DiagnSender;

import ant.dyn.ForumInterv;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class ChatFrameInterv extends Frame implements ActionListener {

private ChatPanelForum owner;   // see validate()

  private ChatFrame chatFrame;

  private Button ok;      
  private TextField txAutore;  
  private TextArea txText;  
  private TextField txTitolo;
  private String selectedForum;

public ChatFrameInterv( 
	ChatPanelForum owner, String title, String selectedForum ) {
	
  super(title);
  this.owner = owner;     // see validate()
  this.selectedForum = selectedForum;

  drawFrame();

 setResizable( true );
 toFront();
 centerFrame();
 show();
 //pack();
}
public void actionPerformed( ActionEvent e ) {
	
	sendIntervento();
}
public void centerFrame() {
	
	Dimension Dim = new Dimension(475, 310); //500,350
	int w = Dim.width;
	int h = Dim.height;
	Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
	if ( w >= d.width )  w = d.width - 10;
	if ( h >= d.height ) h = d.height - 10;
	setSize( w, h );
	setLocation( ( d.width - w ) / 2, ( d.height - h ) / 2 );

}
public void drawFrame() {
		
  String lab =  "Autore : ";
  String lab2 = "Titolo : ";
  
  setBackground( Globals.CruscottoColor );  
  setForeground( Color.white );
  
  Panel content = new Panel( new FlowLayout(3) ) // 1 = align 
  {														//2,2 = hgap-vgap
	   public Insets getInsets() { 
	   	return new Insets( 5,5,5,5 ); 
	   } 
  };


 Panel p01 = new Panel( new BorderLayout( 2, 2 ) );
	p01.add( new Label( lab ), BorderLayout.WEST );
	txAutore = new TextField(25);
	txAutore.setFont(new Font("Mia", Font.BOLD, 14));
	txAutore.setForeground( Color.black );
	txAutore.addActionListener(this);
	p01.add( txAutore, BorderLayout.EAST );
	
/* 1 */ content.add( p01  );
 
 Panel p02 = new Panel( new BorderLayout( 2, 2 ) ); 
	p02.add( new Label( lab2 ), BorderLayout.WEST );
	txTitolo = new TextField(45);
	txTitolo.setFont(new Font("Mia", Font.BOLD, 14));
	txTitolo.setForeground( Color.black );
	txTitolo.addActionListener(this);
	p02.add( txTitolo, BorderLayout.EAST );
	
/* 2 */ content.add( p02 );

    txText = new TextArea("", 10, 60, TextArea.SCROLLBARS_VERTICAL_ONLY);
	txText.setForeground(Color.black);   	 

/* 3 */ content.add( txText );
	
 Panel p2 = new Panel(); //(new FlowLayout(FlowLayout.RIGHT));
   ok = new Button( "OK" );
   ok.addMouseListener( new MouseAdapter() { 
	  public void mouseClicked( MouseEvent e ) {
	          sendIntervento();
	       }
	  }
   );
   Button can = new Button( "CANCEL" );
   can.addMouseListener( new MouseAdapter() { 
	  public void mouseClicked( MouseEvent e ) {
	          dispose();
	       }
	  }
   );  
 p2.add( ok );
 p2.add( can );
	  
/* 4 */  content.add( p2 );
	
  add( content );

  addWindowListener ( new WindowAdapter() {
	     public void windowClosing(WindowEvent e) {

	      dispose();
	 }
	} 
   ); 
  
}
public void sendIntervento() {

	ForumInterv frInt = 
	  new ForumInterv(selectedForum,txAutore.getText(),txText.getText(),
	                  txTitolo.getText());
	  
   try {  	  
	   owner.chatFrame.cli.sendObject( frInt );
	   new DiagnSender(owner.chatFrame, "Attenzione", "6").sendDiagn(); 
	   dispose();  
   } catch (Exception ex) {
	   System.err.println ("ChatFrameInerv eccezione su sendIntervento" + ex);
	   ex.printStackTrace();
   }
}
}