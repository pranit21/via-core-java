package ant.cli;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;

import ant.cli.video.MyVideoAudioTransmitter2;
import ant.awt.BeveledPanel;
import ant.awt.FormattedList;
import ant.awt.EnterExitEnlightButton;
import ant.glob.Globals;
import ant.awt.AntGridPanel;
import ant.awt.ClickableGIF;

import ant.awt.TextDisplayField;
import ant.awt.FacesPanel;
import ant.awt.ChatterList;
import ant.awt.CentrDlgBase;
import ant.cli.forum.ChatPanelForum;
import ant.dyn.ForumRec;
import ant.dyn.Target;

//import ant.cli.util.DiagnSender;
import ant.cli.panels.*;
import ant.cli.util.ContaSecondi;
//import ant.awt.SplashScreen;
import ant.cli.util.DataClient;
import ant.cli.vocal.*;
import ant.cli.vocal.panel.*;
import ant.cli.video.MyVideoAudioTransmitter2; 
import ant.awt.LabLog;
import ant.dyn.MyVectorMail;
import ant.dyn.TargetVideoVector;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatFrame extends Frame implements ActionListener {

	private MyVideoAudioTransmitter2 videoTransm;
	private ChatFrameListener cfL;
	private OutputFactory outFact;		
	private boolean CancellaPresenzaInRoom = false;
	//private boolean Inhibite_Brutal_Closing = false;
	private int SelectedRoomIndex;

	public boolean isAPPLET;
	public boolean ButtonsBlocked = false;
	public ChatPanelNbk notebook;
	public CardLayout cardManager;
	private Panel main;
	public ChatRoom room;
	private ScrollPane scrollingOutput;
	private AntGridPanel txOutput;
	protected ChatPanelForum forumPan;
	private Panel panGIF; 
	public Image[] GIFs;
	
	private String GIFSequence = "";
	private FacesPanel pGIFs;
	
	private String nick;
	public ChatCliente cli;
	private String title;
	public TextField txInput = null;
	//public java.awt.List txListTalk;
	public ChatterList txListTalk;
	public FormattedList listRooms;
	int[] cols = {15,12,12,18};
	private DataClient dataCli = new DataClient();
	private boolean GIFSendable = false;

	private static String RunTitle = "ChatAnt v" 
	    +  Globals.VERSION + " - www.chatant.com - vers.TRIAL";

	  
	private String lw;	 	

	private EnterExitEnlightButton botChat, 
	        goToRoom, bot2, botSendMsg, botWake;	
	private Button bot3, botNewRoom, botGuy;

	public Button btnPriv, bot4, botForum;


	private Button bottDownload;
	private Button bot9, botSend, botRefresh;	 	 	
	protected  Button botLogin;				


	public TextDisplayField labNick, 
 	        labNumUtenti, labAccessi, labRoom, labAddress ;
	private ChatFrameShowRooms newRoom; 
	
	public ChatMenuBar cmb; 	
	public LabLog labLog = new LabLog("");	
	private int max_gif_permitted;	
	public String RegistredNickList;

private TitleRunner tlRunner = new TitleRunner();

  private class TitleRunner extends Thread {
	  
	boolean cut = false;

	public void run() {

	  setPriority( getPriority() - 1 );
	  while ( true ) {
	    try {
		  onTitleMove();
		  sleep( 200 );
		}
	    catch ( InterruptedException e ) {
	    }
	  }	    
	}
  };

/**
 * Commento del constructor ChatFrame.
 */
public ChatFrame() {
	super();
}

public void actionPerformed(ActionEvent e) {

  if ((e.getSource().equals(txInput)) && (e.getID()==1001)) {
	  cli.onEnter( (String) txInput.getText() );
  } 
}

public void drawFrame()	{
	
		cfL = new ChatFrameListener(this);
		//setTitle("Chat of the Ant 2.0");
		
		setSize(770, 472); //largh*lungh ((715, 400)
	
		notebook = new ChatPanelNbk();
		notebook.setBounds(22, 43, 580, 380); //18, 43, 580, 380
		add(notebook);
		
		main = new Panel();
		main.setLayout(new BorderLayout());
		main.setBounds(22, 43, 580, 300); //18, 43, 580, 300 
		//add(main); //la ad la fa il notebook

		cmb = new ChatMenuBar(this, isAPPLET);
		 
		String[] title = { "Chat di BigAnt" };
	    txOutput = new AntGridPanel( title, 88 ); //77=lunghezza riga
	    txOutput.setBackground( Globals.OutputColor );
	    txOutput.setFont( new Font("Dialog", Font.PLAIN, 12) );

	    scrollingOutput = new ScrollPane(
		        ScrollPane.SCROLLBARS_AS_NEEDED );
	    scrollingOutput.add( txOutput );
	     
  	    //txListTalk = new java.awt.List(1000, true);
   	    txListTalk = new ChatterList(1000, true);
		txListTalk.setName("parlatori");
		//txListTalk.setBackground( Globals.ParlatoriColor );
        txListTalk.setBackground( Globals.ParlatoriColor2 );
		txListTalk.setFont(new Font("Mm", Font.BOLD, 12));
		txListTalk.setForeground(java.awt.Color.red);

//---- input
	   Panel sot = new Panel();
		sot.setLayout(new BorderLayout () );
		   Panel sotto2 = new Panel( new BorderLayout() );
		   sot.add("South", sotto2);	
		
		txInput = new java.awt.TextField("", 80);
		txInput.addActionListener(this);
		//txInput.setName("input");
		//txInput.setBackground(java.awt.Color.pink);
		txInput.setFont(new Font("Mia", Font.BOLD, 12));
		sot.add("North", txInput);

//----			
		main.add( "Center", scrollingOutput );
		main.add( "East", txListTalk );
		main.add("South", sot);	
		//main.add( "North", txInput );
		
	//=========================      
	//  pannello a sud  -- la larghezza finisce a 590
	//=========================
		
		Panel southPan = new Panel();
		southPan.setLayout(new GridLayout(2,1));
		southPan.setBounds(22, 423, 580, 60);//18, 423, 580, 60
			
		FacesPanel sotto = new FacesPanel();
		sotto.setLayout( new GridLayout(1,6) );
		southPan.add(sotto);

		pGIFs = new FacesPanel("");		
		pGIFs.setBackground(Color.lightGray);
		southPan.add(pGIFs);
		
		//main.add( "South", southPan );
		add(southPan);
//   -----------	
	    notebook.addPage("chatta", main);
		notebook.showPage("chatta");
		
		sotto.setBackground(java.awt.Color.lightGray);
		
	    botSend = new Button("MandaFaccina");
	    botSend.setSize(30,20); 
		botSend.addMouseListener(cfL);
	    sotto.add(botSend);

		labAddress = new TextDisplayField();
		labAddress.setBackground(Globals.CruscottoColor);
		labAddress.setFont(new Font("Mm", Font.PLAIN, 10));	
		labAddress.setForeground(Color.orange);
		labAddress.setText("..not connected");
		sotto.add(labAddress);
	    

  	    labRoom = new TextDisplayField();
		labRoom.setBackground(Globals.CruscottoColor);
		labRoom.setFont(new Font("Mm", Font.PLAIN, 10));	
		labRoom.setForeground(Color.blue);
		labRoom.setText("..Ingresso");
		sotto.add(labRoom);
	    
		labNumUtenti = new TextDisplayField();
		labNumUtenti.setBackground(Globals.CruscottoColor);
		labNumUtenti.setFont(new Font("Mm", Font.BOLD, 10));
		labNumUtenti.setForeground(Color.blue);
		sotto.add(labNumUtenti);
	    
   	    labNick = new TextDisplayField();
		labNick.setBackground(Globals.CruscottoColor);
		labNick.setForeground(Color.orange);
		labNick.setFont(new Font("Mm", Font.BOLD, 12));
		labNick.setText(Globals.NickNonImpostato);
		sotto.add(labNick);
			
		labAccessi = new TextDisplayField();
		labAccessi.setBackground(Globals.CruscottoColor);
		labAccessi.setForeground(Color.blue);
		labAccessi.setFont(new Font("Mm", Font.BOLD, 10));
		labAccessi.setText("Accessi");
		sotto.add(labAccessi);
		
//===========BOTTONI================pannello di DX

		//Container dxPan0 = new Container();  
		Panel dxPan0 = new Panel();  
	    dxPan0.setLayout(new GridLayout(2,1));
	    //con 420 modifico la larghezza dei bottoni
  	    dxPan0.setBounds(600,45,160,420); 	  
  	    //--------------
/*Pan*/ BeveledPanel dxPan = new BeveledPanel();
/*UP*/  dxPan.setLayout(new GridLayout(10,1,1,1));//10,1
	    dxPan0.add(dxPan);
		
	      //botGuy = new Button("Personaggio");
		  //botGuy.addMouseListener(cfL);
		  //dxPan.add(botGuy);

  	      botLogin = new Button("LOGIN");
		  botLogin .addMouseListener(cfL);
		  botLogin .setVisible(true);
		  botLogin .setBackground(Color.orange);
	      botLogin .setEnabled(false);
		  dxPan.add(botLogin );

		  botChat = new EnterExitEnlightButton("CHAT");
		  botChat.addMouseListener(cfL);
		  botChat.setVisible(false);
		  dxPan.add(botChat);
		  
		  btnPriv = new EnterExitEnlightButton("Chat Privata");
		  btnPriv.addMouseListener(cfL);
		  dxPan.add(btnPriv);		  

  		  botWake = new EnterExitEnlightButton("WAKE !");
		  botWake.addMouseListener(cfL);
		  dxPan.add(botWake);

  		  bot2 = new EnterExitEnlightButton("Rewind");
		  bot2.addMouseListener(cfL);
		  dxPan.add(bot2);

		  bottDownload = new Button("ScambiaFiles");
		  bottDownload.addMouseListener(cfL);
		  dxPan.add(bottDownload);

		  //bot4 = new Button("ApriPosta");
		  //bot4.addMouseListener(this);
		  //dxPan.add(bot4);
		
		  botRefresh = new Button("RefreshFiles");
		  botRefresh.addMouseListener(cfL);
		  dxPan.add(botRefresh);		  

		  botSendMsg = new EnterExitEnlightButton("InstantMessage");
		  botSendMsg.addMouseListener(cfL);
		  dxPan.add(botSendMsg);
		  
		  botForum = new Button("FORUM");
		  botForum.addMouseListener(cfL);
		  dxPan.add(botForum);
		  
		  ContaSecondi timer = new ContaSecondi();
		  add(timer);
		  timer.setFont(new Font("xx", Font.BOLD, 12));
		  timer.setForeground(Globals.ViolaScuro);
		  timer.start();
		  dxPan.add(timer);

		//--------------
/*Pan*/	
		Panel dxDow = new Panel();
/*DOWN*/dxDow.setLayout( new BorderLayout() );  
			
		  listRooms = new FormattedList(cols);
		  listRooms.setBackground(java.awt.Color.lightGray);
		  listRooms.setForeground(Globals.ViolaScuro);		
		  dxDow.add( "Center", listRooms );

		  goToRoom = new EnterExitEnlightButton("GoRoom");
		  goToRoom.addMouseListener(cfL);
		    Panel pino = new Panel();
		    pino.setLayout( new BorderLayout(2,2) );
		  
		      pino.add( "West", goToRoom );
		      botNewRoom = new Button("View/AddRoom");
		      botNewRoom.addMouseListener(cfL);
		      pino.add("East", botNewRoom );
		      dxDow.add( "South", pino );	
		      	
		dxPan0.add(dxDow);
		add(dxPan0);
		
	    showGIFs();
}
public boolean isLogged() {

  return labNick.getText().equals(Globals.NickNonImpostato) ? false
		 : true;
}  

public void setButtonsBlocked(boolean swc){
	
	ButtonsBlocked = swc == true ? true : false;    
}


public void onButtonClick(MouseEvent e) throws IOException {
	
 if (ButtonsBlocked) return;
 	
 String lw = "";
 
//-------------------------------------------- 
// ASTERISCARE l'accesso alle ROOMS PER LA VERSIONE TRIAL
//--------------------------------------------

 if  (e.getComponent() == goToRoom) {
	onGoToRoomButton();
 }

// ----- e sostituire con questo diagniostico
/* if  (e.getComponent() == goToRoom) {
	 new DiagnSender(
		this, 
		"Attenzione: Versione Trial, scadenza 30 giorni", "12").sendDiagn();			
 }
*/ 
//--------------------------------------------   
 
 if (e.getComponent() == botNewRoom) { //statisctiche e creazione stanze
	 
    onNewRoomCheckRoomButton(); 	     
 }

 else if  (e.getComponent() == botForum) {
	 botChat.setLabel("TornaInChat");
	 botChat.setVisible(true);
	 onForumClick(); 
 }
 else if  (e.getComponent() == botLogin ) {
	
   onAutentication();

 }
 else if  (e.getComponent() == botSendMsg ) {

	botChat.setLabel("TornaInChat"); 
	onSendMessage();    
 }

 else if  (e.getComponent() == botRefresh ) {

	onRefreshButton();    
 }
 
 else if  (e.getComponent() == botGuy ) {
	  // Scelgo il personaggio
   	 
	  //botGuy.setVisible(false);
	  // ChatFrameChooseGuy chooseGuy = new ChatFrameChooseGuy (
	//	 this, cli.isAPPLET, cli.GuyGIFs, true);
  	  
 }
 else if ( (e.getComponent() == botChat) 
	  && ( botChat.getLabel().equals("TornaInChat") ) ) {
	  // Ritorno alla chat principale
	  onTornaInChatButton();
 }
	    
 else if ( (e.getComponent() == botChat) && 
	    ( botChat.getLabel().equals("CHAT") ) ) {
	// Ritorno dal download alla chat	
	botChat.setVisible(false);
	notebook.showPage( "chatta" );     		
 }	
 else if  (e.getComponent() == botWake) {
	 
	 onWakeButton();
 }
 else if  (e.getComponent() == btnPriv) { //chat privata

   onPrivateChatButton();	  
 }
 else if  (e.getComponent() == bot2) {
	 
   onREWButton();
   
 }
 else if  (e.getComponent() == bot3) {
   lw = "MAIL";  		
   cli.SendString(lw); 
 }
 else if  (e.getComponent() == bottDownload) { //Scambia Files
	// richiedo al server la lista dei file di tutti gli
	// utenti collegati. Il server di rimando mi manda l'oggetto
	// a seguito del quale apro la finestra di vosializzazione dei files
	boolean Repo = false;
	botChat.setLabel("TornaInChat"); 
	onFilesShareButton(false);   	
 }
 //------------------------------------invio testo + faccetta
 
 else if ( (e.getComponent() == botSend) && (GIFSendable) ) {
	 onGIFSend();
   	 GIFSendable = false;
 }
	//else if  (e.getComponent() == bot4) {
	//	apriOutlook();
	//}
}

private void onTornaInChatButton() throws IOException {
	  botChat.setLabel("CHAT");
	  //goToRoom.setEnabled(false);
	  botChat.setVisible(false); 
	  notebook.showPage( "chatta" );
	  txInput.requestFocus();
	
	  if ( CancellaPresenzaInRoom ) { //� quando torno in chat da una room		
		   onQuitRoom();	
		  CancellaPresenzaInRoom = false;
	  }
}

private String[] getSelectedNicks() {
	String[] listaDest = null;	
	if ( isRoomLogged() )
	   listaDest = room.txListTalk.getSelectedItems(); //getSelectedItems();	
	else
	   listaDest = txListTalk.getSelectedItems(); 
	if (listaDest.length == 0) {
		sendDiagn	("Attenzione !", "5");
		return null;
	} else return listaDest; 
	        
}

private void onFilesShareButton(boolean Repo) {

	if (isAPPLET) {
		  sendDiagn	("Operazione non consentita !", "4");
	}
	else {
		Hashtable allFiles = new Hashtable(); 
		if (Repo) allFiles = cli.regFilRepo.getAllFiles();
		else allFiles = cli.regFil.getAllFiles();	
		
		lw = "LIFF";
		botChat.setVisible(true);
		/*Dimension dim = notebook.getSize();
		ChatFinListaFile lifi = new ChatFinListaFile( 
	       cli,  allFiles, labNick.getText(), labLog, dim, Repo );  
		notebook.addPage("files", lifi);
		notebook.showPage("files");
		*/
		
		ChatDummyFrame fr = new ChatDummyFrame();
		Dimension dim = new Dimension(fr.getDimension());
		ChatFinListaFile lifi = new ChatFinListaFile( 
		   cli,  allFiles, labNick.getText(), labLog, dim, Repo ); 
		
		fr.add(lifi);
		fr.setResizable(true);
		fr.show();
		
	}
}
public void onNewRoom( String title ) {
  
  lw = Globals.NewRoomCommand + title;
  try {
	  cli.SendString( lw ); 
  } catch (IOException ex) {
	  ex.printStackTrace();
   	  cli.stop ();
  }	
}
public void onQuit() throws IOException {

	cli.stop ();
}
public void onRoomLog( int item ) {
	
  botChat.setVisible(true);
  nick = labNick.getText();

 int oldRoom=0;
 lw = "";
 //if ( isRoomLogged() ) newRoom = room.getNumRoom();

  // mi registro alla room
  if ( !(isRoomLogged()) )
	 lw += Globals.RoomLogCommand
	    + item
	    + Globals.FieldSeparator 
	    + nick;  
  else {
	 oldRoom = room.getNumRoom();	  	
	 lw += Globals.SwitchRoomCommand
	    + oldRoom
	    + Globals.FieldSeparator
	    + item
	    + Globals.FieldSeparator 
	    + nick;  
  }
	 
  System.out.println(lw); 
  room = new ChatRoom( cli, nick, item, GIFs );
  cli.setRoom( room ); 
  notebook.addPage("room", room);
  try {
	  Thread.sleep(100);
	  notebook.showPage("room");
	  cli.SendString( lw ); 
  } catch (IOException ex) {
	  ex.printStackTrace();
   	  cli.stop ();
  } catch (InterruptedException e) {
	  e.printStackTrace();
  }	
	
}
private void onTitleMove() {
	
  String newTitle = getTitle();
  if ( tlRunner.cut ) {
	newTitle = newTitle.substring( 1 );
	if ( newTitle.length() == 0 )
	  tlRunner.cut = false;
  }
  else {
	if ( newTitle.length() < RunTitle.length() ) {
	  newTitle = newTitle + RunTitle.charAt( 0 ); 
	  RunTitle = RunTitle.substring( 1 ) + RunTitle.charAt( 0 );  // rotation
	}
	else
	  tlRunner.cut = true;
  }
  setTitle( newTitle );
}


public void onFaceClick( Image img, int GIFIndex ) {

	DataClient dt = new DataClient();
	GIFSendable = true;
	if ( max_gif_permitted++ <= 32 ) {
	   GIFSequence += dt.format2Digits(GIFIndex);
	   pGIFs.add( img );
	}
}

public void onGIFReceive(String line) throws IOException {
	 		
//	� arrivata la stringa :
//   nick ==> mess+F0001+gifSequence
	  
   outFact.onGIFReceive( line );

 }   

public void onRepositoryFilesReceive() throws IOException {
	
  boolean Repo = true; 		
  System.out.println("ricevo repository");
  onFilesShareButton(Repo);

 }   

private void onNewRoomCheckRoomButton() throws IOException {

   cli.onUpdStatisticheRoom(); 
   newRoom = new ChatFrameShowRooms (
	   // this, "Crea la tua stanza", true, dataCli);
       this, "Crea la tua stanza", true);
}
private void onGIFSend() throws IOException {

  if ( !(isRoomLogged()) )  {  	
	 cli.SendString( 
		 txInput.getText()
		 + Globals.SendGIFCommand 
		 + GIFSequence );
  }
  else {
	 room.onGIFSend(GIFSequence); 
  }
	 
	 txInput.setText ("");
	 GIFSequence = ""; 
	 max_gif_permitted = 0;
	 pGIFs.reset();
	 
}

public void AddText( String s, boolean shift ) {
		//txOutput.append( s + "\n" ) ;
	
 outFact.AddText( s, labNick.getText() ); 
 txInput.requestFocus();
	  
/*	if (s.indexOf(Globals.MsgSeparator) >= 0) {
	   txOutput.add( labColorSwitcher( s ), Red ); }
	else {     
	   txOutput.add( s, true ); } //true = grigetto
	
	refreshScreen();
	
	if ( shift )
	   scrollingOutput.setScrollPosition( 0, txOutput.getBounds().height );
*/
	
}

public ChatFrame( String title, ChatCliente cli, boolean isAPPLET ) {
		     
	this.title = title;
	this.cli = cli;
	this.isAPPLET = isAPPLET;
	this.GIFs = cli.GIFs;


	Dimension Dim = new Dimension(710, 385);
	int w = Dim.width;
	int h = Dim.height;
	Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
	if ( w >= d.width )  w = d.width - 10;
	if ( h >= d.height ) h = d.height - 10;
	setSize( w, h );
	setLocation( ( d.width - w ) / 2, ( d.height - h ) / 2 );

	drawFrame();
	
	//RunTitle = "Chat of the Ant 2.0 - By Alex BigAnt Formiconi ";
	tlRunner.start();
	
	  txInput.setBackground(Color.lightGray);
	  txInput.setEditable(false);

	//------------------Frame di avvertimento della versione TRIAL
	//if (!(isAPPLET)) new SplashScreen(this).start();
	//if (!(isAPPLET)) new SplashScreenWindow(); //la formica impalla tutto
	//  new DiagnSender(  //lasciare per i test, non ha lo sleep
	// 		this, "Attenzione: Versione Trial, scadenza 30 giorni", "10").sendDiagn();			
	//---------------------------------------------------------------  
	
	enableAllButtons(false);   
	
	show();

	outFact =  new OutputFactory( txOutput, txInput, 
		              scrollingOutput, GIFs, this);
	
	addWindowListener ( new WindowAdapter() 
	  {
	  public void windowClosing(WindowEvent e) {
		//if (!Inhibite_Brutal_Closing) onCloseWindow(); }
		onCloseWindow(); }
	  }  
	);
	
		
}


public boolean isRoomLogged() {

  return room == null ? false : true;
}

public void onQuitRoom () throws IOException {

	 //torno nella chat principale
	 cli.setRoom( null ); 	
	 cli.SendString( Globals.RoomQuitCommand ); 
	 room = null; 	 
	CancellaPresenzaInRoom = false;
}

public void onRoomExpired() {
	
	botChat.setLabel("CHAT");
	botChat.setVisible(false); 
	notebook.showPage( "chatta" ); 
 	CancellaPresenzaInRoom = false;
	room = null; 	 
}

public void showGIFs() {
	
	AntGridPanel tabGIF = new AntGridPanel(1,1); //4,4 = span
	 
	//ClickableGIF gif;
	//int imgWidth;
	//int imgHeight;
	 
	 for (int i = 0; i < Globals.Max_Faces; i++) {	  
		ClickableGIF gif = new ClickableGIF( GIFs[i], i );
   	    
	    gif.setSize(18,18);
	  
	    // imgWidth = GIFs[i].getWidth(this);
	    // imgHeight = GIFs[i].getHeight(this);
		// gif.setSize(imgWidth, imgHeight);
	     
	    gif.addMouseListener(new GIFListener(this) );
 		//System.out.println("Mostro immagine: "+ GIFs[i].toString() + " - n." + i);
		tabGIF.add( gif );
	 }
	 
	 tabGIF.setBounds(1,1,18,350);
	 //tabGIF.setBackground(java.awt.Color.red);
	 add(tabGIF);

	 //show();

//	if ( owner instanceof  ChatFrameChooseGuy ) 
//  	  tabGIF = new AntGridPanel(2,2,2,2); //2,2 ri-co//4,4 = span
//	else

//	if ( owner instanceof  ChatFrameChooseGuy ) 
//  	  tabGIF = new AntGridPanel(2,2,2,2); //2,2 ri-co//4,4 = span
//	else
}

public void updRoomListAndCruscottoRoom( String lista ) {

	//aggiorna il cruscotto del nome room e numero presenti 
	// + aggiorna la grid completa delle rooms "newRoom" ma solo le l'ho attivata
	// tramite il tasto "?/+"
	
	dataCli.setRoomData ( lista );
	dataCli.updateRoomList( listRooms, room ); 

	if (newRoom != null) {	
	   newRoom.updateRows(dataCli);
	   newRoom = null;
	}
	

/*	String app = null;
	int i = 0;
	StringTokenizer st = new StringTokenizer( lista, Globals.NewRecord );
	listRooms.removeAll();
	while (st.hasMoreTokens()) {
	   app = st.nextToken();
	   listRooms.add( app );
	   if (room != null) room.updNumUsers( app, i );
	   i++;
	}
*/ 
}

private void onPrivateChatButton()  throws IOException {

 lw = Globals.LovLoginCommand;
 String[] listaLove = null;
 
 if ( !(isRoomLogged() ) )
   listaLove = txListTalk.getSelectedItems();
 else
   listaLove = room.txListTalk.getSelectedItems();
 
 if ( checkListaLove(listaLove) ) {
 
	for (int x=0; x < listaLove.length; x++) {
  	     lw = lw
  	          + Globals.FieldSeparator //invertito
  	          + listaLove[x];
	}    
	cli.SendString( lw ); 
 } 

}

  public void onChattersRefreshListCommand(String line) {

	StringTokenizer st = 
	  new StringTokenizer(line.substring(5), Globals.FieldSeparator);
	  
	 if ( !(isRoomLogged() ) ) {
		txListTalk.removeAll();
		while (st.hasMoreTokens())
	   	  txListTalk.add(st.nextToken());
	 }
	 else {  		
	    room.txListTalk.removeAll();
		while (st.hasMoreTokens())
	   	  room.txListTalk.add(st.nextToken());	   		
	 }
}



public boolean isPrivateLogged() {

  return cli.lov == null ? false
		 : true;
}

public void onAutentication() {
	
	botLogin.setVisible(false); 	
	ChatFrameRegistration cfr =
	         new ChatFrameRegistration ( this, ".. Scegli il nick", false);
	
}

public void onBackFromMessage() {

  if ( isRoomLogged() ) {
	  notebook.showPage("room");	
  } else {
	  notebook.showPage( "chatta" );     
  }
}

public void onHaltApplication () throws IOException {

	 room = null;  
	 cli.setRoom( null );
	 cli.SendString( Globals.CloseWindowCommand );
	 
}

public void onGoToRoomButton() throws IOException {
		
	if ( listRooms.getSelectedItem() != null ) {
		   CancellaPresenzaInRoom = true;	
		   botChat.setLabel("TornaInChat");
		   SelectedRoomIndex = listRooms.getSelectedIndex(); 
		   onRoomLog( SelectedRoomIndex  );
		   cli.onUpdStatisticheRoom(); 
 		   room.txInput.requestFocus();
	
	}
}

public void onREWButton() throws IOException {
	 
   if ( isRoomLogged() )
	 lw = Globals.RewRoomCommand;
   else
	  lw = Globals.RewMainCommand;
	  
   if (labNick.getText() != Globals.NickNonImpostato)
 	  cli.SendString(lw); 
}

public void onSendMessage() {
 
 String[] listaDest = null;
 
 if ( isRoomLogged() )
	listaDest = room.txListTalk.getSelectedItems();	
 else
	listaDest = txListTalk.getSelectedItems(); 
	
 if (listaDest.length > 0) {
   	 botChat.setVisible(true);
	 ChatPanelSendMessage sndMsg = new ChatPanelSendMessage( this, listaDest );  
	 notebook.addPage("sendMsg", sndMsg);
	 notebook.showPage("sendMsg");
	 sndMsg.txMsg.requestFocus();
 }
 else  sendDiagn	("Attenzione !", "5"); 
}

private void onWakeButton()  throws IOException {

   lw = Globals.WakeCommand;
   String[] listaWake = null;
   
   if ( !(isRoomLogged() ) )
	 listaWake = txListTalk.getSelectedItems();
   else
	 listaWake = room.txListTalk.getSelectedItems();
	
	if (listaWake.length > 0) {
  	   for (int x=0; x < listaWake.length; x++) {
  	     lw = lw 
  	          + listaWake[x] 
  	          + Globals.FieldSeparator;
  	   }    
	   cli.SendString( lw ); 
	 }
	else {
	  sendDiagn	("Attenzione !", "5");
		} 
}

public void sendDiagn(String title, String nDiagn) {

	CentrDlgBase dErr = new CentrDlgBase(
		(Frame) this, title, nDiagn, true);

}

public void enableInput() {

	 txInput.setBackground(Color.white);
	 txInput.setEditable(true);
	 //txInput.requestFocus();
}

public void enableLoginButton() {

	 botLogin.setEnabled(true);
}	

public void enableAllButtons(boolean swc) {
	
    botChat.setEnabled(swc);
	btnPriv.setEnabled(swc);
	botWake.setEnabled(swc);
	bot2.setEnabled(swc); //rewind
	bottDownload.setEnabled(swc);
	botRefresh.setEnabled(swc);
	botSendMsg.setEnabled(swc);
	botForum.setEnabled(swc);
	goToRoom.setEnabled(swc);
	botNewRoom.setEnabled(swc);
	
    //setButtonsBlocked(!swc);
}

public void onForumClick() throws IOException {
	
	 forumPan = new ChatPanelForum( this );  
	 notebook.addPage("Forum", forumPan);
	 notebook.showPage("Forum");
	 
	 cli.SendString( Globals.ForumTitleRequestCommand );	

// else  sendDiagn	("Attenzione !", "5"); 
}

public void onForumTitlesReceive(ForumRec rec) {
	
	forumPan.add( rec );
	
}

public boolean checkListaLove(String[] listaLove) {
 
  boolean diagn = false;	   
  int lovers = listaLove.length;

  if (lovers == 0) {
	sendDiagn	("Attenzione !", "5"); //seleziona un nome
	return false;
  }	
	 
  for (int x=0; x < lovers; x++) {
  	 if ( labNick.getText().equals(listaLove[x]) ) 
  	    diagn = true;
  }    

  if (diagn) {  
	if ( lovers > 1 )
	     sendDiagn("Preoccupati !", "13"); 	//"Selezione errata: hai incluso te stesso nella chat privata"
	else 
	     sendDiagn("Preoccupati !", "14"); 	//"Non puoi chattare in privato con te stesso";

	return false;
  }

 return true; 
}
public void onRefreshButton() {

	cli.onFileListRefresh();	
}



public void disableMailSystemMenu() {
	 
  cmb.disableMailMenu();

}

public void enableAllMenu() {
	 
   //cmb.enableMailMenu();
   cmb.enableAllMenu();
   enableAllButtons(true);
}

public void onCloseWindow()  {

	if (ButtonsBlocked) return;
	
	 try { 
		if (isPrivateLogged()) {
		  sendDiagn	("Attenzione !", "3");
		}
			
		else if ( isRoomLogged() )
		   onHaltApplication();
		else   
		   onQuit();
 		
	 } catch (IOException ex) {
		ex.printStackTrace();
	    }
	 finally { 	dispose();	}  

}

public int onLoginDaRegistrare(String str, String pwd)  {
	
	labNick.setText(str);
	return cli.onLogin (Globals.ChatLoginRegisterCommand, str 
		                + "|" + pwd );	
}

public int onLogin(String str) throws Exception  {
	
	cmb.enableRepoVocalMenu();
	enableAllButtons(true);

	labNick.setText(str);
	labAddress.setText(cli.getLocalAddress());
	return cli.onLogin (Globals.ChatLoginCommand, str);	
}
public int onLoginGiaRegistrato(String str, String pwd)  {
	
	labNick.setText(str);
	return cli.onLogin (Globals.ChatLoginYetRegistredCommand, str
		                + "|" + pwd);	
}

public void onNewMailForYou(MyVectorMail obj) {
  	
   	 botChat.setVisible(true);
	 ChatPanelViewMail viewMail = new ChatPanelViewMail( this, obj, labNick.getText() );
	 Frame fr = new ChatDummyFrame();
	 fr.add(viewMail);
	 fr.setResizable(true);
	 fr.show();
	 	

	 //alternativa valida e funzionante : apre il pannello nel notebook !
	 //-------------------------------------
	 //notebook.addPage("vieMail", viewMail);
	 //notebook.showPage("vieMail");
	 //-------------------------------------
}
public void onPanelMailActivation() {
  	
   	 botChat.setVisible(true);
	 ChatPanelSendMail sndMail = new ChatPanelSendMail( this, RegistredNickList, labNick.getText() );  
	 notebook.addPage("sndMail", sndMail);
	 notebook.showPage("sndMail");
	 sndMail.txTitle.requestFocus();

}

public void onVocalChatActivation() {
	
	String[] listaDest = null;
	
	if ( isRoomLogged() )
	   listaDest = room.txListTalk.getItems(); //getSelectedItems();	
	else
	   listaDest = txListTalk.getItems(); 
	
	//if (listaDest.length > 0) {
		botChat.setVisible(true);
		ChatPanelVocal vocal = new ChatPanelVocal( cli, listaDest );  
		notebook.addPage("vocal", vocal);
		notebook.showPage("vocal");	
	//}
	//else  sendDiagn	("Attenzione !", "5"); 
}

public void onVideoGrabbingActivation() {

	String[] listaDest = getSelectedNicks();
	
	if (listaDest != null) {	
	  try {
		String receiverIP = cli.seekNickIPAddress(listaDest[0]); 		
		InetAddress receiver;
		receiver = InetAddress.getByName(receiverIP);
		
		ant.cli.video.AntVideoFrameGrabbing grab = 
		       new ant.cli.video.AntVideoFrameGrabbing(this, receiver, listaDest[0]); 
		grab.draw();
		
		} catch (UnknownHostException e) {
			e.printStackTrace();
		 
	    } catch (IOException e) {
		    e.printStackTrace();
	    
	    } catch (Exception e) {
		    e.printStackTrace();
            sendDiagn(e.getMessage(), "27" );
	    } 
 
	}    
}

public void onConferenceStartStop(int media) {
	
	int Action = 0;
	if (media==MyVideoAudioTransmitter2.AUDIO) 
		Action = Target.START_AUDIO_CONFERENCE;
	if (media==MyVideoAudioTransmitter2.VIDEO) 
		Action = Target.START_VIDEO_CONFERENCE;
	if (media==MyVideoAudioTransmitter2.BOTH) 
		Action = Target.START_VIDEO_AUDIO_CONFERENCE;
	if (media==MyVideoAudioTransmitter2.STOP_CONFERENCING)
		Action = Target.STOP_CONFERENCING;
	
	Target target = null;
	TargetVideoVector targetMulti = new TargetVideoVector();
	String[] listaDest = getSelectedNicks();
    
	if (listaDest != null && listaDest.length>0) {			
      for (int i=0; i<listaDest.length; i++) {	  	
	     String receiverIP = cli.seekNickIPAddress(listaDest[i]);   
         System.out.println("---- conference con: "+receiverIP);
	     target =  new Target( Globals.ConferencingLocalDataPort, 
	     				receiverIP, 
	     				Globals.ConferencingReceiverPort, 
						getNick(), listaDest[i] );
	  
	     target.setAction(Action);
	     targetMulti.add(target);
      }
	} else {
       return;			
    }  
      //OK per invio singolo
	  //ant.cli.video.MyVideoAudioTransmitter2 video = 
	  //      new ant.cli.video.MyVideoAudioTransmitter2(target); 
      
      //invio a molti utenti
    
	  if (Action == Target.STOP_CONFERENCING) {
	  	videoTransm.stop(); 
	  }
	  else {	  	
        try {
			videoTransm = 
			   new ant.cli.video.MyVideoAudioTransmitter2(targetMulti);
		} catch (Exception e1) {
			//e1.printStackTrace();
			sendDiagn (e1.getMessage(), "27"); //seleziona un nome
			return;			
		} 
	  }
	  
	try {	
		//cli.sendObject(target);
        cli.sendObject(targetMulti);
        
		/*
	String cmd = Globals.StartVideoCommand 
				 + Globals.FieldSeparator 
			     //+ receiverIP
		           + listaDest[0]
				 + Globals.FieldSeparator
			     //+ cli.getLocalAddress();
			     + getNick();
	*/
		
	} catch (IOException e) {
		e.printStackTrace();
	} catch (Exception e) {
		e.printStackTrace();
	}
}


public void onReconnect()  {
	
	 try { 
		if (isPrivateLogged()) {
		  sendDiagn	("Attenzione !", "3");
		}
			
		else if ( isRoomLogged() )
		   onHaltApplication();
//		else   
//		   onQuit();
 		
	 } catch (IOException ex) {
		ex.printStackTrace();
	 }
	 
	 finally { 
		 cli.reconnect(); 
	 }  

}
  	
public void setRegistredNickList( String lista ) {

	this.RegistredNickList = lista;

}

	/**
	 * @return
	 */
	public String getNick() {
		return labNick.getText();
	}

	/**
	 * @return
	 */
public int getSelectedRoomIndex() {
		return SelectedRoomIndex;
	}
public int getMaxRoomNumber() {
	return listRooms.getItemCount();
	}	

}