package ant.cli.panels;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.IOException;

import ant.cli.ChatCliente;
import ant.cli.ftp.FtpServer;
import ant.cli.ftp.FtpClient;
import ant.dyn.FileRecord;
import ant.dyn.RegistroDownload;
import ant.glob.Globals;
import ant.awt.LabLog;
import ant.awt.PanelMesg;
import ant.awt.FormattedListPanel;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatFinListaFile extends Panel {

	int[] cols = {66, 12, 5, 18}; //file(55), lungh, freccetta, owner	
	private FileRecord[] records;
//	private FormattedList files = new FormattedList(cols);
	String[] titoli =  {"File", "Lungh", "-->", "Owner"};
	
	int[] numericFields = {1}; //posizione dei neumerici -1
	private FormattedListPanel files = 
	new FormattedListPanel(
			cols, titoli, numericFields, 
			Color.gray, Globals.VIOLETTO, "FileSharing");
	
	private String nick;
	private Button bot, down, upload;
	private boolean Repo;
	private ChatCliente cli;
	private String nickDonatore;
	private String nickRichiedente;
	private Dimension dim;
	public LabLog labLog;	      
	private Hashtable hashFiles = new Hashtable();
	private Component MesgValues =
		 new PanelMesg( "Nessun file presente in rete", PanelMesg.ModeInfo );			 
    private Vector registroFile = new Vector();
    
public ChatFinListaFile( ChatCliente cli, Hashtable allFiles, String nickRichiedente ) {
	
	this.nickRichiedente = nickRichiedente;
	this.cli = cli;		
	this.hashFiles = allFiles;

	//System.out.println(getClass().getName()+"Hashfile: " +hashFiles.toString());
	drawPanel();	
   }                                                                                                                                                                                       


public ChatFinListaFile(
	ChatCliente cli, Hashtable allFiles, String nickRichiedente, 
	LabLog labLog, Dimension dim, boolean Repo ) {
	
	this.nickRichiedente = nickRichiedente;
	this.cli = cli;		
	this.hashFiles = allFiles;
	this.labLog = labLog;
	this.dim = dim;
	this.Repo = Repo;
	//System.out.println(getClass().getName()+"Hashfile: " +hashFiles.toString());
	drawPanel();	
   }   


public void StartFtpServer(String nomeFile, ChatFinListaFile o) 
	   throws IOException {
	
  new FtpServer(nomeFile, o).start();
}

public void drawPanel() {
	
	setLayout(new BorderLayout ());

	Panel p0 = new Panel( new BorderLayout() );
	add ("South", p0);

	labLog.setText("... Server in attesa di collegamento");
	labLog.setColor(Globals.CruscottoColor);
	p0.add("Center", labLog);
	
	
	Panel panButton = new Panel( new FlowLayout() );
	panButton.setBackground(Globals.CruscottoColor);
	
	  down = new Button("Download");
	  down.setSize(45, 15);		
	  panButton.add(down);
	  
	  upload = new Button("Invia");
	  upload.setSize(45, 15);	
	  if (Repo) {	
	    panButton.add(upload);
	  }  
	p0.add("East", panButton);
	
	down.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		   onDownload();
	   }
	} );
	
	upload.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		   onUploadToRepository();
	   }
	} );

	//files.setSize(dim.width, dim.height);//nel caso sia ll'interno del notebook	
	files.removeAll();
	files.setBackground(Color.lightGray); 
	//files.setSize(dim.width, dim.height -50); //-50 perch� sotto c'� il pannello del bottone
	loadFileList();	
	add ("Center", files);
	
	if (files.getItemCount() == 0) 
	  add("Center", MesgValues);
		
	setVisible(true);	
}

public void getFileRecordFields(String nick, FileRecord[] records) {

	int n = records.length;
	String lung;
	String nome;

	for (int i = 0; i < n; i++) {
		if (!(records[i] == null)) {
			nome = records[i].nomeFile;
			lung = records[i].numBytes;
			//if ( isNotMyFile(nick) ) addFormattedRecord(nome, lung, nick); non devo vedere i miei files
		    showFormattedRecord(nome, lung, nick);

		    records[i].owner = nick;
		    registroFile.addElement( records[i] );
		}
	}
}

public void onDownload()  {

//if  (ev.getComponent() == down) {
  int ch,ch1 = 0;
  String app = "";
  String selected[] = files.getSelectedItems();
  int numSel[] = files.getSelectedIndexes();
	
  if (numSel.length > 0) {
	String fileSelezionato;
	RegistroDownload regdow = new RegistroDownload();
	regdow.setNickRichiedente(nickRichiedente);
	// imposto l'address del richiedente
	try {
	  regdow.setAddressRichiedente( cli.getClienteAddress() ); 
	}
	catch (Exception e) {
	  System.out.println("ChatFinListaFile: getInetAddress di Cliente non riuscito");
	}

	//ciclo che gestir� le richieste di download per >1 files
	//for (int i=0; i < numSel.length; i++) {
 	for (int i=0; i < selected.length; i++) {
 		
 		fileSelezionato = files.getField( numSel[i], 1);
		nickDonatore =    files.getField(numSel[i], 4);
		
		regdow.setNickDonatore(nickDonatore);
		regdow.put( fileSelezionato, nickDonatore );
 	   
 	   //----tre alternative per il comando sopra-------------		
	   /*
	   fileSelezionato = 
		  selected[i].substring( 0, files.getPosition(1) ).trim();     		   	
	   nickDonatore = 
	      selected[i].substring( files.getPosition(3),selected[i].length() ).trim(); 
  		*/	       
	   //------------------
	    
  	   /*
  	   fileSelezionato = 
  	     ( (FileRecord) registroFile.elementAt( numSel[i] ) ).getNomeFile();    
  	  nickDonatore = 
  	     ( (FileRecord) registroFile.elementAt( numSel[i] ) ).getOwner();
	  regdow.setNickDonatore(nickDonatore);
	  */
	  
      //	  ------------------
      
	   }
	
	 try {
	    StartFtpServer (regdow.getNomeFile(), this);
		// mando regdow al donatore tramire server
		cli.sendObject( regdow ); 
	    } catch (Exception ex) {
		  System.out.println ("ChatFinListaFile eccezione " + ex);
	    }
  }
}

public void onUploadToRepository()  {

  String selected[] = files.getSelectedItems();
  int numSel[] = files.getSelectedIndexes();
	
  if (numSel.length > 0) {
	String fileSelezionato = null;

	//ciclo che gestir� le richieste di download per >1 files
	//for (int i=0; i < numSel.length; i++) {
 	for (int i=0; i < selected.length; i++) {
 		
 		fileSelezionato = files.getField( numSel[i], 1);
		System.out.println ("ChatFinListaFile : file selezionato =  " + fileSelezionato);
 	   //----tre alternative per il comando sopra-------------		
	   /*
	   fileSelezionato =  selected[i].substring( 0, files.getPosition(1) ).trim();     		   	
  		*/	       

	   //------------------
	    
  	   /*
  	   fileSelezionato = ( (FileRecord) registroFile.elementAt( numSel[i] ) ).getNomeFile();    
	   */
	  
      //	  ------------------
      
	}
	
    try {
	  cli.sendObject( Globals.RepositoryUpload ); 	
	  System.out.println ("ChatFinListaFile: mando richiesta di upload");
	  labLog.setText("... upload iniziato");
	  new FtpClient ( fileSelezionato, cli.getClienteAddress(), true, labLog ).start();
	  //devo comuniacere la fine del thread qui quando ftpclient � finito!
	  
	} catch (Exception ex) {
	  System.out.println ("ChatFinListaFile:onUploadToRepository: eccezione " + ex);
	}
  }
  
}

         
   
 public boolean isNotMyFile(String nick) {

	return nickRichiedente.equals(nick) ? false : true; 
	
}
public void loadFileList() {
   
	Enumeration k = hashFiles.keys();
	while (k.hasMoreElements ()) {	
	   nick = (String) k.nextElement();
	   records = ( (FileRecord[]) hashFiles.get(nick) );
	   getFileRecordFields( nick, records );	 
	}

	//files.orderAlphabetically();
}
public void showFormattedRecord(String nome, String lung, String nick)
{
	files.add( 
		  nome 
		  + Globals.FieldSeparator 
		+ lung 
		  + Globals.FieldSeparator  
		+ Globals.MsgSeparator
		  + Globals.FieldSeparator  
		+ nick );
	
	//files.orderAlphabetically();
	
}

/*	 if (selected.length > 0) {
		String fileSelezionato;
		RegistroDownload regdow = new RegistroDownload();
		regdow.setNickRichiedente(nickRichiedente);
		// imposto l'address del richiedente
		try {
		  regdow.setAddressRichiedente( cli.getClienteAddress() ); 
		}
		catch (Exception e) {
		  System.out.println("getInetAddress di Cliente non riuscito");
		}
		//ciclo che gestir� le richieste di download per >1 files
		for (int x=0; x < selected.length; x++) {
			
		   fileSelezionato = 
			  selected[x].substring( 0, files.getPosition(1) );     		   	
		   nickDonatore = 
			  selected[x].
				 substring( files.getPosition(3),
							selected[x].length() ); 
  	       
		   regdow.setNickDonatore(nickDonatore);
		   regdow.put( fileSelezionato.trim(), nickDonatore.trim() );
		   }
		
		 try {
			StartFtpServer (regdow.getNomeFile(), this);
			// mando regdow al donatore tramire server
			cli.sendObject( regdow ); 
			} catch (Exception ex) {
			  System.out.println ("ChatFinListaFile eccezione " + ex);
			}
	  }
	 */ 
	
	
	
}