package ant.serv;
import java.net.*;
import java.io.*;
import java.util.*;

import ant.dyn.LoginFiles;
import ant.dyn.FileRecord;
import ant.dyn.RegistroDownload;
import ant.dyn.RegistroFile2;
import ant.dyn.RepositoryFiles;
import ant.dyn.Target;
import ant.glob.Globals;

import ant.dyn.ForumInterv;
import ant.dyn.MyVectorMail;
import ant.dyn.EMail;
import ant.dyn.TargetVideoVector;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class ChatServer extends ChatServerBase {
	
  private Socket chatSocket;
  private FtpServerServer ftpServ;
  protected ChatServerForum servForum;
  public LoginFiles lf;
  

  private Hashtable wakeNick = new Hashtable();
  private String list;
  protected String mess;
  private static final int ERR = -1;                                                   
  public String nickDonatore;    
  
  public  static DBMainChat  dbChat= new DBMainChat();
  private static DBLove  dbLove= new DBLove();
  private static DBNick dbNick = new DBNick();
  private static Hashtable hashFile = new Hashtable ();
  protected ChatServerRooms servRooms;
  private static int TOT_ACCESSI = 0;
  
  private static Vector BusyNicks = new Vector();
   private String listaLove;
   private String nickCreator;
   private static boolean NoExpiration = true;
   private static Vector rooms = new Vector();
   public static String[] roomTitles = { 
	  "Salone", "Cucina",
	  "Bagno", "Sgabuzzino","Garage",
	  "Terrazzo", "Sala-TV",  "CameraDaLetto",  "SalaBiliardo" };

    

  public ChatServer (Socket client) throws IOException {
	//super("ChatServer "+client.getInetAddress() );
	chatSocket = client;

	//startRooms();	
  }                                                                

public void run () {

	if  ( isChatExpired() ) System.exit(0);
    System.out.println("eseguito chatEspired");
	try {
		
	  oObjStream = new ObjectOutputStream (chatSocket.getOutputStream ());
	  iObjStream = new ObjectInputStream (chatSocket.getInputStream ());

	  servRooms = new ChatServerRooms(rooms);
  	  servForum = new ChatServerForum();
  	  startForum();
  	  
  	 
	  if ( onSocket()  < 0 ) {
		  return;
	  }   
	  
	  //--------- CICLO WHILE di controllo sui caratteri digitati-------------------
	    boolean finisci = false;  
	    while (true) {
  
		        //prova istruzione : String aa = iObjStream.readObject().getClass().getName();
			
			
			switch  (verificaInputStream()) {
				case ( STRINGA ):
				    switch (verificaComandi()) {
				        case ( VAI_AVANTI ): 
				            break;
				        case ( QUIT ): 
				            finisci = true;
				            break;
				        case ( OK_INTERVENTO ):
				            broadcast (Globals.NullCommand, dbChat.getChatters(), msg, nick);
				            registraIntervento (msg, nick);
				            break;
				        case ( ERR ): 
				            finisci = true;
				            break ;
				            
				    }
				  break;  
				case ( STRINGA_CORTA ) :
					 broadcast (Globals.NullCommand, dbChat.getChatters(), msg, nick);
					 registraIntervento (msg, nick);
					 break; 
		        case ( ISTANZA ) :
				 
			       break;

		        default :
		            break;
		             
		         }
				if (finisci) break; 			

	     }
					
	} catch (EOFException ex) {
	    System.err.println( ex.getMessage() + "\n");
	    System.err.println("-- non identified nick has disconnected..");	
	} catch (Exception ex) {
	    System.err.println( ex.getMessage() + "\n");	
		System.out.println("bye : non identified nick has disconnected..");
	    //ex.printStackTrace ();
	} finally {
 
	    dbNick.remove(nick);
	    dbChat.remove(nick);
	
		System.out.println( "Chiusa la connessione con " +
		chatSocket.getInetAddress() ) ;
		try {
		   chatSocket.close ();
	     } catch (IOException ex) {
		    ex.printStackTrace();
	     }

	}
  }                                                                                                                                                                                                                                    



 public static void main (String args[]) throws IOException {
	
	//if (args.length != 1)
	//     throw new RuntimeException ("Syntax: ChatServer <port>");
   
   ServerSocket server = null;     
	try { 
	  readServerProperties(); 
	  //server = new ServerSocket(Integer.parseInt(args[0]));//ora il parametro sta in Server.props
	  server = new ServerSocket(Integer.parseInt(Porta));
	}
	catch (java.net.BindException ex) {
	  System.out.println( "ChatAnt Server gia' attivo "  );
	  //throw new RuntimeException( ex.toString() );
	  System.exit(0);	
	}
	
	Socket client ;
	//servRooms.startRooms();
	startServices();
	
	while (true) {
	  System.out.println( "Attesa di ChatClient..." ) ;
	  client = server.accept ();
	  System.out.println ("Nuovo ChatClient da " + client.getInetAddress ());
	  (new ChatServer(client)).start();
	}
  }                                                                                                

private int verificaInputStream() throws Exception {
 
 Object o = new Object();
 o = iObjStream.readObject();

 if (o instanceof LoginFiles) {	 
	return onFileToShareReceive(o);
 }
 else if (o instanceof RegistroDownload) {
	//System.out.println("ChatServer: il client ha richiesto download");
	RegistroDownload regdow = new RegistroDownload(); 
	regdow = (RegistroDownload) o;
	//System.out.println("...il donatore (FtpClient) � : " + regdow.getNickDonatore());
	avvertiDonatore( regdow, dbNick.getChatters(), regdow.getNickDonatore() );
	return ISTANZA;
 }

 else if (o instanceof EMail) {
    onSendMail( o );
	return ISTANZA;
 }  
 else if (o instanceof Target || o instanceof TargetVideoVector) {
 	onVideoCommand( o );
 	return ISTANZA;
 }  
 else if (o instanceof ForumInterv) {
	   
    System.out.println("ChatServer: ricevuto inetrvento forum");	
	 //ForumInterv fmInt = new ForumInterv();
	onForumWrite( (ForumInterv) o);
    return ISTANZA;
 }
    
 else if (o instanceof Byte) {
	 //ricevo byte dal Donatore
	System.out.println("ChatServer: sto ricevendo il DataOutputStream");		
	return ISTANZA;
 }

   
 else  { 
	 msg = (String) o ;
	 if (msg.length() < 4)  
	    return STRINGA_CORTA;
	 else return STRINGA;
 }

}

private int onFileToShareReceive(Object o) {
	addFilesAndAddressesToRegistroFile( o );
	sendFiles2();		      	
	return ISTANZA;
}


																																								  
private int verificaComandi() throws IOException, InterruptedException,
		 ClassNotFoundException, Exception {

    System.out.println(msg);
	// --------- ASTERISCARE NELLA VERSIONE TRIAL !!!----------------			  
	if  (msg.indexOf("ROOM") == 0) {
		return servRooms.verificaComandi(
			       this, dbNick, nick, msg, iObjStream, oObjStream);
	//-----------------------------------------------------------------	
	}
	if  (msg.indexOf("FORU") == 0) {
		return servForum.verificaComandi(
			       this, nick, msg, iObjStream, oObjStream);
	}
	else if (Globals.HelpCommand.equalsIgnoreCase(msg))
	 {
			oObjStream.writeObject( "Sono disponibili solo i seguenti comandi" );
			oObjStream.writeObject( "NICK (quando entri per farti riconoscere), HELP (per l'aiuto), QUIT (per scollegarti)" );
	 } 
	else if ( Globals.QuitCommand.equalsIgnoreCase(msg) )
	  {
		  return doQuit();
	  }
	
	else if (Globals.LovqCommand.equals(msg)) {
		
	  onPrivateChatQuit();
	}
	
	else if (Globals.WakeCommand.equals(msg.substring(0,4)))
	  {
	  sendCommandToUsersList( dbNick.getChatters(), 
		  Globals.ReceiveWakeCommand,  nick );
	  oObjStream.writeObject( "ChatAnt OK, sveglia eseguita !" );
	}
	
	else if (Globals.SendMsgCommand.equals(msg.substring(0,4)))
	  {
	  sendMsgToUsersList(dbNick.getChatters(), 
		                  Globals.ReceiveMsgCommand, 
		                  nick);
	  oObjStream.writeObject( "ChatAnt OK, messaggio spedito !" );
	}
	   
	else if (Globals.LovLoginCommand.equals(msg.substring(0,4)))
	  { 
	 
		onPrivateChatCreation();	
	}
	
	else if (Globals.LovSpeakCommand.equals( msg.substring(0,4)) )
	  {
		  // taglio il codice LOV1 dal messaggio
	   onPrivateSpeakCommand( msg.substring(4) );	  
	
	}
	
	//else if (Globals.StartSingleWayCallCommand.equals( msg.substring(0,4)) )
	else if ( msg.indexOf(Globals.StartSingleWayCallCommand) == 0 ||
	          msg.indexOf(Globals.StartDoubleWayCallCommand) == 0   )
	{
	  		
	  	 onVocalCall(false, msg);
	}
	//  --------- GSM voice commands ------------------
	else if ( msg.indexOf(Globals.StartSingleWayCallCommand+"GSM") == 0 ){
		onVocalCall(true, msg);		
	}
	
    //ricevo Globals.StopCallCommandGSM + selectedNick 
	else if (msg.indexOf(Globals.StopCallCommandGSM) == 0  )
	{  //command+nickRicevente
		sendCommandToOneUser( dbNick.getChatters(), 
			Globals.StopCallCommandGSM, msg.substring(7) );
	}
	//---------------------------------------------------
	
	else if (Globals.StopCallCommand.equals( msg.substring(0,4)) )
	{
	   sendCommandToUsersList( dbNick.getChatters(), 
			 Globals.StopCallCommand, msg.substring(4) );
	}
	  
	else if (Globals.RepositoryCheckCommand.equals( msg.substring(0,4)) )
	  {
		  
	   onRepositoryCheckCommand();	  
	}
	
	else if ( Globals.RepositoryUpload.equals(msg.substring(0,4)) ) {
		
	  startFtpServer(msg.substring(4)); //nomeFile
	}
	    
	else if (Globals.RewMainCommand.equals( msg ))
	  {
		  // l'utente chiede di vedere gli ultimi interventi
		onREWCommand();
	}
	else if (msg.indexOf(Globals.CheckMyMailCommand) == 0)
	  {
		 
		onCheckMail();
	}
	
	else if (msg.indexOf(Globals.DeleteMailCommand) == 0)
	  {
		 
		onDeleteMail(msg.substring(6));
	}
	  
	else if (Globals.RefreshFileListCommand.equals( msg ))
	  {
		  // refresh dei file di \MieiFiles
		Object ob = iObjStream.readObject();  
		onRefreshFileListCommand( ob );
	}
	
	else if (msg.indexOf(Globals.FileForumRequestCommand) == 0)
	  {
		onForumReadRequest( msg.substring(5) );
	}   
	  
	else if (msg.indexOf(Globals.ChatLoginRegisterCommand) == 0)
	  {
		Registred = false;
		 
		if ( onLoginRegisterRequest( msg.substring(7).trim() ) == 0 ) { 
		   doLog();
		}
	}   
	else if (msg.indexOf(Globals.ChatLoginYetRegistredCommand) == 0)
	  {
		Registred = true;  
		if ( onLoginRegisterRequest( msg.substring(7).trim() ) == 0 ) { 
	  	   //nick = msg.substring(7).trim(); 
		   doLog();
		}
	}   
	
	else if (msg.indexOf(Globals.VocalBusyCommand ) == 0) 
    {   //arriva : comando+aChiEDiretto
    	int ii = Globals.VocalBusyCommand.length();
		one2oneBroadcast( msg.substring(ii), Globals.VocalBusyCommand  );
	}   
	else if (msg.indexOf(Globals.ImageGrabbedSendCommand ) == 0) 
	{   //arriva : comando+aChiEDiretto+numerodiBytes
		int ii = Globals.ImageGrabbedSendCommand.length();
		StringTokenizer st = new StringTokenizer(msg, "|");
		String comm = st.nextToken();
		String nik = st.nextToken();
		one2oneBroadcast( nick, msg );
	} 
	/*
	else if (msg.indexOf(Globals.StartVideoCommand) == 0) 
	{   //arriva : comando+aChiEDiretto+dachi�mandato
		int ii = Globals.StartVideoCommand.length();
		StringTokenizer st = new StringTokenizer(msg, "|");
		String comm = st.nextToken();
		String nik = st.nextToken();
		one2oneBroadcast( nik, msg );
	} 
    */

	else if (msg.indexOf(Globals.VocalRefusedCommand ) == 0)
	{
		int ii = Globals.VocalBusyCommand.length();
		one2oneBroadcast( msg.substring(ii), Globals.VocalRefusedCommand );
	}   
	
	else if  (msg.indexOf(Globals.ChatLoginCommand) == 0 ) // || msg.indexOf("nick ") == 0)
			// il nome del chattatore insieme a this (il thread)
	{
		nick = msg.substring(4).trim(); 
		doLog(); 
	}
	else {
	  	  return OK_INTERVENTO;
		 
	}
	
	return VAI_AVANTI;
	
	}            									  
 

public InetAddress getInetAddress() {
	return chatSocket.getInetAddress();
	}      	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	    	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	                

		  
public ChatServer getChatServer (Hashtable hash, String doner ) {

ChatServer c = null;	
if ( hash.containsKey ( doner ) ) {
   c = (ChatServer) hash.get( doner ); 
}   
 return c;  
}
		  

		  

public void addNick() {

	dbChat.add(nick, this);  	      
	dbNick.add(nick, this);

	//roomBst.update( dbNick );  //per il controllo del ping
}

public void avvertiDonatore ( RegistroDownload regdow, Hashtable hash, String nickDonatore ) {

this.nickDonatore = nickDonatore;
  try {
	  getChatServer(hash, nickDonatore)
	     .oObjStream.writeObject ( regdow );
  } catch (IOException ex) {
	System.out.println("Errore su getServer"+ ex );
	ex.printStackTrace(); 
  }	
}

public void avvisoPerTutti (Hashtable hash, String nick, String mess) { 

	Enumeration e = hash.elements();
	while (e.hasMoreElements ()) {
	  ChatServer c = null; 
		   c = (ChatServer) e.nextElement ();	  
		try {
			
			// qui spedisco il messaggio al client, lo modifico aggiungendo il nick
			c.oObjStream.writeObject (mess + " " + nick);
			sendNumUtentiCollegati ( c );
			
			} catch (IOException ex) {
		      c.interrupt();
		    }
	 }
 }                                                    

									  

public void cancelNick() {
	
	dbNick.remove( nick );
	dbChat.remove( nick );
}

public synchronized void doLog() throws IOException {
	

 RegistredNickServices rns = new RegistredNickServices();
 rns.loadPropertyFile();
  
  if (!Registred) {
	 if ( rns.seekRegistredNick(nick, "") == 0 ) { //nick gi� presente tra i registrati
	    oObjStream.writeObject( Globals.YetRegistredNick  );
	    return;
	 }
  }
  if ( !(dbNick.isDuplicate( nick )) ) {
	  addNick();
	  oObjStream.writeObject( "Ciao "+ nick +" ...ricordati che sei in un gruppo " ) ;
	  oObjStream.writeObject( "...e quindi comportati con correttezza. " ) ;
	  oObjStream.writeObject( "---------------------" );
		  //mando la stringa A0000 con tutti i nick;
		  //A0000 significa : aggiorna la lista dei nick presenti
		  // aggiorno la tabella dei collegati
		  
	  aggiornaListaUtenti( dbChat.getChatters(), Globals.UPD_MAIN_LIST );
	  if ( Registred ) 
	     oObjStream.writeObject(
			 Globals.RegistredNickListCommand + rns.getRegistredNickList());
	 
	  mess = "..WOW ! � entrato --> ";
	  avvisoPerTutti(dbChat.getChatters(), nick, mess); } 
  else { 
	  oObjStream.writeObject( Globals.DuplicateNick  ) ;
	}
}



public synchronized int doQuit() {
	  
  cancelNick();
  
  System.out.println("-------- cancello nick");
 
  //rimuove dal registro i file dell'utente che esce ed aggiorna i registri
  // di tutti gli altri componenti rimasti
  
  //synchronized (hashFile) {
       hashFile.remove(this); 
       System.out.println("-------- cancello rimuovo i file del nick");
 // }
  
  System.out.println("ChatServer: rimuovo il nick da hashFile");
  
  sendFiles2();		      	
  
  aggiornaListaUtenti( dbNick.getChatters(), Globals.UPD_MAIN_LIST );
  mess = "...Arrivederci da ";
  avvisoPerTutti(dbNick.getChatters(), nick, mess);  
  try {
	  Thread.sleep (1000);
	  }
  finally { 
	  return QUIT; 
  }
}

                                                            

public void preLoginMessage () throws IOException {

	 oObjStream.writeObject( ".. Sei felicemente collegato con ChatAnt !" ) ;
	 oObjStream.writeObject( ".. per partecipare clikka su LOGIN. Grazie." ) ;
	 
	 sendNumUtentiCollegati();
	
  }                                                        

public synchronized void registraIntervento ( String message, String nick) {
	
	registroInterventi.addElement(nick + Globals.MsgSeparator + message);
}      

/*
public synchronized void sendFiles2() {
	
Enumeration k = hashFile.keys();
	while (k.hasMoreElements ()) {
	    ChatServer thr = (ChatServer) k.nextElement();	 
	    try {
		     
		    thr.oObjStream.writeObject ( Globals.UdpFileListCommand );
		
		Enumeration e = hashFile.elements();
		while (e.hasMoreElements ()) {	 
		     thr.oObjStream.writeObject ( 
			     (RegistroFile2) e.nextElement() ); 
			     System.out.println("ChatServer: sendFiles2: mando file a un nick");
		     }

	   	 } catch (IOException ex) {
	       ex.printStackTrace(); 
	     } 
	}
}		
*/

public synchronized void sendFiles2() {
	
	Enumeration k = hashFile.keys();
	//Enumeration e = hashFile.elements();
	System.out.println("----------ChatServer: sendFiles----------");
	while (k.hasMoreElements ()) {
		ChatServer thr = (ChatServer) k.nextElement();	 
		try {
			
			thr.oObjStream.writeObject ( Globals.UdpFileListCommand );
			
			Enumeration e = hashFile.elements();
			while (e.hasMoreElements ()) {	 
				thr.oObjStream.writeObject ( 
						(RegistroFile2) e.nextElement() ); 
				System.out.println("/tChatServer: sendFiles2: mando file a un nick");
			}

		} catch (IOException ex) {
			ex.printStackTrace(); 
		} 
	}
}		


public void sendNumUtentiCollegati () throws IOException {
	
 oObjStream.writeObject( 
	 Globals.NumUserCommand +
	 Globals.FieldSeparator
	 + String.valueOf( dbNick.getNumUsers() ) 
	 + Globals.FieldSeparator 
 	 + String.valueOf( TOT_ACCESSI ) 
	 ) ;
		
}                                

public void sendNumUtentiCollegati (ChatServer c ) throws IOException {

 c.oObjStream.writeObject( 
	 Globals.NumUserCommand +
	 Globals.FieldSeparator
	 + String.valueOf( dbNick.getNumUsers() ) 
	 + Globals.FieldSeparator 
 	 + String.valueOf( TOT_ACCESSI ) 
	 ) ;
		
}                                

 
public void  broadcastLove ( String list, String mittente, String mess ) 
	   throws IOException {
	
	String nic;
	StringTokenizer st = new StringTokenizer(list, Globals.FieldSeparator);
	
	while (st.hasMoreTokens()) {

	    nic = (String) st.nextToken();
	    ChatServer c = dbNick.getThread( nic ); 
	    
		try {
  		    c.oObjStream.writeObject (
	             Globals.LovSpeakCommand
	             + mittente
	             + Globals.MsgSeparator
	             + mess );
  		    
			} catch (IOException ex) {
		         c.interrupt();
		    }
	 }
}

public void  one2oneBroadcast ( String nick, String command ) 
	   throws IOException {
		
	ChatServer c = dbNick.getThread( nick ); 
	    
		try {
			c.oObjStream.writeObject ( command );    
		} catch (IOException ex) {
			 c.interrupt();
		}
}




public void  onPrivateSpeakCommand(String line) throws IOException {

 // line � cos� composta: 
 // (LoveSpeakCommand: gi� tagliato)  "|" + nickCreator + "|" + mittente + "|" +  messaggio
 
  //int ch = line.indexOf("|");
  //String nickCreator = line.substring( 0, ch );

  
  StringTokenizer st = new StringTokenizer(line, Globals.FieldSeparator);	

  nickCreator        = st.nextToken();
  String mittente    = st.nextToken();
  String mess        = st.nextToken();
   
  listaLove  = dbLove.getChatters( nickCreator );  //listalove = nickA|nickB|nickC

  if (listaLove != null) 
	 broadcastLove ( listaLove, mittente, mess );

}

public void  onREWCommand() throws IOException {
	
// for (Enumeration e = registroInterventi.elements(); e.hasMoreElements(); )	  
//	  oObjStream.writeObject ( e.nextElement() );
   ant.dyn.MyVectorInterventi regInt = new ant.dyn.MyVectorInterventi();
   for (Enumeration e = registroInterventi.elements(); e.hasMoreElements(); )	  
	   regInt.addElement ( e.nextElement() );   
   oObjStream.writeObject ( regInt );
}

public synchronized void resetPrivateList(String nick) throws IOException {

// dbLove.remove(nick);
// listaLove = null;
// nickCreator = null;

/* int i = 0;
 String app;
 for (Enumeration e = BusyNicks.elements(); e.hasMoreElements(); ) {

	app =  (String)e.nextElement();
	if  ( app.equals(nick) )
	  BusyNicks.removeElementAt(i);
	i++;    
 }
*/	
}

public void sendMsgToUsersList (Hashtable hash, String command, String nick) {

 	String nic= "";
	ChatServer c = null;
	
	StringTokenizer st = 
	    new StringTokenizer(msg.substring(4), Globals.FieldSeparator);
	
	String message = st.nextToken();
	
	while (st.hasMoreTokens()) {
		nic = st.nextToken();
		if (hash.containsKey(nic)) {
		   c = (ChatServer) hash.get(nic);
  			try {  // (nick � il mittente del messaggio)
  			  c.oObjStream.writeObject ( 
	  			    command
	  			  + message   
	  			  + Globals.FieldSeparator
	  			  + nick );
  			  
  			} catch (IOException ex) {
	  		    System.out.println (getClass().getName()+ "Errore al comando wake !");	
  		   	    c.interrupt();
  		    }
		}
	}	
 }                    

private static void startRooms() {
	
	//rooms = new Room[Globals.ServerRooms];
	for (int i=0; i < Globals.ServerRooms; i++) {
	    if  ( roomTitles[i] != null )
		   rooms.add( new Room( roomTitles[i], NoExpiration ) );		
	}
}

private void startFtpServer(String nomeFile) {
	
   try {	
	   ftpServ = new FtpServerServer(nomeFile);
	   ftpServ.start();
	   System.out.println ("-- FtpServerServer().start(): in attesa di ricevere il file : " + nomeFile);  
	
   } catch (IOException ex) {
		  System.out.println ("FtpServerServer().start(): ftp non parte! ");
		  ex.printStackTrace ();
   }	  
}
  //protected ChatServerForum servForum = new ChatServerForum();

private static void startForum() {

  ChatServerForum servForum = new ChatServerForum();
  servForum.startForum();
  //servForum.startForum();
}

private static void startServices() {
	
	startRooms();
	//startForum();
	roomBst.start();
}

private void addFilesAndAddressesToRegistroFile(Object o ) {

	//System.out.println("ChatServer: Arriva la dir di un nuovo nick");
	lf = (LoginFiles) o;
	FileRecord[] records;
	records = lf.getRecordFiles();
	String addressToString=null;
	
//		String me = chatSocket.getInetAddress().getHostName();
//	    System.out.println("ChatServer: parlo con me stesso !!!! " +me);
//		InetAddress mioAdd = chatSocket.getInetAddress().getByName(me);
//		addressToString = mioAdd.getHostAddress();
    
    if ( !chatSocket.getInetAddress().getHostAddress().startsWith("127") ) {
	   //qui, se stai in rete non dovrebbe mai passare, perch� l'istruzione
	   // non ritorna mai un 127.... verifica
	   addressToString = chatSocket.getInetAddress().getHostAddress();
	}
	else {
	   //il server � anche un chattatore: ServerIPAddr non lo riesco ad ottenere
	   //mi da sempre 127.0.0.1 cos� ho risolto mettendolo nel file server.props
	   // (variabile ServerIPAddr)	
	   //addressToString = ServerIPAddr;
	   //_---- poi sostituito con le due seguenti istruzioni 
	   // da verificare !!!
	   try {	   	         
	   	  String nome = InetAddress.getLocalHost().getHostName();
	   	  addressToString = InetAddress.getByName(nome).getHostAddress();
	   } catch (UnknownHostException e) {
          	e.printStackTrace();
       } 
	}
    
	          //prima : new RegistroFile2(lf.getNick(), records, chatSocket.getLocalAddress().getHostAddress()) );
			  //spiego: chatSocket.getLocalAddress() mi da l'indirizzo del server su cui gira ChatServer
			  //corretto: sostituire con  chatSocket.getInetAddress()  
  	   hashFile.put( //put inserisce se non c'� aggionna se c'� 
  	      this, 
          new RegistroFile2( lf.getNick(), 
                             records, 
		                     addressToString ) ); 
         //	getHostAddress() = 999.999.999 = IPAddress                    

	
   System.out.println("ChatServer: addFilesAndAddressesToRegistroFile: Local address del nick collegatosi = "+chatSocket.getLocalAddress().getHostAddress());
}

private void writeFileToRepository(String nomeFile) {

	BufferedInputStream in = new BufferedInputStream( iObjStream );
	DataInputStream iStream = new DataInputStream( in );
	
	try {
	
	FileOutputStream fout = new FileOutputStream( new File(
		   Drive  + File.separator  + Globals.DirRepository  + File.separator + nomeFile ) );
	DataOutputStream oStream = new DataOutputStream(fout);

	int BufferSize = 2048;
	//int buflen = fout.length() > 1000000L ? 10240 : 2048;
	byte buf[] = new byte[ BufferSize ];  
	int n;
	int totBytes=0;

	  while ( ( n = iStream.read( buf, 0, BufferSize ) ) != -1 ) {
		oStream.write( buf, 0, n );
		totBytes += BufferSize;
	  }
	  fout.close();
	  iStream.close();
	  oStream.close();
	  in.close();

	  System.out.println("..Download terminato ! " + totBytes +" ricevuti");

   } catch (Exception ex) {
		   System.out.println ("writeFileToRepository: errore ricezione dati: ");
		   ex.printStackTrace ();
   }
}

public boolean isBusyNick (String nick) {

	String app;
	int i=0;
	for (Enumeration e = BusyNicks.elements(); e.hasMoreElements(); ) {
		app =  (String)e.nextElement();
		if ( ( app.equals(nick) ) ) return true;
		i++;    
	} 
	return false;
}
public boolean isChatExpired () {

	  //return roomBst.EXPIRED ? true : false;
      return RoomBuster.EXPIRED ? true : false;
}

public void maxUsersMessage () throws IOException {

/*	 oObjStream.writeObject( ".. Non puoi collegarti con ChatAnt!" ) ;
	 oObjStream.writeObject( ".. raggiunto il massimo numero di utenti per la versione trial" ) ;
 	 oObjStream.writeObject( ".. Collegati a www.chatant.com ed acquista ChatAnt");
	 oObjStream.writeObject(".. Usufruirai di tutti i servizi di assistenza ed aiuterai la crescita della comunicazione on line.");
	 oObjStream.writeObject("Grazie!");
	 try { sleep(6000); }
	 catch (InterruptedException e) {}
*/	 
 } 
 
  public synchronized void onForumWrite(ForumInterv frmInt) throws IOException {
	
      //servForum.writeInterv( frmInt );
      servForum.writeIntervAsFirst( frmInt );
}
  
 public synchronized void onPrivateChatCreation() throws IOException {	  

// nick � il singolo utente, qui ci passa solo in creazione, quindi nick=creatore 
// della chat privata
	
/* una conversazione privata � come una lista a se generata da una capo lista
   la lista sta in un hashtable ed il capo lista (nickCreator) � la sua key
   Se mettessi tutti i nick di tutte le conversazioni private in corso in unico
   vettore confonderei tra di loro tutte le conversazioni private,
   se A vuole parlare con B e C e 
	  D vuole parlare con E e F, allora se metto tutti insieme A parler� anche
   con E ed F che neppure conosce
   --- per ora funziona cos�, quando esce il capolista (key) muoiono tutti gli altri,
   ma si potr� modificare facendo s� che gli altri continuino a parlare ancora,
   basta non cancellare il capolista (key) dalla hash ma segnalare di non mandagli 
   pi� nessun messaggio.
   --- se esce un nick non capolista invece viene semplicemente rimosso dagli
   elementi di dblove con chiave = nick capolista
*/

String nic = null;
String listOK = "";
// ---------------- CREO La LISTA LOVE SUL REGISTRO LOVE
// (se creatore � tre che vuole parlare con due e con uno) msg = LOVV|due|uno

oObjStream.writeObject( "ChatAnt--> chat privata creata. Ora ne sei l'amministratore" ) ;
nickCreator = nick; 
list = nickCreator + msg.substring( 4 ); //list = tre(creatore)|due|uno (due e uno sono gli altri)

StringTokenizer st = new StringTokenizer(list, Globals.FieldSeparator);	
//verifico che non ci siano nick impegnati in chat privata
while (st.hasMoreTokens()) {

	nic = (String) st.nextToken();
	if  ( isBusyNick(nic) ) {
	    oObjStream.writeObject( 
	       "ChatAnt--> " + nic 
	       + " � gi� impegnato in una chat privata, contattalo pi� tardi!");
		//cancellare il nick busy da list !!!!
		continue;
	}	
	listOK += nic + Globals.FieldSeparator;
}

//devo inserire l'asterisco sul nick impegnato in conversazione privata della lista del client
//aggiornaListaUtenti( dbNick.getChatters(), Globals.UPD_MAIN_LIST );

StringTokenizer st2 = new StringTokenizer(listOK, Globals.FieldSeparator);
if ( st2.countTokens()  < 2 )  return;

dbLove.addPrivateList( nickCreator, listOK );
listaLove =  dbLove.getChatters(nick);

 nic = null;	
 while (st2.hasMoreTokens()) {
	nic = (String) st2.nextToken();
	BusyNicks.addElement(nic); //vettore dei nick impegnati in convers. privata    
	ChatServer c = dbNick.getThread( nic ); 
	try {
  		c.oObjStream.writeObject (Globals.PrivateChatRequestCommand + list); //A00PC  
  		if (!( nic.equals(nickCreator) )) {
  		    c.oObjStream.writeObject (Globals.LovSpeakCommand  //LOV1
  		    + "ChatAnt--> Sei stato richiesto da " 
  		    + nickCreator + " per una conversazione privata!");
	     }

		 } catch (IOException ex) {
			 System.out.println("Errore su onPrivateListCreation()"+ ex );
			 ex.printStackTrace(); 
	         c.interrupt();
	     }
 }
}public synchronized void onPrivateChatQuit() throws IOException {

  // passa qui quando un qualsiasi nick esce dalla chat privata
  
  oObjStream.writeObject( "Bentornato sulla Chat pubblica "+nick+ " !" );

  // attualmente listalove (A|B|C) non viene aggiornata all'uscita del nick
  if (listaLove != null) {	
 	  removeBusyNick(nick);
	  mess = nick + " ti saluta e torna nella chat principale.";
	  broadcastLove ( listaLove, "ChatAnt", mess );
	  //aggiornaListaUtenti(dbLove.getChatters(), Globals.UPD_LOVE_LIST );

	  // se esce il creatore della lista devo cancellare tutti
	  // i nick (anche quelli di busyNick) perch� la conversazione termina con lui 
	  String nic;	  
	  if ( nickCreator.equals(nick) ) {
		 //cancello il creatore della lista privata
		 mess = ".." + nick + " � l'amministratore di questa chat privata." 
				+ " Il collegamento verr� terminato.\nPer favore chiudi questa finestra!";			
		 broadcastLove ( listaLove, "... ", mess );
		 StringTokenizer st = new StringTokenizer(listaLove, Globals.FieldSeparator);	
		 while (st.hasMoreTokens()) {
	        nic = (String) st.nextToken();
	        removeBusyNick(nic);
	     }	
		 listaLove = null;	
		 nickCreator = null;	    
		 dbLove.remove(nick); //nick = amministratore della lista 
	 }
  }   	
}
public void  onRefreshFileListCommand(Object ob) throws Exception {

  addFilesAndAddressesToRegistroFile( ob );
  sendFiles2();
}

private void  onVideoCommand(Object ob) throws Exception {
	
	VideoCommandChecker check = new VideoCommandChecker(dbNick);
	check.verificaComandi(ob);
	
}


public void  onVocalCall(boolean isGsm, String line) {

	// line � cos� composta: 
	// vocal SINGOLA
	// Command + "|" + interlocutore
	 
	// vocal DOUBLE
	// Command + "|" + interlocutore + "|" + richiedente
    
	//String command=null;
	
	Hashtable hash = dbNick.getChatters();
	StringTokenizer st = 
	new StringTokenizer(
			line, Globals.FieldSeparator);	
	
	st.nextToken();
	String interlocutore = st.nextToken();
	String richiedente = "";
//	if (command.equals(Globals.StartDoubleWayCallCommand)){
//		richiedente = st.nextToken();
//	}	
	richiedente = st.nextToken();
	
	System.out.println("---   vocal call: ricevo: "+line);
	System.out.println("---   vocal call: mando: "+msg);
	System.out.println("---   vocal call: mando comando a: "+ interlocutore + ", da parte di :"+richiedente);
	ChatServer c = null;

	if (hash.containsKey(interlocutore)) {
	   c = (ChatServer) hash.get(interlocutore);
	 
		try {
		  //c.oObjStream.writeObject (command + Globals.FieldSeparator + richiedente);
		  c.oObjStream.writeObject (msg);

		} catch (IOException ex) {
		  System.out.println (getClass().getName()+ "Errore al comando wake !");	
		  c.interrupt();
		}  	   	 
	}
}



public int onSocket () throws IOException {
	  
	TOT_ACCESSI += 1;
	int ret;
	 
	if ( roomBst.MaxUsersReached( dbNick ) ) {
	   //maxUsersMessage();
	   ret = -1;
	   //asteriscare questa system nella versione TRIAL   
	   System.out.println( "Massimo numero di utenti raggiunto! Chiusa la connessione con " + chatSocket.getInetAddress() ) ;
	   try {
		 chatSocket.close ();
	   } catch (IOException ex) {
		    ex.printStackTrace(); }
	}   
	else {
	   ret = 0;	 
	   preLoginMessage();
	   servRooms.sendRoomTitles(oObjStream);
	}
	return ret;
  }                                            
  
  public void removeBusyNick (String nick) {
 
   int i = 0;
   String appNick;
  		
 	for (Enumeration e = BusyNicks.elements(); e.hasMoreElements(); ) {
		appNick =  (String)e.nextElement();
		if  ( appNick.equals(nick) ) BusyNicks.removeElementAt(i);
		i++;    
	} 
}

public void onCheckMail() throws IOException {
	
  RegistredNickServices rns = new RegistredNickServices();
  MyVectorMail myVect = rns.checkMail( nick ); //ritorna una vettore
  if ( myVect != null) {
	 oObjStream.writeObject( Globals.MailForYou ); // Posta per te!
	 oObjStream.writeObject( myVect );
  }
  else
	  oObjStream.writeObject( Globals.NoMailForYou ); // Nessun messaggio
}

public void onDeleteMail(String str) throws IOException {

 int num = Integer.parseInt(str);	
 RegistredNickServices rns = new RegistredNickServices();
 //rns.loadPropertyFile();
 rns.deleteMail(nick, num);
 
}

public void onForumReadRequest (String forumName) throws IOException {
	
 ChatServerForum csf = new 	ChatServerForum();
 oObjStream.writeObject(csf.loadForum(forumName));
}

public void onRepositoryCheckCommand () throws IOException {
	System.out.println("ricevo richiesta repository");

	oObjStream.writeObject( new RepositoryFiles("Repository_manager" ) ); //owner
 
}
public synchronized int onLoginRegisterRequest(String str) 
	throws IOException {
	
  RegistredNickServices rns = new RegistredNickServices();
  rns.loadPropertyFile();

   //String app = msg.substring(7).trim();
   nick = str.substring(0, str.indexOf("|"));
   pwd = str.substring(str.indexOf("|")+1);

  int code = rns.seekRegistredNick(nick, pwd); 
   
  if ( code < 0 ) {  //non trovato tra i registrati
	  
	if (!Registred ) { 
	  rns.addNewRegistredNick(nick, pwd);
 	  oObjStream.writeObject( Globals.NewRegistredNick ); //grazie per esserti registrato
 	  Registred = true;
	}
	else {
	  oObjStream.writeObject( Globals.NotRegistredNick ); //non sei registrato
	  Registred = false;
	  return -1;
	} 
  }	
   
  else { //trovato tra i registrati
	 
	if (!Registred ) { 	   
	   oObjStream.writeObject( Globals.YetRegistredNick  );//Registrazione rifiutata, nick gi� presente
	   return -1;
	}
	//else inserisci qui il controllo della pwd
	else
	   if (code == 3) {//pwd errata
	      oObjStream.writeObject( Globals.PasswErrata );
	      return 3;
	   }   
  }	 

  return 0;
		
}

public void onSendMail(Object mail) throws IOException {
	
  RegistredNickServices rns = new RegistredNickServices();
  rns.storeEMail(mail);
  
  oObjStream.writeObject("..Messaggio correttamente inviato!");	  	 
  		
}

}