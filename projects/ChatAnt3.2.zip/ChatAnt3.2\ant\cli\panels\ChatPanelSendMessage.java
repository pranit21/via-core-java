package ant.cli.panels;
import java.awt.*;
import java.awt.event.*;


import java.io.IOException;

import ant.glob.Globals;

import ant.awt.TextDisplayField;
import ant.awt.EnterExitEnlightButton;

import ant.awt.LabLog;
import ant.cli.ChatCliente;
import ant.cli.ChatFrame;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatPanelSendMessage extends Panel  {
	
  private String nick;
  public LabLog labLog;	      
  private ChatCliente cliente;
  private Button botOK;
  ChatFrame frame;
  String[] listaDest;
  private String nickDestinatario;
  public java.awt.List txListTalk;
  public TextArea txMsg = null;


public void drawPanel() {
	
	setLayout(new BorderLayout ());
	setBackground(Color.lightGray);

	txMsg = new TextArea("", 2,1, TextArea.SCROLLBARS_VERTICAL_ONLY);		        
	txMsg.setName("MsgInput");
	txMsg.setFont(new Font("Mia", Font.PLAIN, 12));
	txMsg.setBackground(Color.darkGray);
	txMsg.setForeground(Color.white);
	txMsg.setEditable(true);
	add("Center", txMsg);
		   
	txListTalk = new java.awt.List(100, true);
	txListTalk.setBackground(java.awt.Color.blue);
	txListTalk.setFont(new Font("Mm", Font.PLAIN, 12));
	txListTalk.setBackground(Globals.CruscottoColor);
	    add("East", txListTalk);
	loadListDest();

	Panel p0 = new Panel( new BorderLayout() );
	add ("South", p0);

	TextDisplayField labLog = new TextDisplayField("... Scrivi il messaggio" );
	p0.add("North", labLog);

	Panel p1 = new Panel( new GridLayout(1,2) );
	p0.add("East", p1);
	
	EnterExitEnlightButton botOK =  
	       new EnterExitEnlightButton("Send");
	botOK .setBackground(Globals.CruscottoColor);
	p1.add( botOK );
	
	botOK.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		  onSendMessage(txMsg.getText());
	       }
	} );

//	Button botCanc = new Button("Cancel");
//	p1.add( botCanc );
	
/*	botCanc.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		  onCancel();
	       }
	} );
*/
	setVisible(true);
	//toFront();
	//show();
	}

public ChatPanelSendMessage(ChatFrame frame, String[] listaDest) {
	
	this.listaDest = listaDest;
	this.frame = frame;	
		
	drawPanel();

   }                                          

public void loadListDest() {
	
   for (int i=0; i<listaDest.length; i++)
 	  txListTalk.add(listaDest[i]);
}

public void onSendMessage(String msg)  {
	
   String command = Globals.SendMsgCommand;
   command += txMsg.getText()
  	       +  Globals.FieldSeparator; 
  	          
   for (int x=0; x < listaDest.length; x++) {
  	   command += listaDest[x] 
  	           +  Globals.FieldSeparator;
   }  
   try { 
	   frame.cli.SendString( command );
   }
   catch (IOException ex) {
	   System.err.println(getClass().getName() + "errore su onSendMessage");
   	   ex.printStackTrace();
   }
   frame.onBackFromMessage();
}

public void onCancel()  {

   frame.onBackFromMessage();
	
}
}