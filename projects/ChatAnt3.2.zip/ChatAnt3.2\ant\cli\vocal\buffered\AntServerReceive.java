package ant.cli.vocal.buffered;

import java.net.*;
import java.io.*;
import javax.sound.sampled.*;

import ant.awt.AntProgressBar;
import ant.glob.Globals;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class AntServerReceive implements Runnable {
	 

	public int PORT;
	boolean STOP;
	public final int BUFFER = 6000;//8000
	private Thread thread = null;
	SourceDataLine line = null;
	DatagramSocket connection = null;
	DatagramSocket socket = null;
	   DatagramPacket packet = new DatagramPacket(new byte[]{1},1);
	
	
	public static final AudioFormat FORMAT =
		 new AudioFormat(
			 AudioFormat.Encoding.PCM_SIGNED, 16000.0f, 16, 1, 2, 16000.0f, true);

	public AntServerReceive(int porta) {
	    this(porta, null);
	}
	public AntServerReceive(int porta, AntProgressBar prgBar) {

		this.PORT = porta;
		try {
	     System.out.println("--------------ServerReceive: sto aprendo il socket sulla porta = " + PORT);
		 socket = new DatagramSocket(PORT);
		 System.out.println("--------------ServerReceive: socke riuscito !!!!!");		 
		 connection = socket;

		 }catch (Exception exec) {
		   System.out.println("Exception creating connection:");
		   exec.printStackTrace(System.out);
		 }
		 System.out.println("ServerReceive : socket pronto...");
		
		

	}
	
	public void start() {
		thread = new Thread(this);
		thread.start();
		System.out.println("--- ServerReceive start() eseguito");
	}

public void run() {

	DataLine.Info info = new DataLine.Info(SourceDataLine.class, FORMAT);

	try {
		
		line=null;
		line = (SourceDataLine) AudioSystem.getLine(info);
		line.open(FORMAT, BUFFER);
	} catch (LineUnavailableException exec) {
		System.out.println("Play: Audio Output not ready.\n"+exec.getMessage());
	} catch (Exception exec) {
		System.out.println("Play: Fatal Exception:\n"+exec.getMessage());
	}
	
	line.start();
	System.out.println("--------- ServerReceive : speakers abilitati !!!!!");
	DatagramPacket packet = new DatagramPacket(new byte[6000],6000);
	System.out.println("--------- ServerReceive partito !!!!!!!!");
	int n=0;
	while (thread != null && STOP == false) {

	  try {
		connection.receive(packet);
		//System.out.println("loop... "+n++ );
	  }catch(Exception exec) {
		System.out.println("ServerReceive: Exception receiving packet: "+exec.getMessage());
		
	  }
	  line.write(packet.getData(),0,packet.getLength());
	  System.out.println("<---------------------ricevuto packet = " + packet.getLength());
	  packet = new DatagramPacket(new byte[6000],6000);//65536
	  thread.yield();
	}

	//line.stop();
	System.out.println("--------------server receive stopping....");
	//line.flush(); //da errore
	//line.drain(); //danno errore
	line.stop();
	line.close();
	line = null;
	System.out.println("--------------server receive stopped"); 
	connection.close();
	thread=null;

  }
  
  public void setStop() {
	  STOP = true;
   }

   public void cancel() {
	  System.out.println("..AntServerReceive: richiedo cancel");
	STOP = true; 
	//line.drain(); //danno errore
	//line.flush(); //da errore


	line.stop();
	System.out.println("--------------server receive stopping emergenza"); 
	line.close(); 
	line = null; 
	System.out.println("--------------server receive stopped emergenza"); 
	//connection.close(); prima
	//thread=null;
	System.out.println("--------------server receive thread ora � null"); 
	  
	//STOP = true; levato
	//System.out.println("--------------server receive sto per fare interrupt()"); 
	//thread.interrupt();
	//System.out.println("--------------server receive interrupt() eseguito ");	
	connection.close(); 
	System.out.println("--------------server receive connection.close() eseguito ");
    thread = null;
	System.out.println("--------------server receive thread ora � null! CLOSE ALL !!!!!");
	
   }
/*
  private void receive(byte[] data) throws IOException {
  
	if (!IP_Protocol) {	
		receiveUDP();		
        // asterisc per i test		
		// testScritturaAU(receivePacket.getData());	
		//--------------------------	

		 line.write( receivePacket.getData(),  
		            0, receivePacket.getLength() );
		
			    	
	} else {  // *** IP PROTOCOL
		inStream.read(data);	
		line.write(data, 0, data.length);
		testScritturaAU(data);
			
	}
  }

private void receiveUDP() throws IOException {
 	
	receivePacket = new DatagramPacket(new byte[maxsize],maxsize);
	socketUDP.receive(receivePacket);
}

private void testScritturaAU(byte[] data) {

	//--------	  istruzioni per il debug	  
	if (cont < 150)  {
	   cont++;
	   System.out.println("cont " + cont);
	   writer.writeData(data); //istruzione per il debug
	} else {
		//	--------	  scrittura file audio istruzioni per il debug
		writer.closeWriteData();
		writer.saveToFile("c:\\zz\\output_audio.au", AudioFileFormat.Type.AU);
		// ------------	   
	}

}
  
 




private void receiveUDP_new() throws IOException {
 	
	   int len=0;
	   receivePacket = new DatagramPacket(new byte[maxsize],maxsize);
	   socketUDP.receive(receivePacket);
	 
	   len = receivePacket.getLength();
	   	
}

public static void main(String[] args) {

        porta = Integer.parseInt(args[0]);
		AntServerReceive jvms = new AntServerReceive(porta);
		jvms.start();
}


 public void cancel() {
	System.out.println("..AntServerReceive: richiedo cancel");
    thread = null;
	chiudiSocket();
		line.drain();
		line.stop();
		line.close();	
   		System.out.println("..AntServerReceive: chiamata conclusa");
	} 

private void chiudiSocket() {
	try {
		 
		if (!sock_close) {
			if (!IP_Protocol)  socketUDP.close();
			else               serverSocket.close();
			sock_close = true;
		}
			 
	} catch (IOException e) {
	  e.printStackTrace();
	}
	 
}

 private void  parseSample(byte[] data) {
  //byte[] = receivePacket.getData(); //=1024
  for (int i=0; i<5; i++) {  //1000 sample
	  System.out.print(" " + data[i] + "  " );
  }
  System.out.println(" ");

 } 
 
private void updateWindowBar(byte[] data){ 
	
	//updateBar0(receivePacket.getData()); mettere if per UDP

    double somma2=0;
	for (int i=0;  i < 512 ; i+=2) {

		somma2 += Math.abs ( data[i] );
		//System.out.print(" " + data[i] + "  " );
	}
	updateBar( (int) somma2 / 256 );
  }

 public void updateBar(int val) {	
	 if (prgBar != null) prgBar.setValue(val);
 }

 private boolean getVoIPProtocol() { 
    return (Globals.VoIP_Protocol.equals("IP")) ? true : false ;
 }
 
/*
 
 private void receiveUDP_prova() throws IOException {
 	
 	// riceve un array di byte di misura variabile
 	// se ad esempio maxsize � impostato a 64 e io mando 512 
 	// legge 512, se � impostato a 2024 e io mando 512 legge 2024
 	// sembra che questo non dia alcun fastidio, 
 	// tuttavia in questo caso dovrei ridurre i 2048 a 512 con un arraycopy
 	// ricordando che len = receivePacket.getLength(); = 512 (maxsize=2048)
 	
 	//int len = 0;
	//do {
		receivePacket = new DatagramPacket(new byte[maxsize],maxsize);
		socketUDP.receive(receivePacket);
		//dp = new DatagramPacket(new byte[maxsize],maxsize);
		//mysock.receive(dp);

	//  len = receivePacket.getLength();
	//	if (len > (maxsize >> 1))  
	//		maxsize = len << 1;
	//	}
	//while (len >= receivePacket.getData().length);
 			
 }
 
 
private void writeData(byte[] data) {
   //System.out.print("scrivo....");
   out.write(data, 0, bufferLengthInBytes);
}


private void closeWriteData() {

   try
   {
	   out.flush();
	   out.close();

   } catch (IOException ex) {
		   ex.printStackTrace();
   }

   byte audioBytes[] = out.toByteArray();
   ByteArrayInputStream bais = new ByteArrayInputStream(audioBytes);
   audioInputStream = new AudioInputStream(bais, format, audioBytes.length / frameSizeInBytes);

   long milliseconds = (long)((audioInputStream.getFrameLength() * 1000) / format.getFrameRate());
   double duration = milliseconds / 1000.0;

   try {
	   audioInputStream.reset();
	   System.out.println("---chiudo");
   } catch (Exception ex) {
	   ex.printStackTrace();
	   return;
   }
}




public void saveToFile(String name, AudioFileFormat.Type fileType) {

	if (audioInputStream == null) {
		//reportStatus("No loaded audio to save");
		return;
	} else if (file != null) {
		//createAudioInputStream(file, false);
	}

	// reset to the beginnning of the captured data
	try {
		audioInputStream.reset();
	} catch (Exception e) {
		//reportStatus("Unable to reset stream " + e);
		return;
	}
	String fileName;
	File file = new File(fileName = name);
	try {
		if (AudioSystem.write(audioInputStream, fileType, file) == -1) {
			throw new IOException("Problems writing to file");
		}
	} catch (Exception ex) {
	   //reportStatus(ex.toString()); }
	//samplingGraph.repaint();
	}
	System.out.println("---salavagto");
 }
*/

}