package ant.cli;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

import java.awt.*;
import java.awt.event.*;


import java.util.StringTokenizer;
import ant.glob.Globals;

import ant.cli.util.ContaSecondi;class ChatAvviso extends Dialog {

	private String mittente = null;
	private boolean isMessage = false;
	private String message = null;
	TextArea messaggio;
                                                                                                               
	public ChatAvviso(ChatFrame owner, String str, 
					  boolean modal, boolean isMessage ) {
	
	super (owner, "ChatAnt: Messaggio per te !", modal);  

		this.isMessage = isMessage;

		StringTokenizer st = 
			new StringTokenizer(str, Globals.FieldSeparator);
	
		this.message = st.nextToken();
		this.mittente = st.nextToken();

		messaggio = new TextArea("", 2,1, TextArea.SCROLLBARS_VERTICAL_ONLY);		        
		creaFrame();
	}


public void mouseClicked(MouseEvent e) {	

}




public void checkSize() {
	if (isMessage) setSize(370,300);
	else setSize(370,130);
}

public void creaFrame() {
	
	setLayout(new BorderLayout ());

	Panel p0 = new Panel( new BorderLayout() );
	add ("North", p0);

		ContaSecondi lab2 = new ContaSecondi();
		lab2.setBackground( new Color(70,48,129) );
		lab2.setFont(new Font("Mm", Font.PLAIN, 14));
		lab2.setForeground(Color.white);
		lab2.start();	
	p0.add("East", lab2);
	
		
   	if ( isMessage ) {
		TextField sender = new  TextField();
		sender.setBackground(Globals.CruscottoColor);
   		sender.setFont(new Font("Mia", Font.BOLD, 15));
		sender.setText(" Messaggio da: " + mittente);	
		p0.add("Center", sender);
		
		messaggio.setBackground(Color.darkGray);
	    messaggio.setForeground(Color.white);
		messaggio.setText ( "\n" );
		messaggio.append ( message );
		messaggio.setFont(new Font("Mia", Font.PLAIN, 14));			
	} else {
		Label dummy = new Label();
		dummy.setBackground( new Color(70,48,129) );
		p0.add("Center", dummy);
		messaggio.setBackground((new Color(70,48,129)));
	    messaggio.setForeground(Color.magenta);
		messaggio.setText ( "C'� "+ mittente + " che vorrebbe parlare con te !\n");
		messaggio.append ( "Che fai, rispondi ?");
		messaggio.setFont(new Font("Mia", Font.BOLD, 16));
		}	
	add ("Center", messaggio);

	Button bot = new Button(" OK ");
	//bot.setSize(30, 15);
	bot.setBackground((new Color(70,48,129)));
	bot.setForeground(Color.magenta);
	bot.addMouseListener( new MouseAdapter() { 
	  public void mouseClicked( MouseEvent e ) {
		  onClose();
}
  }
);
	add("South", bot);

	checkSize();
	setVisible(true);
	show();
	toFront();

	addWindowListener ( new WindowAdapter() {
	     public void windowClosing(WindowEvent e) {

	      dispose();
	 }
	} 
   ); 
		
}
	boolean modal = true;	ChatFrame owner;public ChatAvviso( ChatFrame owner, String mittente, boolean modal ) {
	
	//super("ChatAnt: Avviso di chiamata per te..");
	super (owner, "ChatAnt: Avviso di chiamata per te..", modal);  
	
	this.mittente = mittente;

	messaggio = new TextArea("", 2,1, TextArea.SCROLLBARS_NONE );		        
	creaFrame();
}

public void onClose() {
	System.out.println("weuiwoeiu");
	  dispose();
}

}