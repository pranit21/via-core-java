/*
 * Created on Oct 28, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.awt;

import java.awt.*;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class AntProgressBar extends Canvas {
	protected long 	maxValue,
					value;

	protected String label;

	protected Color floodColor,
					floodedLabelColor;

	protected boolean	showPercent,
						showLabel,
						showBorder;

	private Image dbuffer=null;
	
	
public AntProgressBar()
{
	this(100L);
}
public AntProgressBar(long maxValue)
{
	this(Math.max(0L, maxValue), 0L);
}
public AntProgressBar(long maxValue, long value)
{
	this.maxValue = Math.max(0L, maxValue);
	this.value = Math.max(0L, value);

	//install defaults
	floodColor = defaultFloodColor();
	floodedLabelColor = defaultFloodedLabelColor();
	setBackground(SystemColor.control);
	showBorder = true;
	showPercent = true;
	setFont(new Font("Dialog", Font.BOLD, 12));
}
public long decrementValue()
{
	if(value > 0L){
		value--;
		repaint();
	}
	return value;
}
/**
 * Questo metodo � stato creato VisualAge.
 * @return java.awt.Color
 */
protected Color defaultFloodColor() {
	return SystemColor.activeCaption;
}
/**
 * Questo metodo � stato creato VisualAge.
 * @return java.awt.Color
 */
protected Color defaultFloodedLabelColor() {
	return SystemColor.activeCaptionText;
}
public Color getFloodColor()
{
	return floodColor;
}
public Color getFloodedLabelColor()
{
	return floodedLabelColor;
}
public String getLabel()
{
	return label;
}
public long getMaximumValue()
{
	return maxValue;
}
public double getPercent()
{
	return ((double)value / (double)maxValue) * 100D;
}
public Dimension getPreferredSize(){
	return new Dimension(300, getFontMetrics(getFont()).getHeight()+4);
}
public long getValue()
{
	return value;
}
public long incrementValue(){
	if(value < maxValue){
		value++;
		repaint();
	}
	return value;
}
public long incrementValueOf(long amount){
	long percAmount = amount/100;
	if(value < maxValue){
		value += percAmount;
		repaint();
	}
	return value;
}
public boolean isBorderShown()
{
	return showBorder;
}
public boolean isLabelShown()
{
	return showLabel;
}
public boolean isPercentShown()
{
	return showPercent;
}
public void paint(Graphics g)
{
	if(dbuffer == null || dbuffer.getWidth(this) < getSize().width || dbuffer.getHeight(this) < getSize().height)
		dbuffer = createImage(getSize().width, getSize().height);
	Graphics dbg = (dbuffer!=null)?dbuffer.getGraphics() : g;
	dbg = (dbg!=null)?dbg : g;
	dbg.setColor(getBackground());
	dbg.fillRect(0, 0, getSize().width, getSize().height);
	render(dbg);
	if(dbg != g){
		g.drawImage(dbuffer, 0, 0, this);
		dbg.dispose();
	}
}
protected void render(Graphics g)
{
	FontMetrics fm = g.getFontMetrics();

	g.setFont(getFont());
	g.setColor(getBackground());
	g.fillRect(0, 0, getSize().width - 1, getSize().height - 1);
	if(showBorder)
		g.draw3DRect(0, 0, getSize().width - 1, getSize().height - 1, false);
	int i = (int)(((double)value / (double)maxValue) * (double)(getSize().width - 4));
	g.setColor((floodColor==null)? defaultFloodColor() : floodColor);
	g.fillRect(2, 2, i, getSize().height - 4);

	String lab = null;
	if(showLabel && showPercent)
		lab = label + " " + Math.round(getPercent()) + "%";
	else if(showLabel)
		lab = label;
	else if(showPercent)
		lab = Math.round(getPercent()) + "%";

	if(lab != null) {
		int lw = (getSize().width - fm.stringWidth(lab))/2;
		int lh = (showLabel)? getSize().height/2 + fm.getDescent():
							getSize().height/2 + fm.getDescent()*3/2;
		g.setColor(getForeground());
		g.clipRect(2, 2, getSize().width-4, getSize().height-4);
		g.drawString(lab, lw, lh);
		g.setColor(floodedLabelColor == null ? defaultFloodedLabelColor() : floodedLabelColor);
		g.clipRect(2, 2, i, getSize().height-4);
		g.drawString(lab, lw, lh);
	}
}
public void setBorderShown(boolean flag)
{
	showBorder = flag;
	repaint();
}
public void setFloodColor(Color color)
{
	floodColor = color;
	repaint();
}
public void setFloodedLabelColor(Color color)
{
	floodedLabelColor = color;
	repaint();
}
public void setLabel(String lab)
{
	label = lab;
	repaint();
}
public void setLabelShown(boolean flag)
{
	showLabel = flag;
	repaint();
}
public void setMaximumValue(long maxValue)
{
	this.maxValue = maxValue;
	repaint();
}
public void setPercent(double d)
{
	d = Math.min(Math.max(d, 0.0D), 100D);
	value = (long)((double)maxValue * (d / 100D));
	repaint();
}
public void setPercentShown(boolean flag)
{
	showPercent = flag;
	repaint();
}
public void setValue(long val)
{
	value = val;
	repaint();
}
public void update(Graphics g)
{
	paint(g);
}

	

}
