package ant.serv;

import java.util.*;

public class DBNick {

	private Hashtable registroNick = new Hashtable() ;

/**
 * Commento del constructor RegistroFile2.
 */
public DBNick() {
	super();
}
public synchronized void add(String nick, ChatServer thread) {
	
   registroNick.put(nick, thread);
//   System.out.println("RegistroFile: dopo del put in hashtable");
	  
}
public Hashtable getChatters() {
	
   return registroNick;	  
}
public int getNumUsers() {
	
   return registroNick.size();	  
}
public ChatServer getThread(String nick) {
 
  ChatServer c = null;
  if ( registroNick.containsKey(nick) ) {
  	 c = (ChatServer) registroNick.get(nick);
  }
  return c;
}
	
  		                                                    
public synchronized boolean isDuplicate( String nick ) {

  return true ? ( registroNick.containsKey(nick) ) : false; 

}
	
  		                                                                
public synchronized void remove(String nick) {

  if ((nick != null) && (registroNick.containsKey( nick )) )	
	  registroNick.remove( nick );
}
}