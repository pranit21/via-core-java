/*
 * Created on 7-apr-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author p
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

package ant.cli.video;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.net.InetAddress;
import javax.media.*;
import javax.media.format.*;
import javax.media.util.*;
import javax.media.control.*;
import javax.media.protocol.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import com.sun.image.codec.jpeg.*;
import ant.glob.Globals;
import ant.cli.ChatFrame;
import ant.cli.ftp.SendImageClient;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class AntVideoFrameGrabbing extends Panel implements ActionListener 
{
  ImageGetter imgGet;
  private SendImageClient sdImgClient ;	
  public static Player player = null;
  public CaptureDeviceInfo di = null;
  public MediaLocator ml = null;
  //public JButton capture = null;
  public Buffer buf = null;
  public Image img = null;
  public VideoFormat vf = null;
  public BufferToImage btoi = null;
  public ImagePanel imgpanel = null;
  private ChatFrame chatFrame;
  private java.net.InetAddress receiverIP; 
  private  String nick; 
  private int contClick;
  public Object ImageLock = new Object();
  public Integer stateLock = new Integer(0);
  public ImageGetter imageGetter;
  private byte[] imageBytes;
  Object waitSync = new Object();
  boolean stateTransition = true;
  
  public AntVideoFrameGrabbing() {   
  }
  
  public AntVideoFrameGrabbing(
      ChatFrame frame, InetAddress receiverIP, String nick ) {
  	
  	chatFrame = frame;
	this.receiverIP = receiverIP;
	this.nick = nick;

  }
   
  class ImageGetter implements Runnable {
  	
  	AntVideoFrameGrabbing grab;
  	Thread tr;
  	
  	ImageGetter(AntVideoFrameGrabbing grab) {
  		this.grab = grab;
  	}
  	
  	public void run() {
      System.out.println("------- Image Getter started");	
  	  while (true) {	
  	  	System.out.println("--- Image Getter: afferro immagine");
  		grabImage();
        
  		//getStateLock().notify();
  		
  		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			tr.interrupt();
			tr=null;
		}
  	  } //END WHILE
  	}
  	
  	public void start() {
  	   tr = new Thread(this);
  	   tr.setDaemon(true);
  	   tr.start();
  	}
  	public void stop() {
  	  tr.interrupt();
  	  tr=null;
  	  
  	}
  
  }
  
  public void draw() throws Exception {	
  	
	setLayout(new BorderLayout());
	final Frame f = new Frame("Ant Image Grabber");
	//AntVideoFrameGrabbing cf = new AntVideoFrameGrabbing();
    
	f.addWindowListener(new WindowAdapter() {
	  public void windowClosing(WindowEvent e) {
	  	 imgGet.stop();
	     playerclose();
	     f.dispose();
	  }
	});
    
	f.add("Center",this);
	f.setVisible(true);
    
	imgpanel = new ImagePanel();
	//capture = new JButton("Capture");
	//capture.addActionListener(this);
    
	String str1 = "vfw:Logitech USB Video Camera:0";
	String str2 = "vfw:Microsoft WDM Image Capture (Win32):0";
	//di = CaptureDeviceManager.getDevice(str1);
	//ml = di.getLocator();
	ml = new MediaLocator(str1);//"vfw://0" 
	    
	try 
	{
	  player = Manager.createRealizedPlayer(ml);
	  player.start();
	  Component comp;
      
	  if ((comp = player.getVisualComponent()) != null)
	  {
		add(comp,BorderLayout.NORTH);
	  }
	  //add(capture,BorderLayout.CENTER);
	  add(imgpanel,BorderLayout.SOUTH);
	} 
	catch (javax.media.NoPlayerException e0) {
	    System.out.println("Videocamera non collegata");	
	    e0.printStackTrace();
	    throw new Exception();
	 
	}
	catch (Exception e) {
		//System.out.println("Videocamera non collegata");	
		e.printStackTrace();
		throw new Exception();
	}
	
	setSize(new Dimension(320,550));
	f.pack();
	
	
	 try {
	 Thread.sleep(1000);
	 } catch (InterruptedException e) {
	 e.printStackTrace();
	 }
	 
	
	imgGet = new ImageGetter(this);
	imgGet.start();
    
  }

  
  public synchronized Integer getStateLock() {
  	return stateLock;
  }
  public synchronized void waitForImage() {
  	getStateLock().notifyAll();
  }


  
  public boolean waitForState() {
  	synchronized (waitSync) {
  		//while (stateTransition) {
  		    waitSync.notifyAll();
  			try {
				waitSync.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
  		//}   	
  		return stateTransition;
  	}
  }

  
 public void grabImage() {
 
	    contClick++;
	
		// Grab a frame
		FrameGrabbingControl fgc = (FrameGrabbingControl)
		player.getControl("javax.media.control.FrameGrabbingControl");
		buf = fgc.grabFrame();
		
		// Convert it to an image
		btoi = new BufferToImage((VideoFormat)buf.getFormat());
		img = btoi.createImage(buf);

		// show the image
		imgpanel.setImage(img);

		try {  
			
			BufferedImage buffImg = (BufferedImage) img;
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			/*
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			*/
			javax.imageio.ImageIO.write((RenderedImage) buffImg, "JPEG" , stream);
			// scrive l'immagine su File
			//javax.imageio.ImageIO.write((RenderedImage) img, "JPEG" , stream);
			imageBytes = stream.toByteArray();  
			//------------------
			/*
			 * asteriscato ma funzionava
			 */
			
			synchronized (stateLock) {
			   getStateLock().notifyAll();
			}
			
			/* questo da dei problemi
			synchronized (waitSync) {
				stateTransition = false;
				waitSync.notifyAll();
			}
			*/
			//------------------
			
			int lung = imageBytes.length;
			System.out.println("ho catturato l'immagine" + lung);
			if (contClick == 1) { 
				//attivo la ricezione dell'immagine da parte del ricevente
				// solo la prima volta
				attivaInterlocutore(lung);
				onStartSending(imageBytes, receiverIP);
			}
			
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
  
  /*
  public static void main(String[] args) 
  {
	Frame f = new Frame("SwingCapture");
	AntVideoFrameGrabbing cf = new AntVideoFrameGrabbing();
    
	f.addWindowListener(new WindowAdapter() {
	  public void windowClosing(WindowEvent e) {
	  playerclose();
	  System.exit(0);}});
    
	f.add("Center",cf);
	f.pack();
	f.setSize(new Dimension(320,550));
	f.setVisible(true);
  }
  */
  public void draw(ChatFrame frame) 
	{
	  Frame f = new Frame("SwingCapture");
	  AntVideoFrameGrabbing cf = new AntVideoFrameGrabbing();
    
	  f.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		playerclose();
		System.exit(0);
		}});
    
	  f.add("Center",cf);
	  f.pack();
	  f.setSize(new Dimension(320,550));
	  f.setVisible(true);
	  addNotify();
	}
  
  
  public static void playerclose() 
  {
	player.close();
	player.deallocate();
	
  }
  

  public void actionPerformed(ActionEvent e) {
  	
  	//NON E' ACCEDUTO il GRABBING � AUTOMATICO a tempo
  	contClick++;
	JComponent c = (JComponent) e.getSource();
    
	//if (c == capture) {
	  // Grab a frame
	  FrameGrabbingControl fgc = (FrameGrabbingControl)
	  player.getControl("javax.media.control.FrameGrabbingControl");
	  buf = fgc.grabFrame();
      
	  // ------ Convert it to an image
	  btoi = new BufferToImage((VideoFormat)buf.getFormat());
	  img = btoi.createImage(buf);  
      //--------------
	  
/*
  byte[] serobj = null;
  try {      
	  byte[] buf2 = new byte[2048];
	  ByteArrayOutputStream buffer = new ByteArrayOutputStream(2048);
	  ObjectOutputStream out = new ObjectOutputStream(buffer);
	 
	Object ob = new Object();
	ob = img; 
	out.writeObject(ob);
	serobj = buffer.toByteArray();
	} catch (IOException e3) {
		// TODO Auto-generated catch block
		e3.printStackTrace();
	}
*/	  

	  // show the image
	  imgpanel.setImage(img);

	 try {  
	 	 		
	  BufferedImage buffImg = (BufferedImage) img;
	  ByteArrayOutputStream stream = new ByteArrayOutputStream();
	  javax.imageio.ImageIO.write((RenderedImage) buffImg, "JPEG" , stream);
	  // scrive l'immagine su File
	  //javax.imageio.ImageIO.write((RenderedImage) img, "JPEG" , stream);
	  byte[] imageBytes = stream.toByteArray();  
	 
	  	int lung = imageBytes.length;
	  	if (contClick == 1) attivaInterlocutore(lung);	  	
	  	
	  	//attivo la ricezione dell'immagine da parte del ricevente
	  	// solo la prima volta
		if (contClick==1) 
		    //chatFrame.cli.onSendImageGrabbed(imageBytes, receiverIP);
		    onStartSending(imageBytes, receiverIP);
		
	} catch (IOException e1) {
		e1.printStackTrace();
	} catch (Exception e2) {
		e2.printStackTrace();
	}
      
	  // save image
	  //saveJPG(img,"c:\\myVideoCapture.jpg");
	//} //if c==capture
  }
  
 private void attivaInterlocutore(int lung) {
   
   	  System.out.println("--- attivo Interlocutore") ;
	  String command = Globals.ImageGrabbedSendCommand +
					   Globals.FieldSeparator + nick //interlocutore
					   + Globals.FieldSeparator + lung
	  
	                   + Globals.FieldSeparator + chatFrame.getNick();//sono io
	  try {
		  chatFrame.cli.SendString(command);
	  } catch (IOException e) {
		  e.printStackTrace();
	  }
 }
  
  class ImagePanel extends Panel 
  {
	public Image myimg = null;
    
	public ImagePanel() 
	{
	  setLayout(null);
	  setSize(320,240);
	}
    
	public void setImage(Image img) 
	{
	  this.myimg = img;
	  repaint();
	}
    
	public void paint(Graphics g) 
	{
	  if (myimg != null) 
	  {
		g.drawImage(myimg, 0, 0, this);
	  }
	}
  }
  
  private void onStartSending(byte[] imageBytes, InetAddress receiver)
	  throws Exception {

	  try {
	  	 //sdImgClient = new SendImageClient( imageBytes, receiver  );
         sdImgClient = new SendImageClient(this, receiver);
	  	 sdImgClient.start();  	 
		 System.out.println("--- ImageSender started");
	  } catch (Exception e) {
		  e.printStackTrace();
		  throw new Exception(getClass().getName() +" eccezione su onSendImageGrabbed ");
	  }

  }

  public static void saveJPG(Image img, String s)
  {
	BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
	Graphics2D g2 = bi.createGraphics();
	g2.drawImage(img, null, null);

	FileOutputStream out = null;
	try
	{ 
	  out = new FileOutputStream(s); 
	}
	catch (java.io.FileNotFoundException io)
	{ 
	  System.out.println("File Not Found"); 
	}
    
	JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
	
	JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bi);
	param.setQuality(0.5f,false);
	encoder.setJPEGEncodeParam(param);
    
	try 
	{ 
	  encoder.encode(bi); 
	  out.close(); 
	  System.out.println("------ AntVideoFrameGrabbing : creata immagine " + s);
	}
	catch (java.io.IOException io) 
	{
	  System.out.println("IOException"); 
	}
  }
  
/**
 * @return Returns the imageBytes.
 */
public byte[] getImageBytes() {
	return imageBytes;
}

}