package ant.awt;

import java.awt.Button;
import java.awt.Color;
import java.awt.event.ActionListener;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class EnlightButton extends Button {

  final static Color[] inBackForeColor  = { Color.black, Color.lightGray };
  final static Color[] outBackForeColor = { Color.lightGray, Color.black };
public EnlightButton( String ButtonLabel ) {

  super( ButtonLabel );
}
public EnlightButton( String ButtonLabel, ActionListener actnLstn ) {

  super( ButtonLabel );

  addActionListener( actnLstn );
}
protected void offButton() {

  setColors( outBackForeColor );
}
protected void onButton() {
	
  setColors( inBackForeColor );
}
private void setColors( Color[] backForeColor ) {
	
  setBackground( backForeColor[ 0 ] );
  setForeground( backForeColor[ 1 ] );
}
}