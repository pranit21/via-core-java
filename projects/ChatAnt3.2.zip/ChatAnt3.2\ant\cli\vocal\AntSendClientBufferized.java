package ant.cli.vocal;

import java.net.*;
import java.io.*;

import javax.sound.sampled.*;
import ant.awt.AntProgressBar;
import ant.awt.TextDisplayField;
import ant.glob.Globals;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class AntSendClientBufferized implements Runnable {
	
	
	public static final AudioFormat FORMAT =
	   new AudioFormat(
		   AudioFormat.Encoding.PCM_SIGNED, 16000.0f, 16, 1, 2, 16000.0f, true);
		   //AudioFormat.Encoding.PCM_SIGNED, 8000.0f, 8, 1, 1, 8000.0f, true);
	public int PORT;
	boolean STOP;
	String host;
	
	DatagramSocket socket = null;
	DatagramPacket packet = new DatagramPacket(new byte[]{1},1);
	InetAddress remote = null;
	
	 private InetAddress address= null;
	
	
	public final int BUFFER = 8000;//2000; //8000;

	private TargetDataLine line = null;
	private DatagramSocket connection = null;
	private Thread thread = null;
	



//leggo da streal e scrivo su dispositivo output (casse)

  public AntSendClientBufferized(String host, int porta ) throws LineUnavailableException {

     this (host, porta, null, null);
  }


  public AntSendClientBufferized(String host, int porta,
	  TextDisplayField labLog, AntProgressBar prgBar ) throws LineUnavailableException {

	 this(host, porta, labLog, prgBar, Globals.VoIP_Protocol);  //IP_PROTOCOL

  }

  public AntSendClientBufferized(String host, int porta,
            TextDisplayField labLog, AntProgressBar prgBar, 
            String VoIP_Protocol)//prima boolean BroadTransmit
                   throws LineUnavailableException {

	 System.out.println ("-- AntSendClient inzializzato on port " + porta);

	//this.labLog = labLog;
	//this.prgBar = prgBar;
	this.host = host;
	this.PORT = porta;
    //this.IP_Protocol = (VoIP_Protocol.equals("IP") ? true : false );   


	 try {

	 socket = new DatagramSocket();
	 address = InetAddress.getByName(host);

	 }catch (Exception exec) {
	   System.out.println("Exception creating connection:");
	   exec.printStackTrace(System.out);
	 }
	 //System.out.println("client Connected to host...");
	 System.out.println("--------- SendClient: address dell'altro = " + address);
	 //Record rec = new Record(socket);
 
  }

 


	public void start() {
	  thread = new Thread(this);
	  connection = socket;
	  thread.setName("Play");
	  thread.start();
	}

	public void stop() {
		thread = null;
	}

	
	public void run() {
		int cont=0;

	  DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);

	  try {
		  line = (TargetDataLine) AudioSystem.getLine(info);
		  line.open(FORMAT, line.getBufferSize());
	  } catch (LineUnavailableException exec) {
		  System.out.println("Record: Audio Input not ready.\n"+exec.getMessage());
	  } catch (Exception exec) {
		  System.out.println("Record: Fatal Exception:\n"+exec.getMessage());
	  }

	  int frameSizeInBytes = FORMAT.getFrameSize();
	  int bufferLengthInFrames = line.getBufferSize() / 8;
	  int bufferLengthInBytes = bufferLengthInFrames * frameSizeInBytes;
	  int minPacketSize = (int)(bufferLengthInBytes/1.5);

//	**************AudioFormat.Encoding.PCM_SIGNED, 16000.0f, 16, 1, 2, 16000.0f, true);

				  //System.out.println("-- sampleRate = " + format.getSampleRate());
	  /*2*/			System.out.println("--frameSizeInBytes = "+ frameSizeInBytes );
	  /*16000*/			System.out.println("--getBufferSize = "+ line.getBufferSize() );
	  /*2000*/			System.out.println("--bufferLengthInFrames = "+ bufferLengthInFrames );
	  /*4000*/		    System.out.println("--bufferLengthInBytes = "+ bufferLengthInBytes );
//	*******************
	/*1 */
  /*4000 */
  /*500 */
  /*500 */


	  byte[] data;
	  int bytesAvailable;

	  line.start();
	  System.out.println("Record started...");
	  while (thread != null && STOP==false) {
		// Send data only when we have a buffer of at least 50%
		//System.out.println("bytesAvailable 0 = " + line.available());

		// con 4096 mando 5000 alla volta e va bene solo per 16000 Hz
		// con 4000 mando 4000 alla volta e va bene anche per 8000 Hz
		if ( STOP==false && (bytesAvailable = line.available()) >= 4096) { //4096 //minPacketSize
		  data = new byte[bytesAvailable];
		  System.out.println("bytesAvailable = "+bytesAvailable);

		  line.read(data,0,bytesAvailable);
		  try {
			  connection.send(
							  new DatagramPacket(data,bytesAvailable,address,PORT));
			//connection.send(new DatagramPacket(data,bytesAvailable));
		  }catch(Exception exec) {
			System.out.println("Record: Exception sending packet: "+exec.getMessage());
		  }
		}
		try {
		  //System.out.println(cont++);
		  thread.sleep(50);
		}catch(InterruptedException exec) {}
	  }
	  System.out.println("--------------SendClient stopping....");
	  line.stop();
	  line.flush();
	  line.close();
	  line = null;
	  connection.close();
	  System.out.println("--------------SendClient stopped....");
	  thread=null;
	  
	}



  public void cancel() {
	 STOP = true;

  }

  public void setStop() {
	 STOP = true;

  }

public void semaforo() {}

/*
 private void connect() 
   throws SocketException, IOException, InterruptedException {
 
	if (!IP_Protocol)
	   socketUDP = new DatagramSocket();
	else {	
	   connectIP(); 			
	}
 }

 private void connectIP() throws InterruptedException,IOException {

    boolean Connected = false;
    while (! Connected) { 
		 Connected = true;  	   	
	     Thread.sleep(1000); 	
		try {
			 socketIP = new Socket(servAddr, porta);
		} catch (IOException e) { Connected = false; }
    } //end while
	outStream = new DataOutputStream(socketIP.getOutputStream());
 }
 
  private void send(byte[] data) throws java.io.IOException {
        
        if (!IP_Protocol) { //** UDP Protocol ** 
		   sended = detector.send(socketUDP, data, sendPacket); //controlla anche isSilence


        } else  //** IP Protocol ** 
		    sended = detector.send(socketIP, data, outStream);

	    if (sended) {
	    	updateWindowBar( (int) detector.getSomma() / 256 );
			//System.out.println("---  parlo da porta "+ broadPort);
			//System.out.println("---parlo");  
	    }

  }

 public void updateWindowBar(int val) {
	   if (prgBar != null) prgBar.setValue(val);
 }

 private void chiudiSocket() {

 try {
 
	 if (!sock_close) {
		 if (!IP_Protocol)  socketUDP.close();
		 else               socketIP.close();
		 sock_close = true;
	 }
	 
 } catch (IOException e) {
   e.printStackTrace();
 }
 
 }



 public synchronized void semaforo() {
	
	 //while (true) {
		 
		  notify();
		  try {
			 wait();
			
		 } catch (InterruptedException e) {
			
			 e.printStackTrace();
		 }
		
	 //}
 }


 private int getPorta() {

   //mai utilizzato: sembra che non serva a niente splittare i pacchhetti
   // su pi� porte (BroadTransmit)

   if (!BroadTransmit) return porta;

   if (contPorta > MAX_PORTS_OPENED) {
	   contPorta = 0;
	   broadPort = porta;
	   return porta;
   }
   else {
	   contPorta++;
	   return broadPort++;
   }

 }

 private void resetPortCounter() {
	 //	mai utilizzato: sembra che non serva a niente splittare i pacchhetti
	 // su pi� porte (BroadTransmit)
   if (!BroadTransmit) return;

   contPorta--;
   broadPort--;
 }
 
*/
}