/*
 * Created on Feb 4, 2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
import java.net.*;
import java.io.*;
import javax.sound.sampled.*;

public class AUWriter {
	
	ByteArrayOutputStream out;
	AudioInputStream audioInputStream;
	//int frameSizeInBytes;
	int bufferLengthInBytes, frameSizeInBytes;
	File file;
	int cont;
	private AudioFormat format;
	
	public AUWriter(AudioFormat format,int bufferLengthInBytes) {
	   this.format = format;
	   
	   this.frameSizeInBytes = format.getFrameSize();
	   this.bufferLengthInBytes = bufferLengthInBytes;
	   out = new ByteArrayOutputStream();
	}
	
	public void closeWriteData() {
	
	   try
	   {
		   out.flush();
		   out.close();
	
	   } catch (IOException ex) {
			   ex.printStackTrace();
	   }
	
	   byte audioBytes[] = out.toByteArray();
	   ByteArrayInputStream bais = new ByteArrayInputStream(audioBytes);
	   audioInputStream = new AudioInputStream(bais, format, audioBytes.length / frameSizeInBytes);
	
	   long milliseconds = (long)((audioInputStream.getFrameLength() * 1000) / format.getFrameRate());
	   double duration = milliseconds / 1000.0;
	
	   try {
		   audioInputStream.reset();
		   System.out.println("---chiudo");
	   } catch (Exception ex) {
		   ex.printStackTrace();
		   return;
	   }
	}
	public void saveToFile(String name, AudioFileFormat.Type fileType) {
	
		if (audioInputStream == null) {
			//reportStatus("No loaded audio to save");
			return;
		} else if (file != null) {
			//createAudioInputStream(file, false);
		}
	
		// reset to the beginnning of the captured data
		try {
			audioInputStream.reset();
		} catch (Exception e) {
			//reportStatus("Unable to reset stream " + e);
			return;
		}
		String fileName;
		File file = new File(fileName = name);
		try {
			if (AudioSystem.write(audioInputStream, fileType, file) == -1) {
				throw new IOException("Problems writing to file");
			}
		} catch (Exception ex) {
		   //reportStatus(ex.toString()); }
		//samplingGraph.repaint();
		}
		System.out.println("---salavagto");
	 }
	 
	public void writeData(byte[] data) {
	   //System.out.print("scrivo....");
	   out.write(data, 0, bufferLengthInBytes);
	}

	/**
	 * 
	 */
	public AUWriter() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
	}
}
