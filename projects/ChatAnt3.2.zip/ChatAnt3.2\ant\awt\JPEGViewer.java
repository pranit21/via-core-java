package ant.awt;
import java.awt.Graphics;
import java.awt.Canvas;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import ant.glob.Globals;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class JPEGViewer extends Canvas {

  Image img, appImg;
  public Image jpeg;

public JPEGViewer(Image img) {

	this.img = img;
	}

public void paint(Graphics g) {
	
	g.drawImage(img, 1, 1, this);
	//g.drawRect(x,x,x,x);
}
  int num;
  
  public JPEGViewer(Image img, int num) {

	this.img = img;
	this.num = num;
	
	}
	
	public int getIndex() {

	return num;	
}

public Image getImage() {

	return img;	
}

private void loadGIFs() {
	
	
		
				appImg = Toolkit.getDefaultToolkit().getImage(
				//Globals.DirGIF + "f" + i + ".gif" );
				   "c:" 
				   + File.separator
				   + "fac.jpeg" );
 	        

				//System.out.println("No Applet:showGIFs: immagine:"+ appImg.toString());
		 }	
	
}

