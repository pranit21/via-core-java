package ant.cli.panels;
import java.awt.Frame;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
import java.awt.Rectangle;

import java.awt.*;
import java.awt.Color;
import java.awt.event.*;

import ant.cli.ChatFrame;
import ant.glob.Globals;

import java.awt.event.WindowAdapter;
import java.awt.Dialog;
import java.awt.event.WindowEvent;
public class ChatFrameRegistration extends Dialog 
   implements ActionListener, ItemListener {

  private Frame owner;   // see validate()
  Checkbox cb1, cb2, cb3;  
  CheckboxGroup cbg = new CheckboxGroup();
  Button ok;    
  TextField txEmail;    
  private TextField txNick;
  private ChatFrame chatFrame;
  
public ChatFrameRegistration( Frame owner, String title, boolean modal ) {
	
  super( owner, title, modal );
  this.owner = owner; 
	
  setBackground( Globals.CruscottoColor );  
  setForeground( Color.white );
  
  Panel content = new Panel( new GridLayout( 6,1,2,2 ) )
  {
	   public Insets getInsets() { return new Insets( 10,10,10,10 ); 
		   } 
  };

  String lab = "Nick : ";
  String lab2 = "Password : ";
  
 Panel p01 = new Panel( new BorderLayout( 2, 2 ) );
	p01.add( new Label( lab ), BorderLayout.WEST );
	txNick = new TextField(25);
	txNick .setFont(new Font("Mia", Font.BOLD, 14));
	txNick .setForeground( Color.red );
	txNick .addActionListener(this);
	p01.add( txNick, BorderLayout.EAST );
/* 1 */ content.add(p01);
 
 Panel p02 = new Panel( new BorderLayout( 2, 2 ) ); 
	p02.add( new Label( lab2 ), BorderLayout.WEST );
	txEmail = new TextField(25);
	txEmail .setFont(new Font("Mia", Font.BOLD, 14));
	txEmail .setBackground( Color.darkGray );
	txEmail.setEnabled(false);
	//txEmail .addActionListener(this);
	p02.add( txEmail, BorderLayout.EAST );


  cb1 = new Checkbox(" Sono gi� registred", cbg, false);    
  cb1.setFont(new Font("Mia", Font.PLAIN, 12));
  cb2 = new Checkbox(" Register me now", cbg, false);    
  cb2.setFont(new Font("Mia", Font.PLAIN, 12));
  cb3 = new Checkbox(" Simply log", cbg, true);    
  cb3.setFont(new Font("Mia", Font.PLAIN, 12));

  cb1.addItemListener(this);
  cb2.addItemListener(this);
  cb3.addItemListener(this);
		
/* 2 */ content.add(p02);     	 
/* 3 */ content.add( cb1 );
/* 4 */ content.add( cb2 );
/* 5 */ content.add( cb3 );
	
	Panel p2 = new Panel();
	  //p2.setForeground( owner.getBackground() );
	  ok = new Button( "OK" );
	  ok.addMouseListener( new MouseAdapter() { 
	      public void mouseClicked( MouseEvent e ) {
	          setNick();
	       }
	   }
	  );
	  
	p2.add( ok );
	  
/* 6 */  content.add( p2 );
	
  add( content );

  addWindowListener ( new WindowAdapter() {
	     public void windowClosing(WindowEvent e) {

	      dispose();
	 }
	} 
   ); 
  
  setResizable( false );
  pack();
  toFront();
  show();
   
}
public void validate() {

  Rectangle parentBounds = owner.getBounds();  // getOwner() throws SecurityException
											   // in Applet
  Rectangle myBounds = super.getBounds();
  myBounds.x = parentBounds.x + ( parentBounds.width  - myBounds.width  ) / 2;
  myBounds.y = parentBounds.y + ( parentBounds.height - myBounds.height ) / 2;
  if ( myBounds.x < 0 ) myBounds.x = 0;
  if ( myBounds.y < 0 ) myBounds.y = 0;
  setBounds( myBounds );
  super.validate();
}




public void actionPerformed( ActionEvent e ) {
	setNick();
}
  
  public void setNick() {
	
	String nick = txNick.getText();
	String pwd = txEmail.getText();	
		
	chatFrame = (ChatFrame)owner;
	
	if ( !(txEmail.isEnabled()) ) {//non sono iscritto e non mi voglio iscrivere
	   
	   try {
	   
	   if ( chatFrame.onLogin(nick) > -1 ) {
	      dispose();
	      chatFrame.enableInput();
	      chatFrame.disableMailSystemMenu();
	      }
	   
	   } catch (Exception e){ e.printStackTrace(); }
	}   
	else
	   if (cb1.getState() == true) { //gi� registrato
	    //  if ( chatFrame.onLoginRegistred(nick) > -1 ) {
	    //  }
	    if ( chatFrame.onLoginGiaRegistrato(nick, pwd) > -1 ) {
		    dispose();	  
		    enableAllMenu();	
	        chatFrame.enableInput();
	      }   
	   } 
	   else if (cb2.getState() == true)  //voglio registrarmi ora
	      if ( chatFrame.onLoginDaRegistrare(nick, pwd) > -1 ) {
		       dispose();	 
		       enableAllMenu();	
	           chatFrame.enableInput();
	      }   
} 


public void enableAllMenu() {
	 
  chatFrame.enableAllMenu();

}

public void enablePassword() {
	
 txEmail.setBackground( Globals.CruscottoColor );
 txEmail .setFont(new Font("Mia", Font.BOLD, 14));
 txEmail .setForeground( Color.red );
 txEmail .addActionListener(this);
 txEmail.setEnabled(true);
  
}
public void itemStateChanged(ItemEvent e) {

	String aa;
	
	if ( cb1.getState() == true  || cb2.getState() == true )
	   enablePassword();	
	//repaint();
}public void paint(Graphics g) {

/*	String msg = "current state: ";
	g.drawString(msg, 6,80);
	msg = "gi� registrato: " + cb1.getState();
	g.drawString(msg, 6,100);

	msg = "da registrare: " + cb2.getState();
	g.drawString(msg, 6,120);
*/
   	//String msg = "checcati entranbi";
	//g.drawString(msg, 6,80);    	
}}