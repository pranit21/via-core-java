package ant.cli.panels;
import java.awt.Frame;
import java.awt.*;

import ant.cli.ChatFrame;
import ant.cli.GIFPicker;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatFrameChooseGuy extends Frame {

  private Frame owner;   // see validate()



  private ChatFrame chatFrame;



  GIFPicker gfp;
  Image[] GuyGIFs=null;
  boolean isAPPLET;

public ChatFrameChooseGuy( 
	Frame owner, boolean isAPPLET, Image[] GuyGIFs, boolean modal ) {
	
  this.owner = owner;     // see validate()
  this.isAPPLET = isAPPLET;
  this.GuyGIFs = GuyGIFs;
  
 
  addGIFPicker(); 
 
//	Panel p2 = new Panel();
//	  Button ok = new Button( "OK" );
//	  ok.addActionListener( this );
						
//	  p2.add( ok );
//	content.add( p2, BorderLayout.SOUTH );
//  add( content );
  setResizable( true );
  setSize(400,400);
  //pack();
  toFront();
  show();

}

public void addGIFPicker() {
	
//	if ( cli.GIFs != null )
	if (isAPPLET)
	   gfp = new GIFPicker( this, GuyGIFs );
	else
	   gfp = new GIFPicker( this ); //true = guy
	   
	gfp.show();

}
}