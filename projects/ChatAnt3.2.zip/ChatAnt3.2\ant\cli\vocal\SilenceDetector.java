/**
 * Created on 4-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;

import java.net.*;
import ant.awt.AntProgressBar;
import java.io.DataOutputStream;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class SilenceDetector {

	public double sogliaCalcolata;
	int contSilence;
	boolean Parlo;
	double somma;
	DataOutputStream outStream;
	Packetizer pack = new Packetizer(512);
	private boolean checkSilence;
	private boolean DEBUG=false;

	SilenceDetector(boolean checkSilence){
		this.checkSilence = checkSilence;
		//System.out.println("---- " + getClass().getName() + "---- " + "La soglia calcolata � ---->" + sogliaCalcolata);
	}

	public boolean send(DatagramSocket socket, byte[] data, DatagramPacket sendPacket )
	     throws java.io.IOException {

		if (!checkSilence) {
			 socket.send( sendPacket ); 	   
		     return true;
	     }
	     
  	    if (isSendable(data)) {
		   //updateBar( (int) somma2 / 256 );	
		   
		   // inserire il packetizer: viene eseguito 4 volte per ottenere 
		   // un array di 512*4 byte 
		   // data arriva di 512 e diventa in seguito a getPacketizedData(); di 2048
		   // non c'� bisogno di ridimensionarlo 
		   //for (int i =0; i<4 ; i++) {
		   //	 pack.packetize(data) ;	
		   //}
			
		  					
			   //print( data );
		   //}
		   //----------------------
//		   if (pack.isPacket_complete()) { 	//pack.flush()   	   
		   //	data = pack.getPacketizedData();
		   
		   
		   socket.send( sendPacket );
		   return true;
		}
  	    
  	    else
	
		  return false;

	}

	public boolean send(Socket socket, byte[] data, DataOutputStream outStream )
	     throws java.io.IOException {

		if (isSendable(data)) {
		   // (DEBUG) System.out.println("---parlo !!! " + somma / 256 );
		   outStream.write(data);
		   return true;
		}
		return false;

	}


	 public boolean isSilence(byte[] data) {

		   somma = 0;

		//while (contSilence > 0) return false;

		   for (int i=0;  i < 512 ; i+=2) { //50,//90 //180

			   somma += Math.abs ( data [i]);
			   //System.out.print(" " + data[i] + "  " );
		   }
		   //System.out.println(" ");
		   //System.out.println("impreciso-- "+ somma/256+ "," + somma%256);
		   //System.out.println("preciso-- "+ somma / 256);
		   //Tot_somma += somma2;

		   return ( somma / 256 > sogliaCalcolata ) ? false : true;
	 }

	 public double getSomma() {
	     return somma;
	 }

	 private boolean isSendable(byte[] data) {
	 	
		 if (contSilence > 2) {
		 	if (DEBUG) System.out.println("......finito strascico azzero");
		 	contSilence=0;
		 	Parlo = false; //last
		 	return true;
		 }
		
		 
		 if (contSilence > 0){
		 	Parlo = true;
		 	contSilence ++;
		 	if (DEBUG) System.out.println("......dentro strascico, contSilence="+contSilence);  
		 	return true;   
		 
		 } 
		 
		 if (contSilence == 0) { //� passato il tempo del dopo fine discorso
			 if ( !isSilence(data) ) {
				 Parlo = true;
				 contSilence=0;
				 if (DEBUG) System.out.println(" PARLO......azzer strascico");
				 return true;
			 }
			 else { //SILENZIO (per la prima volta)
			 	 if (Parlo) {
			 	 	contSilence ++;
			 	 	return true;
			 	 }			 	 
			 }
		 }
		 
		 return false;
		 //else contSilence +=1;

		 //if ( Parlo || contSilence > 0 ) {
			//socket.send( sendPacket );
			//System.out.println( somma2 / 256 + " --- voce !!!!"  );
			//return true;
		 //}
		// return false;
	 }

	public void updateBar(AntProgressBar prgBar, int val) {

		  if (prgBar != null) prgBar.setValue(val);
	}

  public byte[] packetize(byte[] data) throws java.io.IOException {
// non ha portato a buoni risultati
		 pack.packetize(data) ;	
  	     if (pack.isPacket_complete()) 	//pack.flush()   	   
		   	 return pack.getPacketizedData();
         else
             return null;
  }           

/*
	 private boolean isSilence(byte[] data) {

	// qui arrivano 500 sample ma sarebbe meglio calcolarne 1000
			 somma = 0;
		   //byte[] = receivePacket.getData(); //=1024

		   for (int i=0;  i < 180 ; i++) { //50,//90

			   //idx = Math.random() * 500 ;
			   //idxx = (int) idx;

	//		 somma += Math.abs ( data [(int) Math.random() * 500] );
			   ss = Math.abs ( data [(int) Math.random() * 500] );
			   somma += ss;

			   //System.out.print(" " + ss);

			   updateBar( SOGLIA_PER_BYTE - ss );

			   //System.out.print(" " + data[i] + "  " );
		   }
		   //System.out.println(" ");
		   //System.out.println("-- "+ somma);

		   //return ( somma < SOGLIA ) ? false : true;
		   if (somma < SOGLIA) {
			 if ( SogliaReale < SOGLIA)  SogliaReale = SOGLIA;
			 return false;
		   }
		   else {
			 return true;
		   }
	 }
*/

}
