package ant.serv;


 import java.io.*;
 import ant.glob.Globals;
 /*
  *  * This file is part of ChatAnt

 ChatAnt is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 ChatAnt is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


 Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
  */
public class ServerExpirationSetting {

	 private String userDir;
	 public Licence lic;
	 
/**
 * Commento del constructor ServerExpirationSetting.
 */
public ServerExpirationSetting() {
	
}
public ServerExpirationSetting(long now) {
	super();
}
public long getExpiration() {

	return lic.getExpiration();
		
}
public int getPrimoLancio() {

	return lic.getPrimoLancio();
		
}
public void initializeExpirationClassFile() {
	
	 lic = new Licence();
	 lic.setExpiration(0);
	 lic.setPrimoLancio(0);
	 lic.setExpired(false);
	 lic.setMax_Users(lic.MAX_USERS);
	 
	 writeExpirationClassFile();
		
}
public static void main(java.lang.String[] args) {
	
	ServerExpirationSetting sexp = new ServerExpirationSetting(); 
	sexp.initializeExpirationClassFile();
}
public void readExpirationClassFile() {
	

	userDir = System.getProperty("user.dir");
try {
				
  ObjectInputStream in = new ObjectInputStream(
	 new FileInputStream ( 
	    new File( userDir 
			   + File.separator
			   + Globals.ChatProperties
			   + File.separator 
			   + Globals.ServerLicenceConfigFile )));
	
	lic = new Licence();
	lic = (Licence) in.readObject();
}
   	catch (Exception ex) {
	  System.err.println( ex.getMessage() + "\n");	
	  ex.printStackTrace ();
	}
		
}
public void writeExpirationClassFile() {
	
	userDir = System.getProperty("user.dir");
try {
 
  ObjectOutputStream out = new ObjectOutputStream(
	 new FileOutputStream ( 
	    new File( userDir 
			   + File.separator
			   + Globals.ChatProperties
			   + File.separator 
			   + Globals.ServerLicenceConfigFile )));
	
   out.writeObject( lic );
   out.close();
   System.err.println( "--- file serv-config.cfg correttamente impostato");	
}
   	catch (Exception ex) {
	  System.err.println( ex.getMessage() + "\n");	
	  ex.printStackTrace ();
	}
		
}
}
