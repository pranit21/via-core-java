package ant.awt;

import java.awt.*;
import ant.awt.FlexGridLayout;
import java.util.Vector;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class AntGridPanel extends Panel {

  public static final Font bold  = new Font( "dialog", Font.BOLD, 10 );
  public static final Font plain = new Font( "dialog", Font.PLAIN, 10 );
  boolean FACES;
  private boolean GreyLine;
  boolean Red;
  private FlexGridLayout layout;
  private String line;
  private String ri;
  private int riga;
  private int MaxRowChar;


private AntGridPanel() {
}
public AntGridPanel( String[] Columns ) {

  super();

  setLayout( layout = new FlexGridLayout( 0, Columns.length ) );

  Label tdf;
  for ( int i = 0; i < Columns.length; i++ ) {
	 tdf = new Label( Columns[ i ]);  
//	tdf = new TextDisplayField( Columns[ i ] );
	tdf.setFont( bold );
	add( tdf );
  }
}
private AntGridPanel( LayoutManager layout ) {
}
public Component add(Component c) {

   if (c instanceof Label) {	
	    
	 if ( isSplittable(c) ) 
	    return addLabels( getSplittedLines(line) );
  }
  return super.add(c);	
}


public int getColumns() {

  return layout.getColumns();
}


public AntGridPanel( String[] Columns, int MaxRowChar ) {
  super();
  
  this.MaxRowChar = MaxRowChar;
  
  setLayout( layout = new FlexGridLayout( 0, Columns.length, 1, 0 ) ); 
	 //4,4 = hgap, vgap
  
  Label tdf;
  for ( int i = 0; i < Columns.length; i++ ) {
	 tdf = new Label( Columns[ i ]);  
	tdf.setFont( bold );
	add( tdf );
  }
}

public Component addLabels( Vector labs ) {

	for (int i = 0; i < labs.size(); i++) {   
	  super.add( (Label)labs.elementAt(i) );
	}  
	return null;
}

public Vector getSplittedLines(String line) {

	riga = line.length() / MaxRowChar;
	int module = line.length() % MaxRowChar;
		  
	Vector labs = new Vector();
	int i = 0;
	for ( i = 0; i < riga; i++) {
		 //ri = line.substring( MaxRowChar * i, MaxRowChar * (i+1) );
		 ri = line.substring( MaxRowChar * i );
		 labs.addElement (checkGreyLabel( ri ) );
	}
	if (module > 0) {
		ri = line.substring(MaxRowChar * i, MaxRowChar * i + module);
		//labs.addElement( new Label( ri ) );
		labs.addElement( checkGreyLabel( ri ) );
		
	}
	return labs;	
}

public boolean isSplittable(Component c) {

 line = ( (Label) c ).getText();
 
 return true ? ( line.length() > MaxRowChar ) : false; //MaxRowChar = 69
// if ( line.length() > MaxRowChar ) return true;
// else return addSpaces( line );
 
}

  Image img;

public Component add(Image img) {

	this.img = img;  
	ClickableGIF gif = new ClickableGIF(img);

	//if (FACES)	gif.setSize(50,50);
	//else  gif.setSize(16,16);
  return super.add(gif);
}


public AntGridPanel(int span0, int span1 ) {

  super();
  setLayout( layout = new FlexGridLayout( 0, 1, span0, span1 ) );

}

public Component add(Component c, boolean Red) {

   this.Red = Red;
   if (c instanceof Label) {	
	    
	 if ( isSplittable(c) ) 
	    return addLabels( getSplittedLines(line) );
  }
  Red = false; 
  return super.add(c);	
}

public AntGridPanel(int ri, int co, int span0, int span1 ) {

  super();
  setLayout( layout = new FlexGridLayout( ri, co, span0, span1 ) );
  FACES = true;
}

public Component add(String s, boolean Grigio) {
  
  GreyLine = true;
  GreyLabel c = new GreyLabel(s);
	 if ( isSplittable(c) ) 
	    return addGreyLabels( getSplittedLines(line) );
  GreyLine = false;	
   
  return super.add(c);
  
}

public Component addGreyLabels( Vector labs ) {

	for (int i = 0; i < labs.size(); i++) {   
	  super.add( (GreyLabel)labs.elementAt(i) );
	}  
	return null;
}

public Label checkGreyLabel(String ri) {

	if (GreyLine) 
	   return new GreyLabel( ri );
	else {
  	   Label la = new Label( ri );
	   if (Red) {
		  la.setForeground(Color.red);
	   } 
	   return la; 
	}
}
  private int primaVolta = 0;public boolean addSpaces( String line ) {

	String s = "";
	for (int i=0; i < MaxRowChar - line.length(); i++)
	   s += " ";
	   
	line += s;
	
	return false;
}}