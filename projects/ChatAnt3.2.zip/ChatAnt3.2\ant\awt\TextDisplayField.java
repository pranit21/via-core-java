package ant.awt;

import java.awt.*;
import java.awt.event.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class TextDisplayField extends TextField {
	
  private static FocusHandler fh = new FocusHandler();
   
  private static class FocusHandler extends FocusAdapter {

	public void focusGained( FocusEvent e ) {

	  TextField tdf = (TextField) e.getComponent();
	  tdf.transferFocus();
	}
  }
public TextDisplayField() {

  this( "", 0 );
}
public TextDisplayField( int Columns ) {

  this( "", Columns );
}
public TextDisplayField( String Text ) {
	
  this( Text, 0 );
}
public TextDisplayField( String Text, int Columns ) {

  super( Text, Columns );
  setEditable( false );
  setBackground( Color.lightGray );
  addFocusListener( fh );
}

public void setText(String tx){
	super.setText(tx);
}

public boolean isFocusTraversable() {

  return false;
}
}