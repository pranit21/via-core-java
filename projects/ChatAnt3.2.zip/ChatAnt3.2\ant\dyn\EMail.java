package ant.dyn;

import java.io.Serializable;
public class EMail implements Serializable {


	/*
	 *  * This file is part of ChatAnt

	ChatAnt is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	ChatAnt is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


	Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
	 */
public EMail() {
	super();
}
      


  private String mittente, destinatario, 
	 messaggio, orario, titolo;  
/* Commento del constructor ForumRec.
 */
public EMail(String mittente, String destinatario, 
	String titolo, String messaggio, String orario) {

	this.mittente = mittente ;
	this.destinatario = destinatario; 
	this.titolo = titolo;
	this.messaggio = messaggio;
	this.orario = orario;
}public java.lang.String getDestinatario() {
	return destinatario;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @return java.lang.String
 */
public java.lang.String getMessaggio() {
	return messaggio;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @return java.lang.String
 */
public java.lang.String getMittente() {
	return mittente;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @return java.lang.String
 */
public java.lang.String getOrario() {
	return orario;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @return java.lang.String
 */
public java.lang.String getTitolo() {
	return titolo;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @param newMessaggio java.lang.String
 */
public void setMessaggio(java.lang.String newMessaggio) {
	messaggio = newMessaggio;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @param newMittente java.lang.String
 */
public void setMittente(java.lang.String newMittente) {
	mittente = newMittente;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @param newOrario java.lang.String
 */
public void setOrario(java.lang.String newOrario) {
	orario = newOrario;
}/**
 * Insert the method's description here.
 * Creation date: (07/07/2003 18.13.51)
 * @param newTitolo java.lang.String
 */
public void setTitolo(java.lang.String newTitolo) {
	titolo = newTitolo;
}}