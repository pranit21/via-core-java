package ant.awt;

/**
 * Inserire qui la descrizione del tipo.
 * Data di creazione: (27/01/03 21.35.00)
 * @author: Administrator
 */
import java.awt.Label;
import java.awt.Color;
import ant.glob.Globals;
import java.awt.Font;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class GreyLabel extends Label {

	private Boolean SWC;
/**
 * Commento del constructor SwitchableLabel.
 */
public GreyLabel() {
	super();
	
}
/**
 * Commento del constructor SwitchableLabel.
 */
public GreyLabel(String s) {
	
	super(s);
	setForeground(Globals.GRIGETTO);
	setFont(new Font("Dialog", Font.PLAIN, 10));	  
	
}
/**
 * Commento del constructor SwitchableLabel.
 */
public GreyLabel(String s, Color c) {
	
	super(s);
	this.setBackground(c);
	switchColor();
	
}
public Color flip() {
  
  return getBackground().equals(Globals.OutputColor) ?
	   Globals.ARANCIO : Globals.OutputColor;

	}
public void switchColor() {

	this.setBackground( flip() );
	
	}
}