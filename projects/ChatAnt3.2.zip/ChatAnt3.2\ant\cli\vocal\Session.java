/*
 * Created on 19-nov-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;

import javax.sound.sampled.LineUnavailableException;
import ant.glob.Globals;
import ant.awt.AntProgressBar;
import ant.cli.vocal.gsm.vsjtalk;
import ant.cli.vocal.panel.*;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class Session {
	
	private int trial=1;
	AntSendClient asc;
	private AntServerReceive asr;
	SendVoiceParameters param;
	ChatPanelVocal frame;
	AntProgressBar prgBarSpk;
	private vsjtalk talkGSM;
	
	
	public Session(){} 	
	
	public Session( AntSendClient asc, AntServerReceive asr){
	   this(null, asc, asr);
	} 	
	
	public Session(ChatPanelVocal frame, AntSendClient asc, AntServerReceive asr){
	   this.asc=asc;
	   this.asr=asr;
	   this.frame=frame;
	} 
	
	public Session(java.awt.Component frame){
	   this.asc=asc;
	   this.asr=asr;
	   if (frame instanceof ChatPanelVocal) {
		    this.frame=(ChatPanelVocal)frame;
	   }
	   
	} 
	
	public void setProgressBar(AntProgressBar prgBarSpk) {
		this.prgBarSpk=prgBarSpk;
	}
	
    public void startGSMSession(String host) {	
    
	    talkGSM = new vsjtalk(host);
	    talkGSM.startPhone();
    }
	
	public void stopGSMSession() throws java.io.IOException {	
    
		//if (talkGSM != null) talkGSM.stopCall();
		talkGSM.stopCall();
		//talkGSM.interrupt();
		//talkGSM=null;
	}
	
	public void startServerReceive() {
	
		System.out.println("VocalSession prima di startServerReceive");
		asr = new AntServerReceive(Globals.PortaVoice_NO_MIC +1, prgBarSpk);
		asr.start();
		System.out.println("VocalSession dopo di startServerReceive");
	
	}
	
	public void setConnParams(SendVoiceParameters param){
		this.param = param;
	}
	
	public boolean connectClient() {
		
		if (startSendClient()) return true;
		
		while (asc != null && !asc.lineaOK && trial < 4) {
				trial++;
				System.out.println("......ChatVocalPanel, AntSendClient -- tentativo n. " + trial);
				//stopVocalThreads();
			    stopClient();
				try {
					Thread.sleep(1000*3);			
					startSendClient();
				} catch (InterruptedException e2) {
					e2.printStackTrace();
					return false;
				}		 	
		}
		//-----------------------------------------  
		if (asc != null && asc.lineaOK) 
			trial = 0; 
		else {
			System.out.println("-------- collegamento impossibile -----------");
			frame.onStopCall();
			return false;
		} 
		
		return true;
	}

	public void stopClient() {	
		if (asc != null) {	
			asc.setStop();
			asc.cancel();
			asc = null ;		
		}
		asc=null;
	}

	
	public void stopVocalThreads() {
	
		if (asc != null) {	
			asc.setStop();
			asc.cancel();
			asc = null ;		
		}
		if (asr != null) {
		   asr.setStop();
		   asr.cancel();
		}
		asc=null;
		asr=null;
	}
	
	
	public boolean startSendClient() {
	
		//SendVoiceParameters param = setSendVoiceParams();	
		asc = null;
		this.param = param;
    
		System.out.println("......ChatVocalPanel, AntSendClient -- tentativo n. " + trial++);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			asc = new AntSendClient(param);	   				 
			asc.start();		 
		} catch (LineUnavailableException e1) {
			 System.out.println("ChatPanelVocal : linea occupata!");
			 e1.printStackTrace();
			 return false;
			 //frame.sendDiagn	("Attenzione !", "23"); //Sistema occupato, se l\' errore si ripresenta resettare il PC	
		}	
		return true;
	}

}
