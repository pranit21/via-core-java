package ant.dyn;

/**
 * Inserire qui la descrizione del tipo.
 * Data di creazione: (23/02/03 18.32.27)
 * @author: Administrator
 */
import java.io.Serializable;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ForumRec implements Serializable {

  private String FileRef;
  private String Title;


public ForumRec() {
	super();
}
public ForumRec( String Title, String FileRef ) {	
  
	  this.FileRef =FileRef ;
	  this.Title=Title;
  }        
/**
 * Inserire qui la descrizione del metodo.
 * Data di creazione: (23/02/03 19.05.34)
 * @return java.lang.String
 */
public java.lang.String getFileRef() {
	return FileRef;
}
/**
 * Inserire qui la descrizione del metodo.
 * Data di creazione: (23/02/03 19.05.34)
 * @return java.lang.String
 */
public java.lang.String getTitle() {
	return Title;
}
}