package ant.awt;
import java.awt.Frame;


import java.awt.*;
import java.awt.Color;

import ant.glob.Globals;

import java.io.File;public class SplashPanel extends Dialog {

  private Frame owner;   // see validate()
  /*
   *  * This file is part of ChatAnt

  ChatAnt is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  ChatAnt is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


  Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
   */
public void validate() {

  Rectangle parentBounds = owner.getBounds();  // getOwner() throws SecurityException
											   // in Applet
  Rectangle myBounds = super.getBounds();
  myBounds.x = parentBounds.x + ( parentBounds.width  - myBounds.width  ) / 2;
  myBounds.y = parentBounds.y + ( parentBounds.height - myBounds.height ) / 2;
  if ( myBounds.x < 0 ) myBounds.x = 0;
  if ( myBounds.y < 0 ) myBounds.y = 0;
  setBounds( myBounds );
  super.validate();
}

public SplashPanel( Frame owner, String title, String nDiagn, boolean modal ) {
	
  super( owner, title, modal );
  this.owner = owner;     // see validate()
  
  String diagn = Globals.Diagn[ Integer.parseInt(nDiagn) ];
  drawPanel(diagn);
  
}
  Image Formica;public void drawPanel(String diagn) {

  setBackground( Color.red );  
  setForeground( Color.white );
  
  Panel contentErr = new Panel( new BorderLayout( 10, 10 ) ) {
	   public Insets getInsets() { return new Insets( 10,10,10,10 ); } };

  Label lab = new Label( diagn );
  lab.setFont(new Font( "dialog", Font.BOLD, 12 ));
  contentErr.add( lab, BorderLayout.NORTH );

  //contentErr.add( new SplashScreenWindow() );
//  Panel due = new Panel();

//  AntGridPanel tabGIF = new AntGridPanel(1,1);
//  ClickableGIF gif = new ClickableGIF( getFormica() );	 	
//  gif.setSize(18,18);
 //tabGIF.add( gif );
 //due.add(tabGIF );
 //due.add(gif);
 //contentErr.add( due, BorderLayout.CENTER );

  add( contentErr );
  setResizable( false );
  pack();
  show();
}public Image getFormica() {

	// solo per la versione TRIAL Stand alone !!!
	//questo metodo da errore nell'Applet
	
	Image appImg = null;
	String userDir = System.getProperty("user.dir");
	
	Formica = Toolkit.getDefaultToolkit().getImage(
	   userDir 
	   + File.separator
	   + Globals.DirGIF 
	   + File.separator 
	   + "FORMICA.gif" );
 	        
	 return Formica;
}}