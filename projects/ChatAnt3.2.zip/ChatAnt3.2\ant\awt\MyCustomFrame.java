/*
 * Created on 21-mag-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author fi212916
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.awt;
import java.awt.*;
import java.awt.event.*;
import java.lang.StrictMath;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.geom.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class MyCustomFrame extends Frame {

	/**
	 * 
	 */
	public MyCustomFrame() {
		
		
	}


	
	public void paint(Graphics g) {
		
	
		Graphics2D g2D = (Graphics2D) g;	

		GradientPaint gp = new GradientPaint(0,0,Color.blue,
				8.0f, 6.0f,
				//this.getSize().width/2, 
		        //this.getSize().height/2,
				Color.green, true); 
		
		g2D.setPaint(gp);
		
		g2D.fill(
		   new Rectangle2D.Float(0.0f,0.0f, this.getSize().width, this.getSize().height));
		
	
		}
	
    public void update(Graphics g) {
    	repaint();
    }

}
