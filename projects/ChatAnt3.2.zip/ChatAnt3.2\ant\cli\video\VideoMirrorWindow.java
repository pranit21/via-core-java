/*
 * Created on 7-apr-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author p
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

package ant.cli.video;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.net.InetAddress;
import javax.media.*;
import javax.media.format.*;
import javax.media.util.*;
import javax.media.control.*;
import javax.media.protocol.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import com.sun.image.codec.jpeg.*;
import ant.glob.Globals;
import ant.cli.ChatFrame;
import ant.cli.ftp.SendImageClient;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */

public class VideoMirrorWindow extends Panel 
{
  private SendImageClient sdImgClient ;	
  public static Player player = null;
  public CaptureDeviceInfo di = null;
  public MediaLocator ml = null;
  //public JButton capture = null;
  public Buffer buf = null;
  public Image img = null;
  public VideoFormat vf = null;
  public BufferToImage btoi = null;
 // public ImagePanel imgpanel = null;
  private ChatFrame chatFrame;
  private java.net.InetAddress receiverIP; 
  private  String nick; 
  private int contClick;
  public Object ImageLock = new Object();
  public Integer stateLock = new Integer(0);
//  public ImageGetter imageGetter;
  private byte[] imageBytes;
  Object waitSync = new Object();
  boolean stateTransition = true;
  
  public VideoMirrorWindow() {   
  	draw();
  }
  
  public VideoMirrorWindow(
      ChatFrame frame, InetAddress receiverIP, String nick ) {
  	
  	chatFrame = frame;
	this.receiverIP = receiverIP;
	this.nick = nick;

  }
   

  	
  
  
  public void draw() {	
  	
	setLayout(new BorderLayout());
	final Frame f = new Frame("Ant Image Grabber");
	//AntVideoFrameGrabbing cf = new AntVideoFrameGrabbing();
    
	f.addWindowListener(new WindowAdapter() {
	  public void windowClosing(WindowEvent e) {
	     playerclose();
	     f.dispose();
	  }
	});
    
	f.add("Center",this);
	f.setVisible(true);
    
	//imgpanel = new ImagePanel();
    
	String str1 = "vfw:Logitech USB Video Camera:0";
	String str2 = "vfw:Microsoft WDM Image Capture (Win32):0";
	//di = CaptureDeviceManager.getDevice(str1);
	//ml = di.getLocator();
	ml = new MediaLocator(str1);//"vfw://0" 
	
    
	try 
	{
	  player = Manager.createRealizedPlayer(ml);
	  player.start();
	  Component comp;
      
	  if ((comp = player.getVisualComponent()) != null)
	  {
		add(comp,BorderLayout.NORTH);
	  }
	  //add(capture,BorderLayout.CENTER);
	  //add(imgpanel,BorderLayout.SOUTH);
	} 
	catch (javax.media.NoPlayerException e0) {
	  System.out.println("Videocamera non collegata");	
	  e0.printStackTrace();
	}
	catch (Exception e) {
		//System.out.println("Videocamera non collegata");	
		e.printStackTrace();
	}
	
	setSize(new Dimension(320,550));
	f.pack();
	
	
	 try {
	 Thread.sleep(1000);
	 } catch (InterruptedException e) {
	 e.printStackTrace();
	 }
	 

    
  }

 
  
  
  public static void main(String[] args) 
  {
	Frame f = new Frame("SwingCapture");
	VideoMirrorWindow cf = new VideoMirrorWindow();
    cf.draw();
    
    /*
	f.addWindowListener(new WindowAdapter() {
	  public void windowClosing(WindowEvent e) {
	  playerclose();
	  System.exit(0);}});
    */
    /*
	f.add("Center",cf);
	f.pack();
	f.setSize(new Dimension(320,550));
	f.setVisible(true);
	*/
  }

 
  public static void playerclose() 
  {
	player.close();
	player.deallocate();
	
  }
  

}