/*
 * Created on 1-dic-03
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;
import ant.awt.AntProgressBar;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class MicSpkLevels extends Frame{
	
	private AntProgressBar prgBarMic;
	private AntProgressBar prgBarSpk;

	private WindowAdapter WinAdp = new WindowAdapter() {

	  public void windowClosing( WindowEvent e ) {

		 dispose();		 	
	  }
	};
	
	/**
	 * 
	 */
	public MicSpkLevels(int lung) {
		//GraphicsConfiguration gc=null;
		//Rectangle bounds = gc.getBounds();
		//setLocation(100 + bounds.x, 100 + bounds.y);
		prgBarMic = new AntProgressBar(lung);
		prgBarSpk = new AntProgressBar(lung);
		
		int Barra_Applicazioni = 25;
		Dimension Dim = new Dimension(300, 70);
		int w = Dim.width;
		int h = Dim.height;
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		setSize( w, h );
		setLocation( ( d.width - w ), 
		             ( d.height - (h + Barra_Applicazioni) ) );
	
		addWindowListener( WinAdp );
		
		setLayout(new BorderLayout ());
		
		//Panel p1 = new Panel( new GridLayout(1,2) ); //ri-co
		    Panel p0 = new Panel( new GridLayout(2,1) );
				//p0.add("East", p1);
					Panel panBar1 = new Panel( new BorderLayout() );
						  panBar1.add("Center", prgBarMic);
						  panBar1.add("West", new Label("input mic. "));
					Panel panBar2 = new Panel( new BorderLayout() );
						  panBar2.add("Center", prgBarSpk);
						  panBar2.add("West", new Label("output spk."));
				p0.add( panBar1);
				p0.add( panBar2);
		   add("Center", p0); 
		setSize(300,70);   
		show();
		
	}

	/**
	 * @return
	 */
	public AntProgressBar getPrgBarMic() {
		return prgBarMic;
	}

	/**
	 * @return
	 */
	public AntProgressBar getPrgBarSpk() {
		return prgBarSpk;
	}

}
