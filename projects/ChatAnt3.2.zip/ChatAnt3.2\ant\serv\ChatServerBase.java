package ant.serv;
import java.io.*;
import java.util.*;

import ant.glob.Globals;
import ant.dyn.MyVectorInterventi;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public abstract class ChatServerBase extends Thread {
	
	protected static RoomBuster roomBst = new RoomBuster();	
	protected ObjectInputStream iObjStream;
	protected ObjectOutputStream oObjStream;
	protected static String msg;
	protected static String Porta, Http_Directory, Drive, ServerIPAddr;
    public String nick, pwd;
    public static MyVectorInterventi registroInterventi = new MyVectorInterventi();
	static final int ISTANZA = 3;
	static final int OK_INTERVENTO = 5;
	static final int QUIT = 4;
	static final int STRINGA = 2;
	static final int STRINGA_CORTA = 1;
	static final int VAI_AVANTI = 6;
	public boolean Registred = false;

protected static void readServerProperties() throws IOException {
	
     Properties p = new Properties();
	 String userDir = System.getProperty("user.dir");	
	 p.load(new FileInputStream( 
		   userDir 
		   + File.separator
		   + Globals.ChatProperties
		   + File.separator 
		   + Globals.ServerProperty ));
	
	 Porta = p.getProperty("Porta");
	 Http_Directory = p.getProperty("Http_Directory");
	 ServerIPAddr = p.getProperty("IPAddr");
	 Drive = userDir.substring(0, userDir.indexOf(":") +1);
	 
	 System.out.println("--- Server Configuration ---");
	 System.out.println("Porta         : " + Porta);
	 System.out.println("Http_Directory : " + Http_Directory);
	 System.out.println("IPServerAddress: " + ServerIPAddr);
	}
	
public void clearRewiev() {
// ridimensiona il registro interventi precedenti se questo 100 elementi
 if (registroInterventi.size() > 1000) {
 synchronized (registroInterventi) {
   registroInterventi.removeRange(0,100);
  }
 }
}


public void broadcast (String command, Hashtable hash, String message, String nick) {
		
Enumeration e = hash.elements();
	while (e.hasMoreElements ()) {
	  ChatServer c = null;
	  synchronized ( hash ) {
		 c = (ChatServer) e.nextElement ();
	  }
	 
	  //if (c != null) {
		try {
			//--------------------------------------
			// qui spedisco il messaggio al client, lo modifico aggiungendo il nick
			c.oObjStream.writeObject (command + nick + Globals.MsgSeparator + message);
			//--------------------------------------

			} catch (IOException ex) {
		         c.interrupt();
		    }
	    }
	 //}
}

public abstract void preLoginMessage () 
	throws IOException;



public void sendCommandToOneUser (Hashtable hash, String command, String nick) {
	
		System.out.println("--- ChatServer. sendCommandToUneUser, mando comando a: "+ nick);
		ChatServer c = null;

		if (hash.containsKey(nick)) {
			c = (ChatServer) hash.get(nick);
			
			try {
				//--------------------------------------
				// qui spedisco un codice (ad esempio la sveglia) alla lista
				// (nick � colui che manda la sveglia)
				c.oObjStream.writeObject (command + nick);
				//--------------------------------------
			} catch (IOException ex) {
				System.out.println (getClass().getName()+ "Errore al comando wake !");	
				c.interrupt();
			}
			
		}
}
	                                      


public void sendCommandToUsersList (Hashtable hash, String cod, String nick) {
	// arriva al server una stringa del tipo : WAKExxx|xxx|xxx|xxx
	//  la user list � sotto forma di stringa del tipo
	//  "xxx|xxx|xxx|xxx"
	// cod � il command (es "WAKE") da mandare a user list ovvero msg.substring(4)
 	// il registro su cui ricercare il socket corrispondente al nick 
 	// � la Hashtable hash 
 	
 	String nome= "";
	StringTokenizer st = 
	  new StringTokenizer(msg.substring(4), Globals.FieldSeparator);

	while (st.hasMoreTokens()) {

		nome = st.nextToken();
		System.out.println("--- ChatServer. sendCommandToUsersList, mando comando a: "+nome);
		ChatServer c = null;

		if (hash.containsKey(nome)) {
  		   c = (ChatServer) hash.get(nome);
		 
  			try {
  			//--------------------------------------
  			// qui spedisco un codice (ad esempio la sveglia) alla lista
  			// (nick � colui che manda la sveglia)
  			c.oObjStream.writeObject (cod + nick);
  			//--------------------------------------
  			} catch (IOException ex) {
	  		  System.out.println (getClass().getName()+ "Errore al comando wake !");	
  		   	  c.interrupt();
  		   	}
  	   	 
		}
	  }
		
  }                                          

public void simpleBroadcast ( Hashtable hash, String command) {
		
Enumeration e = hash.elements();
	while (e.hasMoreElements ()) {
	  ChatServer c = null;
	  synchronized ( hash ) {
		//if (e.hasMoreElements ()) 
		 c = (ChatServer) e.nextElement ();
	   }
	 
	  //if (c != null) {
		try {
			//--------------------------------------
			// spedisco il messaggio al client, lo modifico aggiungendo il nick
			c.oObjStream.writeObject ( command );
			//--------------------------------------

			} catch (IOException ex) {
		      c.interrupt();
		    }
	  //}
	}
}
  
public void aggiornaListaUtenti(Hashtable hash, String command) {
	
	Enumeration k = hash.keys();
		
	while (k.hasMoreElements ()) {
	   command += Globals.FieldSeparator 
		       + (String) k.nextElement();     
	}
		
	Enumeration e = hash.elements();
	while (e.hasMoreElements ()) {
	  ChatServer c = null;
	  synchronized (hash) {	
		   c = (ChatServer) e.nextElement ();
	  }
	 
	  try {
		 //--------------------------------------
		 // spedisco la lista dei nick aggiornata al client,
		 // la stringa comincia con il codice
		  c.oObjStream.writeObject (command);
			//--------------------------------------
	  } catch (IOException ex) {
		  c.interrupt();
	  }
	}
}

}