package ant.serv;

/**
 * Insert the type's description here.
 * Creation date: (12/06/2003 14.39.52)
 * @author: Administrator
 */

import java.io.*;
import java.util.*;

import ant.glob.Globals;
import ant.dyn.EMail;
import ant.dyn.MyVectorMail;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class RegistredNickServices {

	private Properties p = new Properties();
	private String userDir;
	private String passw;
	private String fileToWrite;
	private Object mails;

 
/**
 * RegistredNickServices constructor comment.
 */
public RegistredNickServices() {

	userDir = System.getProperty("user.dir");
	fileToWrite = userDir
	   + File.separator
	   + Globals.ChatProperties
	   + File.separator 
	   + "NickRegistrati.props";
}
public void  addNewRegistredNick(String nick, String pwd) {

  p.put( nick, pwd );

  try {
	 p.store(new FileOutputStream( fileToWrite ), "Registred Nick Archive");
  }
  catch (IOException e) {
	  System.err.println("RegistredNickServices: errore su addNewRegistredNick" +e);
	  e.printStackTrace();    
  }
 	//return (passw == null) ? -1 : 0;
}
public MyVectorMail altriMessaggiPresenti(Hashtable hash, String destin) {
	
	//mails = p.getProperty(destin);
 	Object obj = hash.get(destin) ;
 	if (obj != null)
 	   return (MyVectorMail)obj; //vettore di oggetti Mail
 	else
 	   return null; 
}

public MyVectorMail checkMail(String destin) throws IOException {

MyVectorMail v = new MyVectorMail();
Object obj = new Object();
	
try {

 String file = userDir
	   + File.separator
	   + Globals.ChatProperties
	   + File.separator 
	   + "EMailStore.props";
	   	
 ObjectInputStream in = new ObjectInputStream( new FileInputStream ( file ) ); 
 obj = in.readObject();
 in.close();

}
catch (IOException e) {
	  System.err.println("RegistredNickServices: errore su StoreEmail " +e);
	  e.printStackTrace(); 
	  
	}
catch (ClassNotFoundException e) {
	  System.err.println("RegistredNickServices: errore su StoreEmail " +e);
	  e.printStackTrace();    
	}

 Hashtable hashMails = new Hashtable();
 hashMails = (Hashtable) obj;
 
 return v = altriMessaggiPresenti(hashMails, destin);

}
public void deleteMail(String destin, int mailNum) throws IOException {

MyVectorMail v = new MyVectorMail();
Object obj = new Object();
String file = userDir
	   + File.separator
	   + Globals.ChatProperties
	   + File.separator 
	   + "EMailStore.props";
Hashtable hashMails = new Hashtable();
	
try {


 ObjectInputStream in = new ObjectInputStream(
	 new FileInputStream ( file ) );
 
 obj = in.readObject();
 in.close();

 hashMails = (Hashtable) obj;
 v = altriMessaggiPresenti(hashMails, destin);
 
 //MyVectorMail v1 = new MyVectorMail();
 if (v.size() == 1)
	hashMails.remove( destin );
 else {     
	v.removeElementAt(mailNum); 
	hashMails.put( destin, v );
 }   
  
 ObjectOutputStream out = new ObjectOutputStream(
	 new FileOutputStream ( file ) );
	
  out.writeObject( (Object)hashMails );
  out.close();
  
  //System.out.println("Ok mail registrata");	
}

/*catch (StreamCorruptedException e) {
	  //---- File vuoto da inizilizzare:
	  // 1) lo inizializzo
	  // 2) Scrivo il primo messaggio arrivato
	  System.err.println("RegistredNickServices: file Mail vuoto, lo creo");
	  ObjectOutputStream out = new ObjectOutputStream(
	      new FileOutputStream ( file ) );
	  out.writeObject( (Object) hashMails );
	  out.close();
	  storeEMail(mail) ;
	}
*/	
catch (IOException e) {
	  System.err.println("RegistredNickServices: errore su StoreEmail " +e);
	  e.printStackTrace();    
	}
catch (ClassNotFoundException e) {
	  System.err.println("RegistredNickServices: errore su StoreEmail " +e);
	  e.printStackTrace();    
	}

}
public String getRegistredNickList () {

	String lista = "";
	//Enumeration e = p.elements();
	for (Enumeration e = p.keys(); e.hasMoreElements(); )
		lista += e.nextElement() + Globals.FieldSeparator;
			
 	return lista;
}
public void loadPropertyFile() throws IOException {

try {	
  p.load(new FileInputStream( fileToWrite ));
	
 }
catch (IOException e) {
	  System.err.println("RegistredNickServices: errore su loadProperyFile " +e);
	  e.printStackTrace();    
	}

}
public int seekRegistredNick(String nick, String pwd) {

	passw = p.getProperty(nick);
	if (passw == null) return -1;
	if (! passw.equals(pwd) ) return 3; //password errata
	else return 0;  //tutto OK
	
	//return (passw == null) ? -1 : 0;
}
public void storeEMail(Object mail) throws IOException {

String destin = ((EMail)mail).getDestinatario();
MyVectorMail v = new MyVectorMail();
Object obj = new Object();
String file = userDir
	   + File.separator
	   + Globals.ChatProperties
	   + File.separator 
	   + "EMailStore.props";
Hashtable hashMails = new Hashtable();
	
try {

//  p.load( new FileInputStream( file ));
 ObjectInputStream in = new ObjectInputStream(
	 new FileInputStream ( file ) );
 
 obj = in.readObject();
 in.close();

 hashMails = (Hashtable) obj;
 
 v = altriMessaggiPresenti(hashMails, destin);
 if ( v != null ) {
	 v.addElement( mail );
	  hashMails.put( destin, v );
	
 }
  else {
	 MyVectorMail v1 = new MyVectorMail();
	 v1.addElement( mail ); 
	 hashMails.put( destin, v1 );
 }
  
  ObjectOutputStream out = new ObjectOutputStream(
	 new FileOutputStream ( file ) );
	
  out.writeObject( (Object)hashMails );
  out.close();
  
//  p.store(new FileOutputStream( file ), "EMail Archive"); da errore!
  System.out.println("Ok mail registrata");	
 }

catch (StreamCorruptedException e) {
	  //---- File vuoto da inizilizzare:
	  // 1) lo inizializzo
	  // 2) Scrivo il primo messaggio arrivato
	  System.err.println("RegistredNickServices: file Mail vuoto, lo creo");
	  ObjectOutputStream out = new ObjectOutputStream(
	      new FileOutputStream ( file ) );
	  out.writeObject( (Object) hashMails );
	  out.close();
	  storeEMail(mail) ;
	}
catch (IOException e) {
	  System.err.println("RegistredNickServices: errore su StoreEmail " +e);
	  //e.printStackTrace();
	  ObjectOutputStream out = new ObjectOutputStream(
	  		new FileOutputStream ( file ) );
	  out.writeObject( (Object) hashMails );
	  out.close();
	  storeEMail(mail) ;
	}
catch (ClassNotFoundException e) {
	  System.err.println("RegistredNickServices: errore su StoreEmail " +e);
	  e.printStackTrace();    
	}

}
}  
