/*
 * Created on Nov 24, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli;
import java.awt.*;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ImageComparing {

	int totaleDifferenze;
	long sommaQuadrati;
	int nOsservazioni;
	
	public static void main(String[] args) {
		
		//Ringer rng = new Ringer();
		//rng.start();
		
		boolean uno = false;
		boolean due = true;
		System.out.println ( uno | due ) ; 
		
		//MicSpkLevels ms = new MicSpkLevels();
		//ms.show(); 
		
		ImageComparing p = new ImageComparing();
		p.fai();
		
	}
		
	private void fai() {


		
		long t = System.currentTimeMillis();
		BufferedImage image=null ;
		try {
			image = ImageIO.read(new File("c:\\semafiri2.jpg"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(System.currentTimeMillis() - t);
		
		
		
		Image appImg = Toolkit.getDefaultToolkit().getImage(		
		   "C:" 
		   + File.separator
		   + "semafiri2.jpg" );
		   
	
		//System.out.println(System.currentTimeMillis() - t2);

		Image appImg2 = Toolkit.getDefaultToolkit().getImage(		
		   "C:" 
		   + File.separator
		   + "semafiri2.jpg" ); //semafiri2_test
	
		//System.out.println(System.currentTimeMillis() - t2);
			
		//handlepixels(appImg, appImg2, 0,0,100,100);
		
	
		//int w = appImg.getWidth(null);       
		//System.out.println("..........." + w);

		//lavora su BufferedImage
		int h = image.getRaster().getHeight();
		int w = image.getRaster().getWidth();
		//DataBufferInt buf = (DataBufferInt) image.getRaster().getDataBuffer();
		//int data1[] = buf.getData();
		
		
		System.out.println("..........." + h + ", " + w);

		long t2 = System.currentTimeMillis();		
		handlepixels(appImg, appImg2, 0,0,150,150);
		
		System.out.println(System.currentTimeMillis() - t2);		
		
	}
	
	
	
	
	/*
	 public static BufferedImage toBufferedImage(Image image) {       
	 	 new ImageIcon(image); //load image        
	 	 int w = image.getWidth(null);       
	 	  int h = image.getHeight(null);        
	 	  BufferedImage bimage = new BufferedImage(w, h, IMAGE_TYPE);       
	 	   //BufferedImage bimage = getDefaultConfiguration().createCompatibleImage(w, h, Transparency.OPAQUE);       
	 	    Graphics2D g = bimage.createGraphics();    
	 	        g.drawImage(image, 0, 0, null);     
	 	           g.dispose();        
	 	           return bimage;    
	 	           }
	*/
	
	
	
	
	
	public void handlesinglepixel(int x, int y, int pixel) {
		int alpha = (pixel >> 24) & 0xff;
		int red   = (pixel >> 16) & 0xff;
		int green = (pixel >>  8) & 0xff;
		int blue  = (pixel      ) & 0xff;
		
		//System.out.println("--- pixel = " + pixel);
		//System.out.print("   " + blue + "   " + red +  "   " + green );
		//System.out.println(" ");
		// Deal with the pixel as necessary...
		
	 }

	public int[] singlePixelValues(int x, int y, int pixel) {
		int alpha = (pixel >> 24) & 0xff;
		int red   = (pixel >> 16) & 0xff;
		int green = (pixel >>  8) & 0xff;
		int blue  = (pixel      ) & 0xff;
		
		//System.out.println("--- pixel = " + pixel);
		//System.out.print("   " + blue + "   " + red +  "   " + green );
		//System.out.println(" ");
		
		
		return new int[] {red,green,blue};
	}
	
	private int comparePixelRGB(int[] pix1, int[] pix2) {
	
	    int difference=0;
	    for (int i=0; i<3; i++) {
			difference += (pix1[i] - pix2[i]);
			sommaQuadrati+=difference*difference;
			nOsservazioni++;
	    }
	    
	    return difference;
	    
	}

	 public void handlepixels(Image img, Image img2, int x, int y, int w, int h) {
		
		int[] pixels = new int[w * h];
		PixelGrabber pg = new PixelGrabber(img, x, y, w, h, pixels, 0, w);
		try {
			pg.grabPixels();
		} catch (InterruptedException e) {
			System.err.println("interrupted waiting for pixels!");
			return;
		}
		if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
			System.err.println("image fetch aborted or errored");
			return;
		}
		int[] pixels2 = new int[w * h];
		pg = new PixelGrabber(img2, x, y, w, h, pixels2, 0, w);
		try {
			pg.grabPixels();
		} catch (InterruptedException e) {
			System.err.println("interrupted waiting for pixels!");
			return;
		}

		
		for (int j = 0; j < h; j++) {
			System.out.println("");
			for (int i = 0; i < w; i++) {
			   //handlesinglepixel(x+i, y+j, pixels[j * w + i]);
			   int[] pix1 = singlePixelValues(x+i, y+j, pixels[j * w + i]);
			   int[] pix2 = singlePixelValues(x+i, y+j, pixels2[j * w + i]);
			   int diff = comparePixelRGB(pix1, pix2);
			   totaleDifferenze += diff; 
			   //System.out.println("differenza riscontrata = " + diff);
			}
		}
		System.out.println("--- totale differenza  = " + Math.abs(totaleDifferenze));
		System.out.println("--- RMS calcolato      = " + 
		     Math.sqrt(sommaQuadrati / nOsservazioni) );
	 }


	
	
}
