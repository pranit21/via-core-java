package ant.dyn;
import java.util.Hashtable;
 import java.util.Enumeration;
import java.net.InetAddress;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public  class RegistroDownload extends Hashtable 
  implements java.io.Serializable {
	  
	private String nomeFile;


public Hashtable getHashDownload() {
	
		return this;
	}

public void put(String nickRichiedente, String nomeFile) {
		
  //if   (! hashFile.containsKey(nick)) {
	//vectFile.removeAllElements() ;

	//il nick e del donatore

	// nomeFile � cos� composto: nome.txt + --> + nickDonatore

	super.put(nickRichiedente, nomeFile);

	  
}
		 public RegistroDownload() {
}		 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 						 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 						 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 						 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 						 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 						 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 						 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 						 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				 		 		 		 				private String nickDonatore;		 		 		 		 				private String nickRichiedente;public String getNomeFile() {
	
//	 nickDonatore = null;
	 Enumeration k = this.keys();	
		while (k.hasMoreElements ()) {			
		 if ( k.hasMoreElements () )
		    // per ora ci sar� solo un elemento
		    // poi dovr� esser gestita una lista, allora questo metodo sar� obsoleto
		    nomeFile = (String) k.nextElement();					  
		    String dd = ( (String) this.get(nomeFile) );		   
		 }
	 return nomeFile;
	}
  
public java.lang.String getNickDonatore() {
	return nickDonatore;
}     
public java.lang.String getNickRichiedente() {
	return nickRichiedente;
}

public void setNickRichiedente(java.lang.String newNickRichiedente) {
	nickRichiedente = newNickRichiedente;
}						private String listaFiles[];public void setListaFiles(String listaFiles[]) {
	this.listaFiles = listaFiles;
}

private InetAddress addressRichiedente;

public InetAddress getAddressRichiedente() {
	return addressRichiedente;
}

public void setAddressRichiedente(java.net.InetAddress address) {
	addressRichiedente = address;
}

public void setNickDonatore(String nickDonatore) {
	this.nickDonatore = nickDonatore;
}
}