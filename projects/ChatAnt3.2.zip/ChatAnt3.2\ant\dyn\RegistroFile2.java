package ant.dyn;

import java.util.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
/**
 * 
 * @author *
 *
 * FileRecord[] contiene i file di un utente
 * filesAllUsers tramite put i FileRecord di tutti gli utenti
 * Il server spedisce al client (metodo sendFiles2) 
 * un RegistroFile2 alla volta, uno per ogni client.
 * Il client li mette tutti insieme (metodo onFileListReceive)
 * con RegistroFile2.put(nick, records) su filesAllUsers,
 * vedi sotto. 
 */

public class RegistroFile2 implements java.io.Serializable {
	
	public FileRecord[] records;
	public String nick;
	private String nickLocalAddress;
	Hashtable filesAllUsers = new Hashtable() ; //registro di tutti i files
	public Hashtable NickIPAdresses = new Hashtable(); 
	
public RegistroFile2() {
	super();
}
public RegistroFile2( String nick, FileRecord[] records ) {
	
	this.nick = nick;
	this.records = records;
}

public RegistroFile2( String nick, FileRecord[] records, String nickLocalAddress) {
	
	this.nick = nick;
	this.records = records;
	this.nickLocalAddress = nickLocalAddress;
}

public Hashtable getAllFiles() {
	
   return filesAllUsers;
	  
}
public void putFilesByNick(String nick, FileRecord[] records) {
	
   //System.out.println("RegistroFile: prima del put in hashtable");
   filesAllUsers.put(nick, records);
   //System.out.println("RegistroFile: dopo del put in hashtable");	  
}

public void putAddressByNick(String nick, String IPAddress) {
	
   //System.out.println("RegistroFile: prima del put in hashtable");
   NickIPAdresses.put(nick, IPAddress);
   //System.out.println("RegistroFile: dopo del put in hashtable");	  
}
public void reset() {
	
   filesAllUsers.clear();
   NickIPAdresses .clear();
}

	/**
	 * @return
	 */
	public String getNickLocalAddress() {
		return nickLocalAddress;
	}

	/**
	 * @param string
	 */
	public void setNickLocalAddress(String string) {
		nickLocalAddress = string;
	}
	
    public String seekNickIPAddress(String nick) {
		return (String)NickIPAdresses.get(nick);  	
    }
}