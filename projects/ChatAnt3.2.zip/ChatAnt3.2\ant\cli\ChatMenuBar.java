package ant.cli;

import java.awt.MenuBar;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.Frame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import ant.cli.panels.*;
import ant.glob.Globals;
import ant.cli.video.MyVideoAudioTransmitter2;

//import java.io.IOException;
import java.io.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatMenuBar implements ActionListener {

	private Frame owner;
	private Menu men, men2, men3, men4, men5, men51, men6, men7;
	private MenuItem item21, item22, item31, item51, item52;
	private MenuItem item511,item512,item513,item514, item61; 
	private boolean isAPPLET;
	MenuBar mb = new MenuBar(); 

public ChatMenuBar() {
	super();
}
public ChatMenuBar(Object obj, boolean isAPPLET) {

	    this.owner = (Frame)obj;
	    this.isAPPLET = isAPPLET;
		//MenuBar mb = new MenuBar(); 
		

   	  men = new Menu("Connect");
 	    men.add("Connect to");
		
		men2 = new Menu("MailSystem");
		  men2.add(item21 = new MenuItem("Check mail"));	
		  men2.add(item22 = new MenuItem("Sender mail"));
		  
	    men3 = new Menu("Repository");
	      men3.add(item31 = new MenuItem("Explore"));	
	    
	    men4 = new Menu("VoIP");
		  men4.add("Parla con...");	  
		 
	    men5 = new Menu("JMF Services");
	       men5.add(item51 = new MenuItem("Attiva Image Grabbing"));  
	       //men5.add(item52 = new MenuItem("Video Transmit"));
	       men51 = new Menu("Start conferencing");
	       men5.add(men51);
	          men51.add(item511 = new MenuItem("Audio transmit"));
	          men51.add(item512 = new MenuItem("Video transmit"));
	          men51.add(item513 = new MenuItem("Audio+Video"));
	          men51.add( new MenuItem("  _____________"));
	          men51.add(item514 = new MenuItem("STOP conferencing"));

       men6 = new Menu("Stop JMF Services");
	      men6.add("Stop");  
	          
	   men7 = new Menu("?");
	      men7.add("Version");  
	          

	 if ( isAPPLET ) {
	 	 men.setEnabled(false); 
		 men3.setEnabled(false);
	 } 

		men.addActionListener(this);
    	men4.addActionListener(this);
	    men5.addActionListener(this);
	    men6.addActionListener(this);
	    men7.addActionListener(this);
	    
		item21.addActionListener(this);
		item22.addActionListener(this);
	    item31.addActionListener(this);
	    item51.addActionListener(this);
	    item511.addActionListener(this);
	    item512.addActionListener(this);
	    item513.addActionListener(this);
	    item514.addActionListener(this);
	

	    mb.add(men);
		mb.add(men2);
	    //mb.add(men3);
	    mb.add(men4);
	    mb.add(men5);
	    mb.add(men6);	    
	    mb.add(men7);
	  
		disableMailMenu();
		men6.setEnabled(false);
	    disableRepoVocalMenu();
		owner.setMenuBar(mb);
}
public void actionPerformed(ActionEvent e) {

try {
		 
	if ( e.getSource().equals(men) ) {
		ChatFrameConnect cfc = new ChatFrameConnect( owner );
	}
	else if ( e.getSource().equals(item22) ) {
		((ChatFrame)owner).onPanelMailActivation();	
	}
	else if ( e.getSource().equals(item21) ) {
		((ChatFrame)owner).cli.sendObject(Globals.CheckMyMailCommand);	
	}
	else if ( e.getSource().equals(item31) ) {
		((ChatFrame)owner).cli.sendObject(Globals.RepositoryCheckCommand);	
	}
	
	else if ( e.getSource().equals(men4) ) {
		((ChatFrame)owner).onVocalChatActivation();	
	}
	else if ( e.getSource().equals(item51) ) {
			((ChatFrame)owner).onVideoGrabbingActivation();	
	}
	else if ( e.getSource().equals(item511) ) {
		men6.setEnabled(true);
       ((ChatFrame)owner).onConferenceStartStop(
       		    MyVideoAudioTransmitter2.AUDIO);
	}
	else if ( e.getSource().equals(item512) ) {
		men6.setEnabled(true);
		((ChatFrame)owner).onConferenceStartStop(
				MyVideoAudioTransmitter2.VIDEO);	
	}
	else if ( e.getSource().equals(item513) ) {
		men6.setEnabled(true);
		((ChatFrame)owner).onConferenceStartStop(
				MyVideoAudioTransmitter2.BOTH);	
	}
	else if ( e.getSource().equals(item514) ) {
		men6.setEnabled(false);
		((ChatFrame)owner).onConferenceStartStop(
				MyVideoAudioTransmitter2.STOP_CONFERENCING);	
	}
	else if ( e.getSource().equals(men6) ) {
		men6.setEnabled(false);
		((ChatFrame)owner).onConferenceStartStop(
				MyVideoAudioTransmitter2.STOP_CONFERENCING);	
	}	
	else if ( e.getSource().equals(men7) ) {
		new ant.awt.SplashScreenVersion(owner).start();
	}
}

catch (IOException ex) {
   System.err.println("errore su ChatMenuBar: SendObject di ChatCliente");
   ex.printStackTrace();
   //throw new IOException("ChatMenuBar : errore su ChatFrameConnect");
 }
//  if ((e.getSource().equals(txInput)) && (e.getID()==1001)) {
//	  cli.onEnter( (String) txInput.getText() );
//  } 
}
public void disableMailMenu() {

	men2.setEnabled(false);
}

/*public void enableMailMenu() {

	men2.setEnabled(true);
}
*/

public void enableAllMenu() {
	men2.setEnabled(true);
	men3.setEnabled(true);
	men4.setEnabled(true);
	men5.setEnabled(true);
}
public void disableRepoVocalMenu() {

	men3.setEnabled(false);
	men4.setEnabled(false);
	men5.setEnabled(false);
	men6.setEnabled(false);
}

public void enableRepoVocalMenu() {

	men3.setEnabled(true);
	men4.setEnabled(true);
	men5.setEnabled(true);
	
}

}
