package ant.cli.forum;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.File;
import java.net.*;

import ant.awt.FormattedList;

import ant.glob.Globals;

import ant.cli.ChatFrame;
import ant.awt.LabLog;
import ant.dyn.ForumRec;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatPanelForum extends Panel {

	int[] cols = {50,25};

	private String nick;
	private Button bot, down;
	public LabLog labLog;	      

	private Hashtable hashFiles = new Hashtable();

	

public void drawPanel() {
	
	setLayout(new BorderLayout ());

	Panel p0 = new Panel( new BorderLayout() );

	add ("South", p0);

	labLog = new LabLog( "..Selezionare un forum da visualizzare o scrivere" );
	labLog.setColor(Globals.CruscottoColor);
	p0.add("Center", labLog);
	
	Panel p1 = new Panel( new GridLayout(1,2) );
	p0.add("East", p1);
	down = new Button("Visualizza");
	down.setSize(45, 15);
	p1.add(down);	
	down.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		   onOpenForum();
	   }
	} );

	Button b2 = new Button("Scrivi");
	b2.setSize(45, 15);
	p1.add(b2);	
	b2.addActionListener( new ActionListener() {
	   public void actionPerformed (ActionEvent e)
	   {
		   onWriteIntervento();
	   }
	} );
	
	forums.setForeground(Globals.Bordeaux);
	forums.setBackground(Color.lightGray);
	forums.removeAll();
		
	add ("Center", forums);
	setVisible(true);		
}

	protected ChatFrame chatFrame;
	private FormattedList forums = new FormattedList(cols);

public ChatPanelForum(ChatFrame chatFrame ) {
	
	this.chatFrame = chatFrame;		
	//System.out.println(getClass().getName()+"Hashfile: " +hashFiles.toString());
	drawPanel();	
   }               

public void add( Object record ) {
	
	String title = ((ForumRec) record).getTitle();
	String nomeHtml = ((ForumRec) record).getFileRef();
	addFormattedRecord( title, nomeHtml );
	//forumVector.addElement(record);
}


public void addFormattedRecord(String f1, String f2) {
	forums.add( 
		  f1 
		  + Globals.FieldSeparator 
		  + f2 
		  + Globals.FieldSeparator ); 	
}

public void onOpenForum()  {

   //String selected[] = forums.getSelectedItems();

   if ((chatFrame.isAPPLET) && (chatFrame.cli != null)) {		 
	   try {			    
		  URL forumUrl =  new URL (chatFrame.cli.getCodeBase() + File.separator + Globals.ChatForumDir
		          + File.separator + getSelectedHtml() );
		  System.out.println("ChatPanelForum isAPPLET: cerco l'url : " + forumUrl.toString());			 
	   	  chatFrame.cli.getAppletContext().showDocument(forumUrl, "pippa");
	   }
	   catch ( Exception e ) {
		   System.err.println("ChatPanelForum: Errore url : " + e);
		   e.printStackTrace();
	   }
   }   
	else {
		//aprire il browser per consultare il forum
		//new DiagnSender(
		//	chatFrame, "Attenzione", "9").sendDiagn();
		 try {	
		     chatFrame.cli.onOpenForumRequest(getSelectedHtml());
		 }    
		 catch ( Exception e ) {
		   System.err.println("ChatPanelForum: Errore su onOpenForumRequest : " + e);
		   e.printStackTrace();
	   }
	} 
   
}

public void onWriteIntervento()  {
		
	cfai =  new 
	    ChatFrameInterv( this, ".. Inserisci il tuo intervento", 
		    getSelectedHtml() );
	  
}
	ChatFrameInterv cfai;
	
public String getSelectedHtml()  {

	String selectedLine = forums.getSelectedItem();
	return  selectedLine.substring( forums.getPosition(1), 
		       selectedLine.length() );	   
}
	

	
}