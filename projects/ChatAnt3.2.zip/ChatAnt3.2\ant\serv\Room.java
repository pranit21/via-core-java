package ant.serv;

import java.util.Hashtable;
import java.util.Calendar;
import java.util.Date;
import ant.glob.Globals;

import ant.dyn.MyVectorInterventi;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class Room {

	public int TOT_ACCESSI = 0;
	private static long ROOM_EXPIRATION = Globals.UN_ORA;
	
	//private static Hashtable registroRoom = new Hashtable() ;
	// static o non static dovrebbe essere la stessa cosa,
	// in quanto tutta la classe Room � definita gi� static !
	private Hashtable registroRoom = new Hashtable();
	private String title;
	private long expirationDate;
	private String dataCreated;
	private String dataExpiration;
	private MyVectorInterventi registroInterventi = new MyVectorInterventi();	
/**
 * Commento del constructor RegistroFile2.
 */
public Room() {
	super();
}
public Room(String title) {
	
	this( title, false );	
}

public Room(String title, boolean NoExpiration) {
	
	this.title = title;
	
	Calendar cal = Calendar.getInstance();
	Date tempo = cal.getTime();
	
	if ( NoExpiration ) {
 	   dataCreated = Globals.StaticRoomDataCreation;		   
	   expirationDate = tempo.getTime();
 	   expirationDate += Globals.ANNO; //scad. un anno
 	   
 	   tempo.setTime(expirationDate);
   	   cal.setTime(tempo); 	   
	   
   	   dataExpiration = 
		   formatDate( cal.get(Calendar.DATE) ) 
	     + "/"
	     + formatDate( (1+(cal.get(Calendar.MONTH))) )
	     + "/"
	     + formatDate( cal.get(Calendar.YEAR) )
	     + " :: "
	     + formatDate( cal.get(Calendar.HOUR_OF_DAY) )
	     + ":"
	     + formatDate( cal.get(Calendar.MINUTE) );

	 
	}
	else {
   	   setExpirationDate(tempo);
   	   tempo.setTime(expirationDate);
   	   cal.setTime(tempo); 	   
   	   dataExpiration = 
		   (cal.get(Calendar.DATE))
	     + "/"
	     + (1+ (cal.get(Calendar.MONTH) )) //perch� i mesi cominciano da zero
	     + "/"
	     + cal.get(Calendar.YEAR)
	     + " :: "
	     + cal.get(Calendar.HOUR)
	     + ":"
	     + cal.get(Calendar.MINUTE);	   
	}
}

private void setExpirationDate(Date tempo) {
	//expirationDate = tempo.getTime() + ROOM_EXPIRATION;
	expirationDate = tempo.getTime() + 60000; //TEST

}

public synchronized void addMember(String nick, Hashtable registroNick ) {
		
	TOT_ACCESSI +=1;
	if ( registroNick.containsKey( nick) ) {
		   ChatServer c = (ChatServer) registroNick.get( nick);
	       registroRoom.put( nick, c ); 		 
	}
}
  		                                        
public Hashtable getChatters() {
	
   return registroRoom;	  
}
public String getDataCreated() {
	return dataCreated;
}

public String getToStringExpirationDate() {
	return dataExpiration;
}

public long getExpirationDate() {
	return expirationDate;
}

public int getNumUsers() {
	
   return registroRoom.size();	  
}
public ChatServer getThread(String nick) {
 
  ChatServer c = null;
  if ( registroRoom.containsKey(nick) ) {
  	 c = (ChatServer) registroRoom.get(nick);
  }
  return c;
}
	
  		                                            
public String getTitle() {
	
   return title;	  
}
public void remove(String nick) {
	//prima sincronizzato (la Hash � gi� sincronizzata)
   registroRoom.remove( nick );
}

public void registraIntervento ( String message, String nick) {
	// prima synchronized Vector � gi� sincronized 
	registroInterventi.addElement(nick + Globals.MsgSeparator + message);
 
}
private String formatDate(int num) {

  return (num < 10) ? '0' + String.valueOf(num)
					:  	String.valueOf(num);

//  if (num < 10) return '0' + String.valueOf(num);
//  else return String.valueOf(num);
}

public MyVectorInterventi getRegistroInterventi() {
	return registroInterventi;
}

}