/*
 * Created on Nov 20, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.awt;
import java.awt.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatterList extends List {
	
	//public java.awt.List lista = new java.awt.List();
	
	public ChatterList(int rows, boolean multipleMode){
		super(rows, multipleMode);
	}
	
	public int getItemCount() {

		return super.getItemCount();
	}

	public int getSelectedIndex() {

		return super.getSelectedIndex();
	}

	public int[] getSelectedIndexes() {

		return super.getSelectedIndexes();
	}

	public String[] getSelectedItems() {

		return super.getSelectedItems();
	}

	public String getSelectedItem() {

		return super.getSelectedItem();
	}

	public String getItem(int index) {

		return super.getItem(index);
	}
	public String[] getItems() {

			return super.getItems();
		}
	
	public void removeAll() {

		super.removeAll();
	}
	
	public void add(String nick){
		super.add(nick);
		
	}


}


