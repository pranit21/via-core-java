package ant.cli.ftp;

import ant.awt.LabLog;

import java.net.*;
import java.io.*;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
/**
 * 
 * @author A.Formiconi
 * esegue "l'upload". Legge un file e lo manda in DataOutptupStream 
 *
 */
public class FtpClient extends Thread {
	Thread thread;
	private InetAddress address;	 	 	
	private int porta;
	private String str;
	private String nick;
	private Socket server ;
	private String nomeFile;
	private LabLog labLog;
	private boolean toRepository = false;
	
public FtpClient ()

		throws IOException {

}

public void destroy() {
	super.destroy();

	// inserire qui la codifica per il rilascio delle risorse
}

public void run() {
	
	try {
	//PolicyEngine.assertPermission(PermissionID.FILEIO);
	sleep(1000);
	Socket server = new Socket ( address, 9990 );	
	System.out.println(" FtpClient donatore, eseguito il socket"); 
    
	FileInputStream finp = new FileInputStream( 
		new File( getDrive() + File.separator 
			+ "MieiFiles" + File.separator 	+ nomeFile ) );
			
	DataInputStream iStream = new DataInputStream(finp);
		 
	BufferedOutputStream out = new BufferedOutputStream(server.getOutputStream());	
	DataOutputStream oStream = new DataOutputStream(out);	
	int BufferSize = 2048; //1024
	byte buf[] = new byte[ BufferSize ];
	int n;
	  
	//while ( ( n = iStream.read( buf ) ) >= 0 ) {
	//  oStream.write( buf );
	while ( ( n = iStream.read( buf, 0, BufferSize ) ) >= 0 ) {
	  oStream.write( buf, 0 ,n );
	  }
	//oStream.writeBytes( "Copied by Big Ant !" );
	
	//    byte bit;
	//    while (iStream.available() != 0 ) {
	//       bit = iStream.readByte();  
	//       oStream.writeByte(bit);
	//     }
	
	finp.close();
	oStream.close();
	iStream.close();
	out.close();
	
	labLog.setText("...upload terminato");
	
	if (null != server) {
	  try {
		thread = null;		
		server.close (); 
	}
	    catch (IOException e) {
		  System.out.println( "FtpClient: errore chiususra socket " + e);
	    }
	    //System.out.println( "FtpClient: Chiudo la connessione con "+ server.getInetAddress() ) ;
	}

	}
	catch ( FileNotFoundException e ) {
	      System.out.println( "FtpClient: file non trovato, eccezione: "+e ) ;
	      System.out.println( "FtpClient: file non trovato = "+ nomeFile);
	}
	catch ( IOException e ) {System.out.println( "FtpClient: file non trovato, eccezione: "+e );
	}
	catch (Exception ex) {
		System.out.println ("FtpClient : errore apertura socket :"+ex);
	}
	finally {
	  //System.out.println ("FtpClient : chiudo il thread");
	  interrupt();
	}
}



public void start() {
	if (thread == null){
		thread = new Thread(this);
		thread.start();
	}
 }           
		

 public FtpClient (String nomeFile, InetAddress address )
	throws IOException {

	    this.address = address;
	    this.nomeFile = nomeFile;
}     

 public FtpClient (String nomeFile, InetAddress address, boolean toRepository, LabLog labLog)
	throws IOException {

		this.toRepository = toRepository;
		this.nomeFile = nomeFile;
		this.address = address;
		this.labLog = labLog;
}   
             
public String getDrive() {
	
	String userDir = System.getProperty("user.dir");
	return userDir.substring(0, userDir.indexOf(":") +1);
}


}