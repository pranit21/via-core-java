package ant.cli.video;
import java.io.*;
import java.awt.*;
import java.net.*;
import java.awt.event.*;
import java.util.*;
import ant.dyn.Target;

import javax.media.*;
import javax.media.rtp.*;
import javax.media.rtp.event.*;
import javax.media.rtp.rtcp.*;
import javax.media.protocol.*;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.Format;
import javax.media.format.FormatChangeEvent;
import javax.media.control.BufferControl;
import com.sun.media.rtp.RTPSessionMgr;

import java.awt.*;
import javax.swing.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class MyAVReceiverTest extends JFrame
 implements ReceiveStreamListener, SessionListener, 
	ControllerListener, RemoteListener
{
    Vector mgrs;
    Vector playerWindows = null;

    boolean dataReceived = false;
    Object dataSync = new Object();

    Vector targets;
    //Rx rx;
    
	Player player;
	  Component center;
	  Component south;
	  DataSource ds;
	  String senderIP; 
	
  public MyAVReceiverTest (String senderIP) {
	 
	this.senderIP =senderIP;
	
	targets = new Vector();
	//Target target = new Target("55533", "127.0.0.1", "44433");
	Target target = new Target("55533", senderIP, "44433");
	targets.add(target);
			
	disegna();
	initialize();

	System.out.println("Partito RECEIVER");
		 
	try {
	   Thread.sleep(10000);
   } catch (InterruptedException e) {
	   // TODO Auto-generated catch block
	   e.printStackTrace();
   }
		
   System.out.println("Stoppato RECEIVER");
 }  
   
   
 public MyAVReceiverTest( Vector targets) {
	 //this.rx= rx;
	 this.targets = targets;	
	 disegna();	
	 initialize();
 }    
 
 private void initialize() {
	mgrs = new Vector( targets.size());
	playerWindows = new Vector();

		// Open the RTP sessions.
		for( int i= 0; i < targets.size(); i++) {		
			Target target= (Target) targets.elementAt( i);

		addTarget( target.ip, target.port, target.localPort);		
	}
 }
    
  private void disegna() {
	setDefaultCloseOperation(EXIT_ON_CLOSE);
		JButton button = new JButton("Select File");
		ActionListener listener = 
			new ActionListener() {
		  public void actionPerformed(
			  ActionEvent event) {
			JFileChooser chooser =
			  new JFileChooser(".");
			int status = 
			  chooser.showOpenDialog(MyAVReceiverTest.this);
			if (status == 
				JFileChooser.APPROVE_OPTION) {
			  File file = chooser.getSelectedFile();
			  try {
				load(file, null);
			  } catch (Exception e) {
				System.err.println("Try again: " + e);
			  }
			}
		  }
		};
		button.addActionListener(listener);
		getContentPane().add(button, 
		  BorderLayout.NORTH);
		pack();
		show();
  	
  	  
  }
    
    
  public void load(final File file, DataSource ds) 
	   throws Exception {
	   	
	 URL url = null; 
	 
	  	
	 if (file != null) url = file.toURL();
	 
	 final Container contentPane = 
	   getContentPane();
	 if (player != null) {
	   player.stop();
	 }
	 if (ds== null)	 player = Manager.createPlayer(url);
	 else
	 player = Manager.createPlayer(ds);
	 
	 ControllerListener listener = 
		 new ControllerAdapter() {
	   public void realizeComplete(
		   RealizeCompleteEvent event) {
		 Component vc = 
		   player.getVisualComponent();
		 if (vc != null) {
		   contentPane.add(vc, 
			 BorderLayout.CENTER);
		   center = vc;
		 } else {
		   if (center != null) {
			 contentPane.remove(center);
			 contentPane.validate();
		   }
		 }
		 Component cpc = 
		   player.getControlPanelComponent();
		 if (cpc != null) {
		   contentPane.add(cpc, 
			 BorderLayout.SOUTH);
		   south = cpc;
		 } else {
		   if (south != null) {
			 contentPane.remove(south);
			 contentPane.validate();
		   }
		 }
		 pack();
		 if (file != null) setTitle(file.getName());
	   }
	 };
	 player.addControllerListener(listener);
	 player.start();
   }
    
 
    public boolean isDone() {
	return playerWindows.size() == 0;
    }

    public void addTarget( String senderAddress,
			   String senderPort,
			   String localPort) {
        try {
	    InetAddress ipAddr;
	    SessionAddress localAddr;
	    SessionAddress destAddr;

	    RTPManager mgr = RTPManager.newInstance();
	    mgr.addSessionListener(this);
	    mgr.addReceiveStreamListener(this);
	    mgr.addRemoteListener( this);

	    ipAddr = InetAddress.getByName( senderAddress);

	    int local_port= new Integer( localPort).intValue();
		
	    if( ipAddr.isMulticastAddress()) {
	        // local and remote address pairs are identical:
	        localAddr= new SessionAddress( ipAddr,
	    				       local_port,
	       				       6);
		    
		    destAddr = new SessionAddress( ipAddr,
					       local_port,
					       6);
	    } else {
	        localAddr= new SessionAddress( InetAddress.getLocalHost(),
	      	  		               local_port);

		int remotePort= new Integer( senderPort).intValue();
		    
                destAddr = new SessionAddress( ipAddr, remotePort);
	    }
			
	    mgr.initialize( localAddr);

	    // You can try out some other buffer size to see
	    // if you can get better smoothness.
	    BufferControl bc = (BufferControl)mgr.getControl("javax.media.control.BufferControl");
	    if (bc != null) {
	        bc.setBufferLength(350);
	    }
		    
    	    mgr.addTarget(destAddr);

	    mgrs.addElement( mgr);	    
        } catch (Exception e){
            System.err.println("Cannot create the RTP Session: " + e.getMessage());
            return;
        }	
    }
    
    public void removeTarget( String address, String port) {


	for (int i = 0; i < mgrs.size(); i++) {
	    RTPSessionMgr mgr= (RTPSessionMgr) mgrs.elementAt( i);

	    SessionAddress addr= mgr.getRemoteSessionAddress();

	    String dataPort= addr.getDataPort() + "";
	    
            if( addr.getDataHostAddress().equals( address)
		&& port.equals( dataPort)) {
		
                mgr.removeTarget( addr, "Closing session from AVReceiver");
                mgr.dispose();

		mgrs.removeElement( mgr);
		
		break;
	    }
	}
    }
    
    /**
     * Close the players and the rtp  managers.
     */
    protected void close() {
	

	

	// close the RTP session.
	for (int i = 0; i < mgrs.size(); i++) {
	    RTPManager mgr= (RTPManager) mgrs.elementAt( i);
	    
            mgr.removeTargets( "Closing session from AVReceiver");
            mgr.dispose();
	    mgr = null;
	}
    }

 


  


    /**
     * SessionListener.
     */
    public synchronized void update(SessionEvent evt) {
	if (evt instanceof NewParticipantEvent) {
	    Participant p = ((NewParticipantEvent)evt).getParticipant();
	    System.err.println("  - A new participant had just joined: " + p.getCNAME());
	}
    }


    /**
     * ReceiveStreamListener
     */
    public synchronized void update( ReceiveStreamEvent evt)
       {
	RTPManager mgr = (RTPManager)evt.getSource();

	Participant participant = evt.getParticipant();	// could be null.
	ReceiveStream stream = evt.getReceiveStream();  // could be null.

	String timestamp= getTimestamp();
	
	if (evt instanceof RemotePayloadChangeEvent) {
     
	    System.err.println("  - Received an RTP PayloadChangeEvent.");
	    System.err.println("Sorry, cannot handle payload change.");
	    System.exit(0);

	} else if (evt instanceof NewReceiveStreamEvent) {
	    try {
		stream = ((NewReceiveStreamEvent)evt).getReceiveStream();
		ds = stream.getDataSource();

		// Find out the formats.
		RTPControl ctl = (RTPControl)ds.getControl("javax.media.rtp.RTPControl");
		if (ctl != null) {
		    System.err.println("  - Recevied new RTP stream: " + ctl.getFormat());
		} else {
		    System.err.println("  - Recevied new RTP stream");
		}
		
		if (participant == null) {
		    System.err.println("      The sender of this stream had yet to be identified.");
		} else {
		    System.err.println("      The stream comes from: " + participant.getCNAME()); 
		}



	try {
    
		player = javax.media.Manager.createPlayer(ds);
		//AGGIUNTO PER GUI----------------------------
		load(null, ds);
		System.out.println("GUI CARICATA");
		
	/*	final Container contentPane = 
		  getContentPane();
		//if (player != null) {
		 // player.stop();
		//}
		player = Manager.createPlayer(ds);
		ControllerListener listener = 
			new ControllerAdapter() {
		  public void realizeComplete(
			  RealizeCompleteEvent event) {
			Component vc = 
			  player.getVisualComponent();
			if (vc != null) {
			  contentPane.add(vc, 
				BorderLayout.CENTER);
			  center = vc;
			} else {
			  if (center != null) {
				contentPane.remove(center);
				contentPane.validate();
			  }
			}
			Component cpc = 
			  player.getControlPanelComponent();
			if (cpc != null) {
			  contentPane.add(cpc, 
				BorderLayout.SOUTH);
			  south = cpc;
			} else {
			  if (south != null) {
				contentPane.remove(south);
				contentPane.validate();
			  }
			}
			pack();
			setTitle("pampero");
			//show();
			//setTitle(file.getName());
		  }
		};
		player.addControllerListener(listener);
		player.start();
*/

    pack();
	} catch (Exception e) {	
	}
				
		//----------------------------------------
		// Notify intialize() that a new stream had arrived.
		synchronized (dataSync) {
		    dataReceived = true;
		    dataSync.notifyAll();
		}

	    } catch (Exception e) {
		System.err.println("NewReceiveStreamEvent exception " + e.getMessage());
		return;
	    }        
	} else if (evt instanceof StreamMappedEvent) {
	    if (stream != null && stream.getDataSource() != null) {
		 ds = stream.getDataSource();
		// Find out the formats.
		RTPControl ctl = (RTPControl)ds.getControl("javax.media.rtp.RTPControl");
		System.err.println("  - The previously unidentified stream ");

		
		if (ctl != null) {
		    System.err.println("      " + ctl.getFormat());
		}
		
		System.err.println("      had now been identified as sent by: " + participant.getCNAME());

		RTPSessionMgr rtpManager= (RTPSessionMgr) evt.getSessionManager();
		SessionAddress addr= rtpManager.getRemoteSessionAddress();
 
  
				
		//----------------------------------------

		if( addr != null) {
	
		}
	    }
	} else if (evt instanceof ByeEvent) {
	    StringBuffer sb= new StringBuffer();

	    sb.append( timestamp + " BYE");

	    String reason= ((ByeEvent) evt).getReason();
	    
	    sb.append( " from " + participant.getCNAME());
	    sb.append( " ssrc=" + stream.getSSRC());
	    sb.append( " reason='" + reason + "'");

	
	}
    }

    public void update( RemoteEvent event) {	
	String timestamp= getTimestamp();       
 
	if( event instanceof ReceiverReportEvent) {
	    ReceiverReport rr= ((ReceiverReportEvent) event).getReport();

	    StringBuffer sb= new StringBuffer();

	    sb.append( timestamp + " RR");

	    if( rr != null) {
		Participant participant= rr.getParticipant();

		if( participant != null) {
		    sb.append( " from " + participant.getCNAME());
		    sb.append( " ssrc=" + rr.getSSRC());
		} else {
		    sb.append( " ssrc=" + rr.getSSRC());
		}

		//rx.rtcpReport( sb.toString());
	    }	    	    
	} else if( event instanceof SenderReportEvent) {
	    SenderReport sr= ((SenderReportEvent) event).getReport();

	    StringBuffer sb= new StringBuffer();

	    sb.append( timestamp + " SR");

	    if( sr != null) {
		Participant participant= sr.getParticipant();

		if( participant != null) {
		    sb.append( " from " + participant.getCNAME());
		    sb.append( " ssrc=" + sr.getSSRC());
		} else {
		    sb.append( " ssrc=" + sr.getSSRC());
		}

		//rx.rtcpReport( sb.toString());
	    }	    	    
	} else {
	    System.out.println( "RemoteEvent: " + event);
	}
    }

    private String getTimestamp() {
	String timestamp;

	Calendar calendar= Calendar.getInstance();

	int hour= calendar.get( Calendar.HOUR_OF_DAY);

	String hourStr= formatTime( hour);

	int minute= calendar.get( Calendar.MINUTE);

	String minuteStr= formatTime( minute);

	int second= calendar.get( Calendar.SECOND);
	
	String secondStr= formatTime( second);
		
	timestamp= hourStr + ":" + minuteStr + ":" + secondStr;	

	return timestamp;
    }

    private String formatTime( int time) {	
	String timeStr;
	
	if( time < 10) {
	    timeStr= "0" + time;
	} else {
	    timeStr= "" + time;
	}

	return timeStr;
    }
    
    /**
     * ControllerListener for the Players.
     */
    public synchronized void controllerUpdate(ControllerEvent ce) {

	//Player p = (Player)ce.getSourceController();

	//if (p == null)
	  //  return;

	// Get this when the internal players are realized.
	if (ce instanceof RealizeCompleteEvent) {
	   /*
	    PlayerWindow pw = find(p);
	    if (pw == null) {
		// Some strange happened.
		System.err.println("Internal error!");
		System.exit(-1);
	    }
	    pw.initialize();
	    pw.setVisible(true);
	    p.start();
	    */
	}

	if (ce instanceof ControllerErrorEvent) {
	    /*
	    p.removeControllerListener(this);
	    PlayerWindow pw = find(p);
	    if (pw != null) {
		pw.close();	
		playerWindows.removeElement(pw);
	    }
*/
	    System.err.println("AVReceiver internal error: " + ce);
	}
    }


	public static void main( String[] args) {
		
		
		 Vector targetVect = new Vector();
		 Target target = new Target("55533", "127.0.0.1", "44433");
		 targetVect.add(target);
		 
		 MyAVReceiverTest receive = new MyAVReceiverTest(targetVect);
		 System.out.println("Partito RECEIVER");
		 
		 try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Stoppato RECEIVER");
		
	 }
	
}




