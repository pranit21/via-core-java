/*
 * Created on 21-nov-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ant.cli;

import ant.glob.*;
import java.util.*;
import java.io.*;
import ant.cli.vocal.*;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */



public class ClientVoiceCommander {

	ChatCliente cli;
	private Session vocalSession; 
	private AntServerReceive asr;
	private AntSendClient asc;
	MicSpkLevels levels;
	NickAdmin nickAdm;
	
	public ClientVoiceCommander(ChatCliente cli, NickAdmin nickAdm){
	   this.cli = cli;
	   this.nickAdm = nickAdm;
	}
	
	private void onVocalCallBusy(String aChiLoMando) throws IOException { 
		cli.SendString(Globals.VocalBusyCommand + aChiLoMando);
	}
	
	private void onVocalCallReceive(
			boolean isGsm, boolean singleWay, String line) throws Exception {
	
		StringTokenizer st = new StringTokenizer(line, Globals.FieldSeparator);
		String command = st.nextToken();
		String meCheRicevo = st.nextToken();
		String chiMiChiama = st.nextToken();
		String tipocall="";
		if (isGsm) tipocall = " GSM "; 
			else tipocall = " NOCOMPRESS " ;
		String tipoc = (singleWay) ? "singol duplex":"full duoplez";
		System.out.println("----->Client: ricevuta chiamata "+ tipocall + " " + tipoc + " , line="+line);
		System.out.println("----->Client: ricevuta chiamata "+ tipocall + ", meCheRicevo " +meCheRicevo);
		System.out.println("");
		
		if ( nickAdm.isVocal_Call_Busy() ) {
	            // sono gi� impegnato in conversazione
				// rimanda al mittente il messaggio di occupato
			onVocalCallBusy(chiMiChiama);
			return; 
		}
	
	    //Ringer ring = new Ringer();     
	    //ring.start()
		
		//------- RIPRISTINARE ----------
	    //cli.sendDiagn("Attenzione...", "22", true); //chiamata voclale in arrivo
		//--------------------------------
		
	    //ring.interrupt();
		
		if ( ! nickAdm.isVocal_Call_Refused() ) {		
			try {			        
				if (isGsm) {
					System.out.println("<---------------- ricevo richiesta di convers. GSM da parte di : " + chiMiChiama);
					nickAdm.setVocalBusy(true);
					onVocalStartCall_GSM(chiMiChiama);
					return;    
				} 
				if (singleWay) {
					System.out.println("<---------------- ricevo richiesta di single way convers.da parte di : " + chiMiChiama);
				}
				else
			    if (!singleWay) { //double
					System.out.println("<--------------- ricevo richiesta di double convers. da parte di : " + chiMiChiama );
								
					asc = new AntSendClient(cli.seekNickIPAddress( chiMiChiama ), 
					     Globals.PortaVoice_NO_MIC +1);
					asc.start();
			    }
	
	/*		    
				try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					} 	
	*/
			    
			    // Asteriscare PER I TEST double
				levels = new MicSpkLevels( 70 ); 	    
				asr = new AntServerReceive(Globals.PortaVoice_NO_MIC, 
				       levels.getPrgBarSpk() ); 
				asr.start();     
				System.out.println("..ChatClient: AntServerReceive started");				
			
			} catch (Exception e) {
				e.printStackTrace();
				nickAdm.setVocalBusy(false);
				new Exception("Eccezione su AntServerReceive");
			}
	
			nickAdm.setVocalBusy(true);
		}
	
		else {	   		
		 // chiamata rifiutata : avverti chi ti ha richiesto -------
		    System.out.println("chiamata rifiutata");
		    onVocalCallRefused(chiMiChiama);
		}
	 }	
	
	private void onVocalStartCall_GSM(String chiMiChiama){
		
		java.net.InetAddress servAddr=null;
		String host = cli.seekNickIPAddress( chiMiChiama );
		
		System.out.println("-------------ChatCliente: ricevuta chiamata GSM per " + host);
		
		vocalSession = new Session();
		vocalSession.startGSMSession(host);
		nickAdm.setVocalBusy(true);
		
	}
	
	private void onVocalCallRefused(String aChiLoMando) throws IOException { 
		cli.SendString(Globals.VocalRefusedCommand + aChiLoMando);
	}
	
	
	
	private void onVocalStopCall() throws Exception {
		
		try {
			if (asr != null) {
			   asr.setStop();   
			   asr.cancel();
			   asr = null;
			   levels.dispose();
			}
			if (asc != null) {	
				asc.setStop();
				asc.cancel();
				asc = null ;		
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			nickAdm.setVocalBusy(false);
			new Exception("Eccezione su AntServerReceive:cancel()");
		}
		nickAdm.setVocalBusy(false);
	}
	
	private void onVocalStopCall_GSM() throws Exception {
		System.out.println("............client: ricevo stopCall GSM");
		if (vocalSession!=null) vocalSession.stopGSMSession();
		//if (talkGSM!=null)talkGSM.stopCall();
		//talkGSM=null;
		nickAdm.setVocalBusy(false);
	}
	
	
public boolean checkVoiceCommand(String line) {

try {	
	//----------------------- voice commands ---------------------
	if (line.indexOf(Globals.StartSingleWayCallCommand) == 0) {
		//seekNickIPAddress(nick)
		//onVocalSingleWayCall(line.substring(4));
		onVocalCallReceive(false, true, line); //nick
		return true; 
	}
	if (line.indexOf(Globals.StartDoubleWayCallCommand + "GSM") == 0) {
		System.out.println(
				"----->Client: ricevo chiamata GSM, line = " + line);
		onVocalCallReceive(true, false, line);
		return true;
	}
	if (line.indexOf(Globals.StartDoubleWayCallCommand) == 0) {
		System.out.println(
				"----->Client: ricevo chiamata StartDoubleWayCallCommand, line = "
				+ line);
		onVocalCallReceive(false, false, line);
		return true;
	}
	if (line.indexOf(Globals.StopCallCommandGSM) == 0) {
		System.out.println(
				"----->Client: ricevuto sop call GSM: " + line);
		onVocalStopCall_GSM();
		return true;
	}
	if (line.indexOf(Globals.StopCallCommand) == 0) {
		System.out.println(
				getClass().getName() + "--ricevuto stopCall");
		onVocalStopCall();
		return true;
	}
//----------------------- voice commands FINE---------------------

} catch (IOException ex) {
	ex.printStackTrace();
	//stop();
} catch (Exception ex) {
	ex.printStackTrace();
}
  
return false;

}
		
	
}