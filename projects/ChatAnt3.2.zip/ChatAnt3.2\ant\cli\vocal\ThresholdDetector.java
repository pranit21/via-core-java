/*
 * Created on 12-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ant.cli.vocal;
import javax.sound.sampled.*;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ThresholdDetector implements Runnable {
	
	private static final int CICLI = 20; 
	AntSendClient altroTr;
	SilenceDetector detector;
	double somma;
	Thread tr;
	boolean Interrupt;
	int cicli;
	private TargetDataLine line;
	int bufferLengthInBytes;
	
	ThresholdDetector(
	   AntSendClient altroTr, SilenceDetector detector, TargetDataLine line, int bufferLengthInBytes) {
	   this.line = line;
	   this.bufferLengthInBytes = bufferLengthInBytes;  
	   this.detector = detector;
	   this.altroTr = altroTr;
	}	
	public void stop() {
		
		  if (tr != null) {	
			  tr.interrupt();
			  Interrupt = true;
			  tr = null;
		  }   
		System.out.println("----------- TREAD DAEMON STOPPED!!!!");	
	 }

  public void run() {
  	
	byte[] data = new byte[bufferLengthInBytes];
 
	try {	
	  //while (!Interrupt) {
	  while (cicli < CICLI) {	
		//Thread.sleep(500);
		line.read(data, 0, bufferLengthInBytes);
		compute(data);	
		cicli++;	
	  } 
	  	
	  double sogliaCalcolata = (somma / (512*CICLI)) + 0.15;	
	  detector.sogliaCalcolata = sogliaCalcolata ;
	  
	  System.out.println("-- ThresholdDetector statistics ");
	  System.out.println("--    sum packets         : " + somma);
	  System.out.println("--    loops performed     : " + cicli);
	  System.out.println("--    Threshold           : " + sogliaCalcolata);	
	  ((AntSendClient)altroTr).semaforo(); 
	  //tr.stop();	   

	} catch(Exception e)
	 { e.printStackTrace(); }  
	 
	finally {  stop();  }
   
	}

	public void start() {
	  Interrupt=false;
	  tr = new Thread(this);
	  tr.setDaemon(true);
	  tr.start();
	}
	
	
  private void compute(byte[] data) {

	for (int i=0;  i < bufferLengthInBytes ; i++) { //512 //50,//90 //180
		somma += Math.abs (data [i]);
		//System.out.print("detect  " + data[i] + "  " );
	}
	//System.out.println(" ");
	//System.out.println("impreciso-- "+ somma/256+ "," + somma%256);
	//System.out.println("preciso-- "+ somma / 256);
	//Tot_somma += somma2;

	//return ( somma / 256 > SOGLIA2 ) ? false : true;
		
  }
  
}
