package ant.serv;

import java.io.*;
import java.util.*;

import ant.glob.Globals;

import ant.dyn.ForumRec;

import ant.dyn.ForumInterv;
/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class ChatServerForum extends ChatServerBase {

  private static Vector rooms = new Vector(); 
  private String Forum, ForumPath;
  private ChatServer serv;
  protected static Properties p = new Properties();
  private static String userDir;
  
  private String strAut; 
  private String strData ;
  private String strTit;
  private String strMess, strBlank;
  
public void preLoginMessage() 
   throws java.io.IOException {	  
}

	

public ChatServerForum() {
	  
}

public Properties getForumProperties()  {
	
	return p;
}

public String getForumPath()  {
	
	String userDir = System.getProperty("user.dir");
	System.out.println("-- user.dir = " + userDir);
	
	if (Http_Directory.equals("") || Http_Directory == null) {
	   ForumPath = userDir 
			   + File.separator
			   + Globals.ChatForumDir
			   + File.separator;
    }		   
    else {
	   ForumPath = Http_Directory  
			   + File.separator
	           + Globals.ChatForumDir
	           + File.separator;
    }
	System.out.println("--forum path = "+ForumPath);		
	return ForumPath;
}
public String parseFile(String s)  {
	
	int ch = s.indexOf("=");
  	return s.substring( ch +1 );
  	       
}

public String parseTitle(String s)  {
	
	int ch = s.indexOf("=");
  	return s.substring( 0,ch );
  	       
}

private void readProperty() throws IOException {

//le propriet� sono state gi� impostate allo start del server

/*	 Properties prop = new Properties();
	 
	 ObjectInputStream in = new ObjectInputStream(
	 new FileInputStream ( 
	    new File( 
		       userDir 
			   + File.separator
			   + Globals.ChatProperties
			   + File.separator 
			   + Globals.PropertyForum )));

 
	 try {
	     prop = (Properties) in.readObject();
	 }
	 catch ( ClassNotFoundException e ) { 
		 throw new RuntimeException( "ChatServerForum: readProperty " + e ); 
		 }

	//Enumeration e = e.propertyNames();
	Enumeration e = prop.elements();
*/	
	Enumeration e = p.elements();
	
	ForumRec rec = new ForumRec();
	while (e.hasMoreElements()) {
	  rec = (ForumRec) e.nextElement();
	   
	  sendForumTitles( rec );
	  //f1 = rec.Title;
 	  //f2 = rec.FileRef;
	  //System.out.println("stampo elemento :" + f1 + "---"+f2);
	}
	//in.close();
 }                             

private void readPropertyFile() throws IOException {

	//eseguito solo una volta a startForum(); 
  String title;
  String fileRef;
   
  BufferedReader in =
	  new BufferedReader(
		new FileReader( userDir 
			   + File.separator
			   + Globals.ChatProperties
			   + File.separator 
			   + Globals.PropertyForumFile ));
				
/*  ObjectOutputStream out = new ObjectOutputStream(
	 new FileOutputStream ( 
	    new File( userDir 
			   + File.separator
			   + Globals.ChatProperties
			   + File.separator 
			   + Globals.PropertyForum )));
*/  	//la serializzazione su file � inutile

  String s;
  while((s = in.readLine())!= null) { 
//	  s2 += s + "\n";
	  title = parseTitle(s);
	  fileRef = parseFile(s);
	  
	  addProperty(title, fileRef); 
  }
   
   //out.writeObject(p); //la serializzazione su file � inutile
   
   in.close();
   //out.close();   
}                    

public void sendForumTitles (ForumRec rec ) 
	throws IOException {

  oObjStream.writeObject( rec );
}

public void startForum()  {
	
try {
	  System.out.println("-- startForum");	
	  userDir = System.getProperty("user.dir");
	  System.out.println("-- UserDir = "+ userDir);	
	  readPropertyFile(); 
	}
catch ( IOException e ) { 
	//throw new RuntimeException( "" + e );
	  System.err.println("startForum: errore su readProperyFile " +e);
	  e.printStackTrace();    
   }	
}

public int verificaComandi( ChatServer server, 
	                        String nick, String msg, 
	     			        ObjectInputStream iObjStream, 
	     			        ObjectOutputStream oObjStream ) 
	 throws java.io.IOException, InterruptedException, ClassNotFoundException {

	this.serv = server; 
	this.nick = nick;
	//this.dbNick = dbNick;
	this.iObjStream = iObjStream;
	this.oObjStream = oObjStream;
	
	if ( msg.indexOf( Globals.ForumTitleRequestCommand ) == 0 ) {  
		readProperty();
	  }
	 
	 return VAI_AVANTI;
	
}

private void writeProperty(String title, String fileRef)
   throws IOException {

   //p.setProperty("indice" , "valore");   
   p.put( title, 
	      new ForumRec(title, fileRef) );  
}                                  
  
  private void addProperty(String title, String fileRef)
   throws IOException {

   //p.setProperty("indice" , "valore");   
   p.put( title, 
	      new ForumRec(title, fileRef) );  
}

public void createHeaderForumFile(String forumPath, String forum) 
   throws IOException {
	
	  BufferedWriter out2 =
	    new BufferedWriter(
		  new FileWriter( forumPath + forum ));
	  
	  StringBuffer sb = new StringBuffer();
	  sb.append("<html><head><title>Forum " + forum + "</title>");
	  sb.append("</head><body><table border='1' width='75%'><tr><td  colspan='2' height='19' bordercolor='#C0C0C0' bgcolor='#C0C0C0'><font face='Arial Black'>");
	  sb.append("Forum : " + forum + "</font></td></tr>");
	  sb.append("<tr><td colspan='2' height='19'>&nbsp;</td></tr>");	 
	  sb.append	('\n' + "</table>" + '\n' + "</body></html>");

	  //sa2 += strAut + strData;	 
	  out2.write(sb.toString());
  	  out2.close();
}
protected StringBuffer loadForum(String forum) throws IOException {

//carica il forum alla richiesta di lettura del client
//aggiungere controllo forum vuoto
	 
   StringBuffer sa2 = new StringBuffer();
   	 
   File file = new File( getForumPath() + forum );  
  
   System.out.println("LoadForum : leggo: " + getForumPath() + forum  );	
   if ( !(file.exists()) ) {
	   return (StringBuffer) sa2.append("--- Nessun intervento presente ---");
	}    
	BufferedReader in2 =
	  new BufferedReader(
		new FileReader( getForumPath() + forum  ));
	
	String sa;
	
	while((sa = in2.readLine())!= null) {
	  if (sa.equals("</table>")) break;  
	     //sa2 += sa + "\n";
	     sa2.append(sa + '\n'); 
	}
	
  in2.close();
  return sa2;
}

private void readPropertyFile2() throws IOException {

//fa la stessa cosa di  readPropertyFile ma sfrutta le
//proprieta di Properties
//metodo non acceduto: non so come carica le chiavi con spazio
  p.load(new FileInputStream( 
	   userDir 
	   + File.separator
	   + Globals.ChatProperties
	   + File.separator 
	   + Globals.PropertyForumFile ));
}

protected void writeIntervAsFirst(ForumInterv frmInt) throws IOException {
  
   Forum = frmInt.getSelectedForum();    		
   ForumPath = getForumPath();
   System.out.println("path forum: " + ForumPath + Forum);	
   File file = new File( ForumPath + Forum );
      
   if ( !(file.exists()) ) {
	  createHeaderForumFile( ForumPath, Forum );
	}
   
	prepareHtmlIntervento(frmInt);            
	    
	BufferedReader in2 = new BufferedReader(
		new FileReader( ForumPath + Forum ));
	
	String s;
	StringBuffer sb2 = new StringBuffer();
	StringBuffer sb1 = new StringBuffer();
	boolean getHeader = true;
	
	while((s = in2.readLine()) != null) {
	  if ( getHeader ) 
	       sb1.append(s + '\n'); 
	  else sb2.append(s + '\n'); 
	  
	  if (s.indexOf("&nbsp;</td></tr>") > 0) 
	     getHeader = false;
	    
	}
	//while((s = in2.readLine()) != null) {
	//	 sb2.append(s + '\n'); 
	//}
		
  in2.close();

  BufferedWriter out2 =
	  new BufferedWriter(
		new FileWriter( ForumPath + Forum ));
	  
	out2.write(sb1.toString()); //testata
	  
	out2.write(strAut);
    out2.write(strData);	
    out2.write(strTit);
    out2.write(strMess);
    out2.write(strBlank);
    //out2.write(strClose);
    
    out2.write(sb2.toString());
    
    out2.close();
	System.out.println("fineeeee");
}



private void prepareHtmlIntervento(ForumInterv frmInt) {
	
	Calendar cal = Calendar.getInstance();
	Date tempo = cal.getTime();
	java.text.SimpleDateFormat df = 
				new java.text.SimpleDateFormat("dd.MM.yyyy 'at' HH:mm"); 
	String data = df.format(tempo);
	
	strAut = "<tr><td width='25%' height='19' style='background-color: #C0C0C0'><b>Autore:</b> "
					+  frmInt.getTxAutore() 	              
	  				+ "</td>" + '\n'; 
	strData = "<td width=25% height=19 style='background-color: #C0C0C0'><b>Data:</b> "
					+ data 
					+ "</td></tr>" + '\n';
	strTit =  "<tr><td width='50%' colspan='2' height='19' style='background-color: #C0C0C0'><b>Titolo:</b> "
					+ frmInt.getTxTitolo() 	                
					+ "</td></tr>" + '\n';
	strMess =  "<tr><td width='50%' colspan='2' height='49' style='background-color: #E8FF9F'>"
	                  + frmInt.getTxText()
	                  + "</td></tr>" + '\n';
	strBlank = "<tr><td width='50%' colspan='2' height='30'></td></tr>" + '\n';
}

protected void writeIntervAsLast(ForumInterv frmInt) throws IOException {
   
   Forum = frmInt.getSelectedForum();    		
   ForumPath = getForumPath();
   System.out.println("path forum: " + ForumPath + Forum);	
   File file = new File( ForumPath + Forum );
      
   if ( !(file.exists()) ) {
	 createHeaderForumFile( ForumPath, Forum );
	}
   
	prepareHtmlIntervento(frmInt);
/*	String strAut = "<tr><td width='25%' height='19' style='background-color: #C0C0C0'><b>Autore:</b> "
					+  frmInt.getTxAutore() 	              
	  				+ "</td>"; 
	String strData = "<td width=25% height=19 style='background-color: #C0C0C0'><b>Data:</b> "
					+ data 
					+ "</td></tr>";
	String strTit =  "<tr><td width='50%' colspan='2' height='19' style='background-color: #C0C0C0'><b>Titolo:</b> "
 					+ frmInt.getTxTitolo() 	                
					+ "</td></tr>";
	String strMess =  "<tr><td width='50%' colspan='2' height='49' style='background-color: #E8FF9F'>"
	                  + frmInt.getTxText()
	                  + "</td></tr>";
	String strBlank = "<tr><td width='50%' colspan='2' height='30'></td></tr>";
*/
	String strClose = '\n' + "</table>" + '\n' + "</body></html>";                  
	    
	BufferedReader in2 =
	  new BufferedReader(
		new FileReader( ForumPath + Forum ));
	
	String sa;
	StringBuffer sa2 = new StringBuffer();
	
	while((sa = in2.readLine())!= null) {
	  if (sa.equals("</table>")) break;  
	     //sa2 += sa + "\n";
	     sa2.append(sa + '\n'); 
	}
	
  in2.close();

  BufferedWriter out2 =
	  new BufferedWriter(
		new FileWriter( ForumPath + Forum ));
	  
	  out2.write(sa2.toString());
	  out2.write(strAut);
	  out2.write(strData);	
	  out2.write(strTit);
	  out2.write(strMess);
	  out2.write(strBlank);
	  out2.write(strClose);
	   
  	  out2.close();
	//System.out.println("fineeeee");
}

}