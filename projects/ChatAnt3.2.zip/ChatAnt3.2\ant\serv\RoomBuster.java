package ant.serv;

import java.util.Date;
import java.util.Calendar;
import java.util.Vector;
import ant.glob.Globals;

import java.io.*;

/*
 *  * This file is part of ChatAnt

ChatAnt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ChatAnt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ChatAnt.  If not, see <http://www.gnu.org/licenses/>.


Copyright 2003-2005 Alessandro Formiconi - formiconi@gmail.com
 */
public class RoomBuster implements Runnable {
				
   private Thread tr;
   private static java.util.Vector rooms = new Vector();
   private int roomToCheck;
   private	ChatServer serv;
   private Calendar cal;   
   private DBNick dbNick;   
   public static boolean EXPIRED = false;   
   private File fi;   
   private Licence lic ;  
	private long now;   
	private Date tempo;   
	private String userDir;
    


public RoomBuster()  {

//	super();


}

public void stop() {
	tr = null;
 }   


public void run() {
	for (;;)
	
		{
			
		 cal = Calendar.getInstance();
	     tempo = cal.getTime();  
	     now = tempo.getTime();
			
			 try
		  {
		System.out.println("...checking system...");
		System.out.println(getClass().getName() + "...disabilitato ChatExpiration ");
		//ALEX 
 	    //checkChatExpiration();
		if (rooms.size() > 0)
	
		   checkRoomExpirationDate();
		
		  }
		  catch(IOException e)
		    {
			}
			catch(InterruptedException e)
					   {
					   }	
	  
		  try
		  {
			  Thread.sleep(60000*5);
		  }
		  catch(InterruptedException e)
		    {
			}
		   finally {

		  	  stop();
		    }
		}

}


public void start() {

	tr = new Thread(this);
	tr.setDaemon(true);
	tr.setPriority(Thread.MIN_PRIORITY);
	tr.start();
	System.out.println("..RoomBuster started");
	roomToCheck = Globals.ServerRooms;
}

public void achtung() {
	//serv.shutdownRoom();
}

public synchronized void update(Vector rooms, ChatServer serv) {

	this.rooms = rooms;
	this.serv = serv;
	System.out.println("update booster");

}
 public void checkChatExpiration()  throws IOException {

	readExpirationClassFile();
	
	if ( lic.isExpired() ) {
		 // licenza scaduta
		 System.out.println(Globals.Diagn[11]);
		 EXPIRED = true;
		 return;
	}		
	
	if ( lic.getPrimoLancio() == 0 ) {
		setProductExpiration();
	}
	
	else if ( lic.getExpiration() < now ) {
	  //------------------System da asteriscare nella versione TRIAL	
	  //System.err.println("La licenza � scaduta, il server verra' disabilitato alla prima nuova connessione");		
	  EXPIRED = true;
	  lic.setExpired(true);
	  writeExpirationClassFile(); //flagga che � scaduta
	  sendDiagn	("ERRORE !", "11");
 	  return;
	} 
	else if ( isCfgModified() ) {
	  System.out.println("File serv-config.cfg degradato. Il server verra' disabilitato alla prima nuova connessione");		
	  EXPIRED = true;
	  lic.setExpired(true); 
	  writeExpirationClassFile();
	  return;
	 }
  //System.out.println("La licenza non e' ancora scaduta");   
}

public void checkRoomExpirationDate()  throws IOException, InterruptedException {

	int idxlastCreated = rooms.size(); 
	long expir = 
	    ( (Room)rooms.elementAt(idxlastCreated -1) ).getExpirationDate();
	
	if ( expir <= now ) {
	   achtung();
	   serv.servRooms.stopRoom(idxlastCreated);
	}
}

public int execPing() {
	
	BufferedReader in = null;
	
	try {
	Runtime r = Runtime.getRuntime();
	Process p = r.exec("ping 62.2.78.245");
	
	if (p == null) {
	  System.out.println("Could not connect");
	  return -1;
	}
	
	in = new BufferedReader(new InputStreamReader(p.getInputStream()));
	
	String line;
	
	while ((line = in.readLine()) != null) {
	   System.out.println(line);
	}
	in.close();
	
	} catch (IOException io) {
	  System.err.println(io.toString()); 
	}
	
	return 0;
}
	public boolean isCfgModified() {

  long modif = fi.lastModified();
  
  return ( ( lic.getLastModified() +3000 >= modif  )
		&& ( lic.getLastModified() -3000 <= modif ) )
		 ? false : true;
}

public boolean MaxUsersReached (DBNick dbNick) {

	readExpirationClassFile();

	if ( lic.getMax_Users() <= dbNick.getNumUsers() ) {
		// asctriscare nella versione TRIAL
		//System.out.println(" --> numero massimo di utenti raggiunto!!");
		sendDiagn	("ERRORE !", "26");
		return true;
	}
	else return false;
}

public synchronized void readExpirationClassFile() {
	
userDir = System.getProperty("user.dir");
fi = new File( userDir 
		   + File.separator
		   + Globals.ChatProperties
		   + File.separator 
		   + Globals.ServerLicenceConfigFile );

try {
				
  ObjectInputStream in = new ObjectInputStream(
	 new FileInputStream ( fi ));
	
	lic = new Licence();
	lic = (Licence) in.readObject();
}
	catch (FileNotFoundException ex) {
	  System.err.println("RoomBuster error: file server-config.cfg assente: " + ex.getMessage() + "\n");
	  System.exit(0);
	}	
   	catch (Exception ex) {
	  System.err.println("RoomBuster error: file server-config.cfg degradato: " + ex.getMessage() + "\n");
	  ex.printStackTrace ();
	  System.exit(0);	  
	}
		
}

public void setProductExpiration() {
	
		lic.setPrimoLancio(1);
		lic.setNow(now);
		lic.setExpiration(Licence.EXPIRATION); //calcola now+Licence.EXPIRATION
		lic.setLastModified(now);		
		writeExpirationClassFile();
}

public void writeExpirationClassFile() {
	
	//userDir = System.getProperty("user.dir");
try {
 
  ObjectOutputStream out = new ObjectOutputStream(
	 new FileOutputStream ( fi ) );
	
   out.writeObject( lic );
   out.close();
   fi.setLastModified( now );
   
   //System.err.println( "--- file serv-config.cfg reimpostato");	   
  }
   catch (Exception ex) {
	  System.err.println( ex.getMessage() + "\n");
	  ex.printStackTrace ();
	}
   	
}//	static {
//	   String userDir = System.getProperty("user.dir");
//	}

	public void sendDiagn(String title, String nDiagn) {

		ant.awt.CentrDlgBase dErr = new ant.awt.CentrDlgBase(
			new java.awt.Frame(), title, nDiagn, true);

	}

}