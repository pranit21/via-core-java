package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class NoProcessorException extends NoPlayerException
{

	public NoProcessorException()
	{
		super();
	}

	public NoProcessorException(String message)
	{
		super(message);
	}



}
