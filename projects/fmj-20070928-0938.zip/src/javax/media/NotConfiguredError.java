package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class NotConfiguredError extends MediaError
{

	public NotConfiguredError()
	{
		super();
	}


	public NotConfiguredError(String message)
	{
		super(message);
	}


}
