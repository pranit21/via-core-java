package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface Effect extends Codec
{

}
