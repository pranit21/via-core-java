package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class MediaEvent extends java.util.EventObject
{
	public MediaEvent(Object source)
	{	super(source);
	}
}
