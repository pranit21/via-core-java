package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class MediaError extends Error
{

	public MediaError()
	{
		super();
	}

	public MediaError(String message)
	{
		super(message);
	}


}
