package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class StopTimeSetError extends MediaError
{

	public StopTimeSetError()
	{
		super();
	}

	public StopTimeSetError(String message)
	{
		super(message);
	}




}
