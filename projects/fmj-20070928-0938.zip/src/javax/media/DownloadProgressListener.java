package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface DownloadProgressListener
{
	public void downloadUpdate();
}
