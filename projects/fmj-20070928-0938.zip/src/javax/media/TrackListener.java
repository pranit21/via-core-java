package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public interface TrackListener
{
	public void readHasBlocked(Track t);
}
