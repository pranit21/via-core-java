package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public interface Owned
{
	public Object getOwner();
}
