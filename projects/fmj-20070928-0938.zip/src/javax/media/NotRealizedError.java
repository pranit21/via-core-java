package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class NotRealizedError extends MediaError
{

	public NotRealizedError()
	{
		super();
	}

	public NotRealizedError(String message)
	{
		super(message);
	}


}
