package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class AudioDeviceUnavailableEvent extends ControllerEvent
{

	public AudioDeviceUnavailableEvent(Controller from)
	{	super(from);
	}
}
