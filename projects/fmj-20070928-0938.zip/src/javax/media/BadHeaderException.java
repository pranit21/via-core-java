package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class BadHeaderException extends MediaException
{

	public BadHeaderException()
	{
		super();
	}

	public BadHeaderException(String message)
	{
		super(message);
	}
}
