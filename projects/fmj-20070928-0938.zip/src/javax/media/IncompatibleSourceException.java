package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class IncompatibleSourceException extends MediaException
{

	public IncompatibleSourceException()
	{
		super();
	}

	public IncompatibleSourceException(String message)
	{
		super(message);
	}


}
