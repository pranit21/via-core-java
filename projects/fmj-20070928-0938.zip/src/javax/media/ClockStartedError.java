package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class ClockStartedError extends MediaError 
{

	public ClockStartedError()
	{
		super();
	}

	public ClockStartedError(String message)
	{
		super(message);
	}

}
