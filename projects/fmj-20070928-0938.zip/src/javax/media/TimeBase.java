package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public interface TimeBase
{
	public long getNanoseconds();

	public Time getTime();
}
