package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface ControllerListener
{
	public void controllerUpdate(ControllerEvent event);
}
