package javax.media.datasink;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface DataSinkListener
{
	public void dataSinkUpdate(DataSinkEvent event);
}
