package javax.media.rtp;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface RemoteParticipant extends Participant
{
	// No methods.
}
