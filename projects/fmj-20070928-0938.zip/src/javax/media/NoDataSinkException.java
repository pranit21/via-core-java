package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class NoDataSinkException extends MediaException
{

	public NoDataSinkException()
	{
		super();
	}


	public NoDataSinkException(String message)
	{
		super(message);
	}


}
