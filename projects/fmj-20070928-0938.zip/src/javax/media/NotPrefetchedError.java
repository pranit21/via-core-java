package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class NotPrefetchedError extends MediaError
{

	public NotPrefetchedError()
	{
		super();
	}


	public NotPrefetchedError(String message)
	{
		super(message);
	}


}
