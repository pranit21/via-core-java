package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class CannotRealizeException extends MediaException
{

	public CannotRealizeException()
	{
		super();
	}


	public CannotRealizeException(String message)
	{
		super(message);
	}


}
