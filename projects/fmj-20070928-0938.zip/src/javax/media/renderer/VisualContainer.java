package javax.media.renderer;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface VisualContainer
{

}
