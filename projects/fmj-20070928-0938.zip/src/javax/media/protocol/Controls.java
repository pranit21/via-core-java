package javax.media.protocol;

/**
 * Complete
 * @author Ken Larson
 *
 */
public interface Controls extends javax.media.Controls
{

}
