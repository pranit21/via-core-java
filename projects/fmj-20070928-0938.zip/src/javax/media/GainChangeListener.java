package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface GainChangeListener
{
	public void gainChange(GainChangeEvent event);
}
