package com.sun.media.ui;

/**
 * TODO: Stub
 * TODO: hierarchy of inheritance
 * @author Ken Larson
 *
 */
public class TextComp
{

}
