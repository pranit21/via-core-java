package javax.media.bean.playerbean;

public class MediaPlayerResource
{

	public static java.util.ResourceBundle resourceBundle;

	public MediaPlayerResource()
	{	throw new UnsupportedOperationException(); // TODO
	}

	public static String getString(String inputString)
	{	throw new UnsupportedOperationException(); // TODO
	}
}
