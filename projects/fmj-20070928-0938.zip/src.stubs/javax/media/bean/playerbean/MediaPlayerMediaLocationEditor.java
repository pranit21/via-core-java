package javax.media.bean.playerbean;

public class MediaPlayerMediaLocationEditor extends java.awt.Panel implements
		java.beans.PropertyEditor, java.awt.event.ActionListener,
		java.awt.event.ItemListener
{

	public MediaPlayerMediaLocationEditor()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public String getJavaInitializationString()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public java.awt.Dimension getPreferredSize()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public void setValue(Object o)
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public Object getValue()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public void setAsText(String s)
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public String getAsText()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public boolean isPaintable()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public void paintValue(java.awt.Graphics g, java.awt.Rectangle area)
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public String[] getTags()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public java.awt.Component getCustomEditor()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public boolean supportsCustomEditor()
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public void addPropertyChangeListener(
			java.beans.PropertyChangeListener listener)
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public void removePropertyChangeListener(
			java.beans.PropertyChangeListener listener)
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public void actionPerformed(java.awt.event.ActionEvent evt)
	{	throw new UnsupportedOperationException();	 // TODO
	}

	public void itemStateChanged(java.awt.event.ItemEvent evt)
	{	throw new UnsupportedOperationException();	 // TODO
	}
}
