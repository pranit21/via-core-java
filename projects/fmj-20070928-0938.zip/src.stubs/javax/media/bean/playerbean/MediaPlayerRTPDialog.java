package javax.media.bean.playerbean;

public class MediaPlayerRTPDialog extends java.awt.Dialog
{

	public MediaPlayerRTPDialog(java.awt.Frame frame)
	{	super(frame);
		throw new UnsupportedOperationException();	// TODO
	}

	public String getRTPAdr()
	{	throw new UnsupportedOperationException();	// TODO
	}
}
