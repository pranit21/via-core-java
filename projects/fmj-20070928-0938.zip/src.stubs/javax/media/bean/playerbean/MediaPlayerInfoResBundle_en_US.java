package javax.media.bean.playerbean;

public class MediaPlayerInfoResBundle_en_US extends
		java.util.ListResourceBundle
{

	public MediaPlayerInfoResBundle_en_US()
	{	throw new UnsupportedOperationException();	// TODO
	}

	protected Object[][] getContents()
	{	throw new UnsupportedOperationException();	// TODO
	}
}
