package net.sf.jdshow;

/**
 * 
 * @author Ken Larson
 *
 */
public class IFilterGraph extends IUnknown
{

	public IFilterGraph(long ptr)
	{
		super(ptr);
		
	}

}
